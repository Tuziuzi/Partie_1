# SITREP ZUG 1 — VOLKSREPUBLIK CHINA (CHN)
**Kampagne SCHWARZE SEE · Jahr 2026 abgeschlossen · nächster Zug: 2027**
Spieler: Andi · WN-01-Validator: **BESTANDEN** (0 Fehler)

---

## 1. Ihr Raumfahrtprogramm läuft — und es dauert

Drei Bauaufträge sind eingereiht. Alle drei sind **Neuentwürfe**, also P0n: weltweit
Stück 1, **Kosten ×4,0, Zeit ×3,0**.

| Auftrag | Stück | Masse | Material | fertig |
|---|---|---|---|---|
| Aufklärungssatellit | 2 × 2 t | 4 t | 16 t | **2029** |
| Scoring-Raumschiff | 5 × 2 t | 10 t | 40 t | **2029** |
| GEO-Relais (+2 C2-Slots) | 2 × 5 t | 10 t | 40 t | **2029** |
| **Summe** | | 24 t | **96 t** | |

Bezahlt aus 40 t Jahresfertigung + 56 t Lager. **Rest: 44 t Lager, 0 t Jahresfertigung.**
Startmasse 66 t von 400 t/a gebucht (Zonenfaktoren: LEO ×1, MEO ×2, HEO ×3, SSO ×1,
GEO ×4). Alles unbewaffnet — Ihr *»Der Weltraum bleibt unbewaffnet«* ist eingehalten.

**Bemessung offengelegt:** Ihr Befehl nannte keine Massen. Ich habe aus `construction.md`
gerechnet — Aufklärer 2 t (Sensor »bis GEO alles aufdecken« 1 t + Struktur 1 t),
Scoring-Schiff 2 t, GEO-Relais 5 t nach `launch_c2.md` §2.1. Wenn Sie anders bauen wollen,
sagen Sie es in Zug 2; die Aufträge lassen sich noch umwidmen.

**Nicht ausgeführt: »orbitale Startkapazität vergrößern«.** Ein E-5-Startkomplex kostet
5 Züge (BZ-01 §7) und war neben 96 t Material in diesem Jahr nicht mehr finanzierbar.
Steht als Befund für Zug 2 an.

**Die zentrale Lehre:** ×4 auf alles ist der Preis dafür, dass Sie drei Entwürfe
gleichzeitig neu beginnen. Wären die Scoring-Schiffe und die Aufklärer derselbe Rumpf
gewesen, stünden Sie nach dem ersten Los auf der Leiter statt dreimal am Anfang.

---

## 2. Die schlechte Nachricht

**Ihr Hackerangriff ist aufgeflogen — mit der bestmöglichen Güte gegen Sie.**

Die Sabotage gegen die EU wurde mit **Admiralty A1** attribuiert. A1 ist die höchste Stufe
der Skala: völlig zuverlässige Quelle, bestätigte Information. Öffentliche Benennung und
Eskalation sind der EU erlaubt.

Rechenweg: Umfang 5 aus Ihrem Blatt, Gegenspionage 4 und Laufzeit 1 Zug GM-Bemessung
(EU mit Repression 0,08 / Medienfreiheit 0,88). Steht im Audit, nachprüfbar.

**Befund V9 — Doppelnennung.** »Sabotage durch massive Hackerangriffe« stand sowohl als
Befehlszeile 6 als auch als Sonderbefehl Sabotage/5. Dieselbe Operation, **einmal**
aufgelöst, nicht zweimal.

---

## 3. Was Ihr Apparat meldet — und was Sie davon abziehen sollten

**Bias-Protokoll B-1:** Repression 0,80, Medienfreiheit 0,10, Domäne Wirtschaft.
Verzerrung **b = 0,2834**, Meldefaktor **×1,2834**.

Im Klartext: Ihre Wirtschaftsberichte kommen rund **28 % zu gut** bei Ihnen an. Das ist
keine Erzählung, das ist die gebuchte Funktion Ihres Regimetyps. Wo eine Zahl auffällig
gut aussieht, lohnt eine unabhängige Prüfung — die kostet einen Befehl.

**Coup-Track:** Basisrate 1,2 % je Zug für ein Einparteiensystem, Wurf **7179 von 10000**
— nicht ausgelöst. Keine Rezession bei Ihnen, das hält den Track niedrig.

---

## 4. Energie (Block CHINA, von Ihnen geführt)

| Kennzahl | Wert |
|---|---|
| Primärenergie | **162,3 EJ** (größter Verbraucher am Tisch) |
| Versorgung | 100 |
| Klima | **10,1** |
| Nachhaltigkeit | 40,0 |
| **Gesamtscore** | **46,0** |

Kein Rezessionsflag, keine Deckungslücke, keine Abregelung. Die Vorwahl »erneuerbar« bei
100 % Budget deckt den Bedarf — aber Klima 10,1 zeigt, dass der Bestand noch überwiegend
fossil ist. Bei Ihrem Verbrauch ist das der größte Einzelhebel auf die Weltbiosphäre.

---

## 5. Weltlage 2026 → 2027

| | 2025 | 2026 |
|---|---|---|
| CO₂ | 422,8 ppm | **426,1 ppm** |
| ΔT | 1,30 °C | **1,3421 °C** |
| Biosphäre B | 100 | **99,47** |

**Scoring:** niemand hat kΔv ausgegeben — kein Schiff im Orbit, das scoren konnte. Remis
an der Spitze, alle Serien bei 0. Ihre Scoring-Schiffe kommen 2029.

**Weltereignis:** 2W10 fiel auf **2** (1+1). `ereignisse.md` führt unter »Ereignistafel«
nur die Konvention, **keine Ergebniszeilen** — **REGELLÜCKE**, gemeldet statt geschätzt.

**Ihre Klienten:** Russland und Indien bleiben gebunden. Sie sind Patron mit 1 freiem
Kriegswirtschaftsschritt.

---

## 6. Für Zug 2

- **44 t Lager, 0 t freie Jahresfertigung** — 2027 bringt wieder 40 t.
- **Ein Entwurf statt drei:** wer denselben Rumpf wiederholt, klettert die Leiter.
- Die A1-Attribution wird beantwortet werden. Überlegen Sie, ob Sie zuerst sprechen.
- Alle 12 C2-Slots sind frei.
- Indien hat Sie um Technologie gebeten und Ihr Nein bekommen — wirtschaftliche Hilfe
  läuft weiter.

---
*Fog of War: dieser Bericht enthält keine verdeckten Daten anderer Fraktionen. Alle Würfe
und Rechnungen liegen im Journal, Belege W-001-0001 ff. und R-Z1-01 ff.*
