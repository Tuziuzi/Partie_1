═══ SITREP — IND — Jahr 2027 ═══
GEHEIM — NUR FÜR IND

▸ Weltlage: 2 öffentliche Auflösungen (Annihilation/Kessler) — Details unten
▸ Eigene Würfe diese Runde: 0
▸ Gebuchte Änderungen (eigene): 9
   · factions.IND.economy.resources.propellant.lh2.stored_t: 2.0 → 1.2903  [references/economics.md §7 + launch_c2.md §5.4 und §5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.propellant.lox.stored_t: 6.0 → 5.3776  [references/economics.md §7 + launch_c2.md §5.4 und §5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.propellant.ch4.stored_t: 3.0 → 2.4994  [references/economics.md §7 + launch_c2.md §5.4 und §5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.launch.restraum_vortrag_t: 38.968 → 40.0  [references/economics.md §7 + launch_c2.md §5.4 und §5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.launch._vortrag_beleg: {'gilt_fuer_jahr': 2027, 'gestartet_gewichtet_t_2026': 1.032, 'regelref': 'launch_c2.md §5.6 (B-16/Entscheidung 2)', 'herkunftsjahr': 2026} → {'gilt_fuer_jahr': 2028, 'herkunftsjahr': 2027, 'gestartet_gewichtet_t_2027': 0.0, 'regelref': 'launch_c2.md §5.6 (B-16/Entscheidung 2)'}  [references/economics.md §7 + launch_c2.md §5.4 und §5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.launch.committed_t: 0 → 0  [references/economics.md §7 + launch_c2.md §5.4 und §5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.c2.slots_committed: 0 → 0  [references/economics.md §7 + launch_c2.md §5.4 und §5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.industrial.available_t: 4.0 → 4.0  [references/economics.md §7 + launch_c2.md §5.4 und §5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.industrial.committed_t: 0 → 0  [references/economics.md §7 + launch_c2.md §5.4 und §5.6 + wn02_skalenschnitt.md §4.1]
▸ Wirtschaft: Produktion 0 t · Upkeep 0 t
▸ Flotte: 0 Einzelschiffe + 2 Schwärme (4 Rümpfe)
▸ Ω-Lage (öffentlich): P_Raum 210000.0 W · Beleg SETUP: leistungsbuch §6.1, IND-Zeile (Startbestand Juli 2026, Güte C)
▸ Welt [annihilation] R2-annihilation-noop: übersprungen — keine Nukleareinsätze in der Vorrunde
▸ Welt [kessler] R2-kessler-zerfall: {"mechanik": "K-Z1", "sonnenphase": "mittel", "sonnenfaktor": 1.0, "hoehenfaktor": 1.0, "h
▸ Nächste Befehle fällig für: Jahr 2028
— Dies ist die Stufe-1-Kurzfassung (Standard). Literarischer Vollbericht nur auf Befehl `SITREP LANG` (Eingabe: diese Datei + kompakt.py-View, Deckel 15 KB).
═════════════════════════════════════════
