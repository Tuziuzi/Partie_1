# SITREP 0 — VOLKSREPUBLIK CHINA (CHN)

**Kampagne:** SCHWARZE SEE · **Zug 1 · Jahr 2026** · Spieler: **Andi**
**Skala:** orbital · Module: Delta V + ERDE-01 + EH-01 (Energie) + OB-01/C-9
**Status:** WN-01-Validator **BESTANDEN** — Zustellung freigegeben

*Abkürzungen beim ersten Auftreten erklärt; danach als bekannt vorausgesetzt.*
*SITREP = Situation Report, Lagebericht. Δv (Delta v) = Geschwindigkeitsänderungs-
budget eines Raumfahrzeugs in km/s. LEO = Low Earth Orbit, niedrige Erdumlaufbahn.
GEO = geostationärer Orbit, 35.786 km. C2 = Command and Control, Führung.*

---

## 1. Ihre Regimeform — das ist Ihre Kernmechanik

Sie führen **den Autokraten persönlich**, nicht ein Kabinett.

| | Wirkung |
|---|---|
| **Sie entscheiden schnell** | Keine Koalitionsreibung, kein öffentlicher Streit. Kurswechsel kosten Sie fast nichts. |
| **Ihre Innenberichte sind geschönt** | Was Ihr Apparat Ihnen meldet, ist **verzerrt** — nach oben. Jede Verzerrung läuft über die Bias-Funktion B-1 mit protokolliertem Seed. Der GM lügt nie über die Wahrheit; er zeigt Ihnen, was Ihr Apparat meldet. |
| **Coup-Risiko** | Rezession, Niederlage und hoher Personalismus treiben den Coup-Track. |
| **Nachfolgeproblem** | Fällt die Führung, ist die Nachfolge nicht geregelt. |

**Ihre Regimeparameter:** Repression **0,72** · Medienfreiheit **0,10** ·
Parteidominanz **0,90** · Personalismus **0,55**

- **Doktrin:** `vergeltung_nur` — keine taktischen Kernwaffen, nur Vergeltung [QE-11]
- **Persönlichkeit:** Status quo
- **Kernwaffen:** ja
- **Rüstungsquote 2026:** 1,7 % BIP (SIPRI 2024: 314 Mrd $, Güte A)

**Praktische Folge:** Trauen Sie Ihren eigenen Zahlen nicht blind. Wo Ihr Bericht
auffällig gut aussieht, lohnt eine unabhängige Prüfung — die kostet aber einen Befehl.

---

## 2. Ihre Startbestände (Beleg: SETUP, alle kanonquellenbelegt)

### Raumfahrt

| Posten | Wert | Quelle |
|---|---|---|
| **Startkapazität** | **400 t/a** LEO-Äquivalent (Langer Marsch, kommerzielle Träger) | launch_c2.md Tab. 1 |
| **C2-Slots** | **12** (CDSN, Tianlian) | launch_c2.md Tab. 2 |
| **Ω-Raumleistung P_Raum** | **1,50 · 10⁶ W** (Omega = gebuchte Leistung im Orbit) | leistungsbuch §6.1 |
| **K_Raum** | 0,018 (Kardaschew-Index Ihres Raumsegments) | leistungsbuch §6.1 |
| Weltanteil Raumleistung | 2,6 % | leistungsbuch §6.1 |
| **q_raum (Raumfahrtquote)** | 0,0010 (0,10 % BIP) | C-9 Rev. B §1.1 |

### Bodenstreitkräfte (BL-01, aus SIPRI 2024 kompiliert, kein Zufall)

| Heer | Luft | SAM | See | ASAT |
|---|---|---|---|---|
| 105 | 105 | 116 | 114 | 10 |

*SAM = Surface-to-Air Missile, bodengestützte Flugabwehr. ASAT = Anti-Satellite,
Satellitenabwehr — Sie halten den Höchstwert 10.*

### Flotte, Industrie, Forschung
Alles auf **Null**. Keine Schiffe, keine Fabriken, keine laufende Forschung.
Das ist der reguläre Start 2026.

### Bündnis — Sie sind Patron von ZWEI Klienten

**Rolle `patron` · 1 Kriegswirtschaftsschritt gebunden · 1 frei** (ein Patron bindet
genau einen Schritt, unabhängig von der Zahl seiner Klienten).

| Klient | Führung | Bemerkung |
|---|---|---|
| **Russland** (`dependsOn: CHN`) | KI | 100 t/a, 5 C2-Slots, Kernwaffen, personalistisch. Hat **0 freie Schritte** — die Startquote nach §1 hat den zweiten bereits verbraucht, Russland steht schon auf `KRIEGSWIRTSCHAFT`. |
| **Indien** (`dependsOn: CHN`) | **Jakob** | Beim Aufsetzen als REGELLÜCKE gefunden und vom Spielleiter zugunsten des Kanons entschieden (`kriegswirtschaft.md` §2.2 führt Indien als Vasall RUS/CHN). Jakob ist damit formal Ihr Klient. |

**Wichtig:** Ein Patron kann seinen Klienten **nicht entlassen** (KW-02). Das Verhältnis
endet nur durch **Verrat des Klienten**. Jakob kann sich also lösen — Sie können ihn
nicht halten und nicht loswerden. Löst er sich, bekommen Sie Ihren Schritt zurück.

---

## 3. Die offene Weltlage

| Fraktion | Spieler | t/a | C2 | Ω P_Raum | Regime | Kernwaffen | Bindung |
|---|---|---|---|---|---|---|---|
| **USA** | KI | 2.000 | 24 | 5,24·10⁷ W | Demokratie | ja | Patron der EU |
| **CHN** | **Sie** | 400 | 12 | 1,50·10⁶ W | Einparteien | ja | Patron von RUS + IND |
| **RUS** | KI | 100 | 5 | 2,70·10⁵ W | personalistisch | ja | Ihr Vasall |
| **EU** | **Roman** | 45 | 8 | 1,00·10⁶ W | Demokratie | ja | Vasall USA |
| **IND** | **Jakob** | 40 | 3 | 2,10·10⁵ W | Demokratie | ja | **Ihr Vasall** |
| **REST** | KI | 0 | 0 | 0 W | hybrid | nein | ungebunden |

**Ihre Lage in einem Satz:** Sie sind die klare Nummer zwei im Raum — mit zwei Klienten
im Rücken und dem größten Energieverbrauch der Welt (28 % des Welt-Primärenergiebedarfs).

Die USA halten **90 % der Weltraumleistung** und die fünffache Startkapazität. Gegen sie
direkt anzurennen wäre teuer.

**Roman führt seit Zug 1 die EU** — aus deutscher Perspektive, als Vasall der
KI-geführten USA. Damit stehen sich am Tisch zwei menschlich geführte Demokratien in
fremden Blöcken gegenüber (Roman im US-Block, Jakob in Ihrem). Beide haben dasselbe
Emanzipationsproblem, nur in entgegengesetzte Richtung. Eine europäisch-indische
Verständigung wäre für Sie die unangenehmste Entwicklung der frühen Partie — Ihr Klient
liefe Ihnen weg, und Washington bekäme einen zweiten Anker in Asien.

---

## 4. Was Sie für Zug 1 entscheiden müssen

**Blatt 1 — Staatsführung**
1. **Rüstungsquote** (Regler; C-3-Sprungdeckel begrenzt den Jahressprung)
2. **Safety-Slider** (KI-Sicherheit gegen Tempo)
3. **Repression** — bei 0,72 bereits hoch; höher steigert Kontrolle und Kaskadenrisiko
4. **Orbitalanteil** — wie viel Ihres Budgets in den Raum geht
5. Bis zu **6 Befehle** (Domäne · Ziel · Freitext), Sonderbefehle (verdeckte Operation,
   Umfang, falsche Flagge), 2 Conditionals

**Blatt 2 — Energiepolitik (EH-01, Block CHINA, von Ihnen geführt)**
6. Energiebudget 0–100 % des Jahreskapitalbudgets
7. Baureihenfolge oder freie Rangliste über 19 Träger
> **Gemessen und nicht offensichtlich:** eine einzige Technologie lässt 18–34 % des
> Bedarfs ungedeckt, sieben nebeneinander nur 2,3 %. **Breite schlägt Rangfolge.**

**Blatt 3 — Mitlaufende Module** (Delta V als Nachbarmodul)

**Delta V (Raumsegment)** — für Zug 1 typischerweise:
- Schiffsentwürfe (über den Shipyard-Rechner) oder Bau von Standardgerät
- Zielbahn: LEO / MEO / GEO / EML — jede Zone hat einen Massenfaktor gegen Ihre 400 t/a
- Forschungsslot setzen (Autonomie L1, Antriebe, Sensorik)
- Aufklärung, verdeckte Operationen, Diplomatie

**Sie können frei formulieren.** Schreiben Sie mir Ihre Befehle in Prosa; ich übersetze
sie in das Auflösungsformat und weise zurück, was gegen eine Regel läuft — nie
stillschweigend umgedeutet.

---

## 5. Offene Punkte, die Sie kennen sollten

- **C-9 Raumfahrtquote ist aktiv** (Rev. B, ab Setup nach §9.3). Ihre Startkapazität ist
  ab jetzt **endogen**: sie wächst oder schrumpft mit Wirtschaftskraft und q_raum.
  Rampendeckel aufwärts ×1,25 je Zug, abwärts sofort.
  *Der Balancelauf zu C-9 (n ≥ 1200) steht laut Regelwerk noch **OFFEN** — die Regel ist
  unkalibriert. Das ist so im Spielstand vermerkt.*
- **Zeitmodell:** Ära I, 1 Jahr je Zug, Züge 1–25 (2026–2051).
- **Siegkriterien:** UEBERGABE (Kardaschew-Index K ≥ 0,9 bei intakter Biosphäre) ·
  STAGNATION (Zug 75) · WORLD3_KOLLAPS · XRISK_ENDE · BIOZID (Siegsperre).
  Weltstand heute: **K = 0,7285**.

---
*Erzeugt vom Delta-V-GM-Controller, Kampagne SCHWARZE SEE, Seed 516028054.
Fog of War: dieser Bericht enthält keine verdeckten Daten anderer Fraktionen.*
