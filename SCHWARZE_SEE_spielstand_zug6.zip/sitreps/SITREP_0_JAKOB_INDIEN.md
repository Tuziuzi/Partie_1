# SITREP 0 — REPUBLIK INDIEN (IND)

**Kampagne:** SCHWARZE SEE · **Zug 1 · Jahr 2026** · Spieler: **Jakob**
**Skala:** orbital · Module: Delta V + ERDE-01 + EH-01 (Energie) + OB-01/C-9
**Status:** WN-01-Validator **BESTANDEN** — Zustellung freigegeben

*Abkürzungen beim ersten Auftreten erklärt; danach als bekannt vorausgesetzt.*
*SITREP = Situation Report, Lagebericht. Δv (Delta v) = Geschwindigkeitsänderungs-
budget eines Raumfahrzeugs in km/s. LEO = Low Earth Orbit, niedrige Erdumlaufbahn.
GEO = geostationärer Orbit, 35.786 km. C2 = Command and Control, Führung.*

---

## 1. Ihre Regimeform — das ist Ihre Kernmechanik

Sie führen **die Regierung als Kollektiv**, nicht eine Person.

| | Wirkung |
|---|---|
| **Ihr Lagebild ist ehrlich** | Was Ihr Apparat meldet, entspricht der Wahrheit. Keine geschönten Innenberichte. |
| **Ihr Lagebild ist öffentlich** | Ihre Zahlen sind für andere Fraktionen leichter greifbar. Sie haben keine Überraschung im Rücken. |
| **Kein Coup-Risiko** | Ihre Führung fällt nicht über Nacht. Dafür entscheiden Sie langsamer als eine Autokratie. |

**Warnung aus der Startlage:** Indien wird im Kanon als `demokratie` geführt, trägt aber
Repressionswert **0,42** und Medienfreiheit **0,32** (V-Dem stuft Indien seit 2017 als
Wahlautokratie ein, Rang 105 von 179 [QA-42]). Sie sitzen dicht an der Kippkante zur
Autokratie. Ein Regimewechsel im Spiel schaltet Ihre gesamte Mechanik um.

- **Doktrin:** `nfu` — No First Use (nuklearer Erstschlagverzicht)
- **Persönlichkeit:** Opportunist
- **Kernwaffen:** ja
- **Rüstungsquote 2026:** 2,3 % BIP (SIPRI 2024: 86,1 Mrd $, Güte A)

---

## 2. Ihre Startbestände (Beleg: SETUP, alle kanonquellenbelegt)

### Raumfahrt

| Posten | Wert | Quelle |
|---|---|---|
| **Startkapazität** | **40 t/a** LEO-Äquivalent (LVM3, PSLV/GSLV) | launch_c2.md Tab. 1 |
| **C2-Slots** | **3** (ISTRAC/IDSN) | launch_c2.md Tab. 2 |
| **Ω-Raumleistung P_Raum** | **2,10 · 10⁵ W** (Omega = gebuchte Leistung im Orbit) | leistungsbuch §6.1 |
| **K_Raum** | −0,068 (Kardaschew-Index Ihres Raumsegments) | leistungsbuch §6.1 |
| Weltanteil Raumleistung | 0,4 % | leistungsbuch §6.1 |
| **q_raum (Raumfahrtquote)** | 0,0005 (0,05 % BIP) | C-9 Rev. B §1.1 |

### Bodenstreitkräfte (BL-01, aus SIPRI 2024 kompiliert, kein Zufall)

| Heer | Luft | SAM | See | ASAT |
|---|---|---|---|---|
| 64 | 54 | 51 | 50 | 5 |

*SAM = Surface-to-Air Missile, bodengestützte Flugabwehr. ASAT = Anti-Satellite,
Satellitenabwehr.*

### Flotte, Industrie, Forschung
Alles auf **Null**. Keine Schiffe, keine Fabriken, keine laufende Forschung.
Das ist der reguläre Start 2026.

---

## 2a. NACHTRAG — Ihre Bündnisbindung (Änderung gegen den ersten Entwurf)

**`dependsOn: CHN` · Rolle `vasall` · 1 Kriegswirtschaftsschritt gebunden · 1 frei**

Beim Aufsetzen wurde eine **REGELLÜCKE** gefunden: `kriegswirtschaft.md` §2.2 führt
Indien in der Standard-Fraktionsliste als **Vasall (RUS/CHN)**, das Setup-Skript hatte
Sie aber als ungebunden angelegt. Der Spielleiter hat zugunsten des Kanons entschieden.
Sie starten damit als **Klient Chinas** — also von Andis Fraktion.

Was das heißt:
- Sie können nur **einer** Eskalation folgen, wo eine blockfreie Macht **zwei** folgen kann.
- **Es ist ein Anfangs-Handicap, kein Dauerzustand.** Zwei Wege heraus:
  1. **L1-Tech »Umbau der heimischen Wirtschaft«** (§4.1) — reguläre Forschung,
     0,25 × Jahresbudget, Erfolg ab **4 auf 1W6**. Wirkt auch **auf Vorrat**.
  2. **Verrat am Patron** (§4.2 / KW-02) — Peking kann Sie nicht entlassen, nur Sie
     können das Verhältnis aufkündigen. Danach sind zunächst **beide** Schritte
     gebunden, zurückzugewinnen über Forschung.

Sie sind die einzige **Demokratie im chinesischen Block**. Das ist unbequem — und
zugleich Ihre stärkste diplomatische Karte gegenüber Europa.

---

## 3. Die offene Weltlage

| Fraktion | Spieler | t/a | C2 | Ω P_Raum | Regime | Kernwaffen | Bindung |
|---|---|---|---|---|---|---|---|
| **USA** | KI | 2.000 | 24 | 5,24·10⁷ W | Demokratie | ja | Patron der EU |
| **CHN** | **Andi** | 400 | 12 | 1,50·10⁶ W | Einparteien | ja | **Ihr Patron** |
| **RUS** | KI | 100 | 5 | 2,70·10⁵ W | personalistisch | ja | Vasall CHN |
| **EU** | **Roman** | 45 | 8 | 1,00·10⁶ W | Demokratie | ja | Vasall USA |
| **IND** | **Sie** | 40 | 3 | 2,10·10⁵ W | Demokratie | ja | Vasall CHN |
| **REST** | KI | 0 | 0 | 0 W | hybrid | nein | ungebunden |

**Ihre Lage in einem Satz:** Sie sind die schwächste Raumfahrtnation am Tisch, Klient
Ihres stärksten menschlichen Gegenspielers — und trotzdem eine Kernwaffenmacht mit
1,4 Milliarden Menschen. Die USA halten 90 % der Weltraumleistung; Andi (China) startet
mit **zehnfacher Startkapazität** und **vierfachen C2-Slots**.

**Roman führt seit Zug 1 die EU** — aus deutscher Perspektive, als Vasall der
KI-geführten USA. Zwei Demokratien in fremden Blöcken, beide mit demselben
Emanzipationsproblem in entgegengesetzte Richtung: das ist die naheliegendste
diplomatische Bewegung der frühen Partie. Er hat 8 C2-Slots und kaum Masse, Sie haben
3 Slots und dieselbe Fessel. Reden Sie miteinander.

---

## 4. Was Sie für Zug 1 entscheiden müssen

**Blatt 1 — Staatsführung**
1. **Rüstungsquote** (Regler; C-3-Sprungdeckel begrenzt den Jahressprung)
2. **Safety-Slider** (KI-Sicherheit gegen Tempo)
3. **Repression** — bei 0,42 gefährlich nah an der Regimekippe
4. **Orbitalanteil** — wie viel Ihres Budgets in den Raum geht
5. Bis zu **6 Befehle** (Domäne · Ziel · Freitext), Sonderbefehle, 2 Conditionals

**Blatt 2 — Energiepolitik (EH-01, Block INDIEN, von Ihnen geführt)**
6. Energiebudget 0–100 % des Jahreskapitalbudgets
7. Baureihenfolge oder freie Rangliste über 19 Träger
> **Gemessen und nicht offensichtlich:** eine einzige Technologie lässt 18–34 % des
> Bedarfs ungedeckt, sieben nebeneinander nur 2,3 %. **Breite schlägt Rangfolge.**

**Blatt 3 — Mitlaufende Module** (Delta V als Nachbarmodul)

**Delta V (Raumsegment)** — für Zug 1 typischerweise:
- Schiffsentwürfe (über den Shipyard-Rechner) oder Bau von Standardgerät
- Zielbahn: LEO / MEO / GEO / EML — jede Zone hat einen Massenfaktor gegen Ihre 40 t/a
- Forschungsslot setzen (z. B. **Autonomie L1**: senkt C2-Slotkosten, erlaubt Kampf
  jenseits GEO ohne Besatzung — bei 3 Slots ein ernsthafter Kandidat)
- Aufklärung, Diplomatie, Bündnisangebote

**Sie können frei formulieren.** Schreiben Sie mir Ihre Befehle in Prosa; ich übersetze
sie in das Auflösungsformat und weise zurück, was gegen eine Regel läuft — nie
stillschweigend umgedeutet.

---

## 5. Offene Punkte, die Sie kennen sollten

- **C-9 Raumfahrtquote ist aktiv** (Rev. B, ab Setup nach §9.3). Ihre Startkapazität ist
  ab jetzt **endogen**: sie wächst oder schrumpft mit Wirtschaftskraft und q_raum.
  Rampendeckel aufwärts ×1,25 je Zug, abwärts sofort.
  *Der Balancelauf zu C-9 (n ≥ 1200) steht laut Regelwerk noch **OFFEN** — die Regel ist
  unkalibriert. Das ist so im Spielstand vermerkt.*
- **Zeitmodell:** Ära I, 1 Jahr je Zug, Züge 1–25 (2026–2051).
- **Siegkriterien:** UEBERGABE (Kardaschew-Index K ≥ 0,9 bei intakter Biosphäre) ·
  STAGNATION (Zug 75) · WORLD3_KOLLAPS · XRISK_ENDE · BIOZID (Siegsperre).
  Weltstand heute: **K = 0,7285**.

---
*Erzeugt vom Delta-V-GM-Controller, Kampagne SCHWARZE SEE, Seed 516028054.
Fog of War: dieser Bericht enthält keine verdeckten Daten anderer Fraktionen.*
