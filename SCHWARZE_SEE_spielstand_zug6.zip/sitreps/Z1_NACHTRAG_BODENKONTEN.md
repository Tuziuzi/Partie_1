# NACHTRAG ZUG 1 — BODENKONTEN UND ARSENALE
**Kampagne SCHWARZE SEE** · Modul **ZH-01 »ZEUGHAUS« Rev. C** · für alle drei Spieler
Validator **BESTANDEN** · Prüfpass **ZH1–ZH13 BESTANDEN**

*Bodenkonten, Arsenalstände und Weltrechenleistung sind öffentliche Größen (SIPRI,
FAS/SIPRI Nuclear Notebook, Marktdaten). Dieser Nachtrag geht an alle drei Tische.*

---

## 1. Warum es diesen Nachtrag gibt

Delta V führt eine **Raumkasse** (Startkapazität in t/a) und Rabatte für den Boden, aber
bisher **keine Bodenkasse**. Ein Sprengkopf hatte keinen Preis, ein Panzerbataillon keine
Tonne. ZH-01 schließt das: **eine** neue Umrechnung, **keine** neue Währung.

```
Bodenkonto = Ausgaben(SIPRI) x k(BL-01) x 0,20 (Gerät, C-9 §2) x kappa 27,4 t/Mrd USD
           + Restraum (Startkapazität, die NICHT ins All geht, 1:1)
```

**Die zentrale Kopplung:** Startkapazität, die Sie nicht verplanen, fällt auf den Boden.
Zwei Ausgänge, eine Tonne (Z-1.5). Wer alles in den Orbit schießt, hat keinen Restraum.

---

## 2. Bodenkonten Zug 2 (2027)

C-2 NORMATIV · W_index 1,0 · Restraum bei **voll stehengelassener** Startkapazität

| | Rüstungsfluss | Restraum (max) | **Bodenkonto (max)** | Hochtech-Tranche 15 % |
|---|---|---|---|---|
| **CHN** (Andi) | 2 236,9 t | 400,0 t | **2 636,9 t** | **395,5 t** |
| **EU** (Roman) | 1 630,3 t | 45,0 t | **1 675,3 t** | **251,3 t** |
| **IND** (Jakob) | 589,8 t | 40,0 t | **629,8 t** | **94,5 t** |

**Diese beiden Zahlen schreiben Sie oben auf Blatt 3 ab** — Feld »Bodenkonto laut SITREP«
und »davon Hochtechnologie-Tranche«. Der GM prüft Ihre Zeilen dagegen.

**Die Tranche ist Fluss, kein Bestand.** Was Sie nicht buchen, verfällt zum Jahresende
(Z-1.4). Sparen geht auf dem Bodenkonto nicht.

**Was unter den Deckel fällt:** Sprengköpfe, Kernwaffenprogramm, Future-SP,
State-of-the-Art, ASAT. **Was nicht:** Modernisierung, Advanced-Punkte, Flugkörper, SAM,
Personal — Leiter MASSE und PRÄZISION sind ungedeckelt.

---

## 3. Arsenale, Stand 2026 (aus LW-01 gebucht)

| | USA | RUS | CHN | EU (Frankreich) | IND |
|---|---|---|---|---|---|
| Sprengköpfe | **3 700** | **4 309** | **700** | **290** | **190** |
| davon disloziert | 1 770 | 1 718 | 40 | 280 | 0 |
| Massenlinie (P4) | **nein** | ja | **ja** | nein | nein |
| Pausenzüge | **2** | 0 | 0 | 0 | 0 |

**Zwei Zeilen entscheiden mehr als die Bestandszahl.**

**Die USA haben 3 700 Köpfe und eine kalte Linie.** Die LEP-Linie (Life Extension Program,
Kampfwertsteigerung vorhandener Köpfe) läuft, aber die Pit-Neufertigung (Pit = der
Spaltkern einer Waffe) ist seit 1989 kalt — erste Kriegsreserve-Pit 2024. Zwei Pausenzüge
heißt: **die USA können nicht sofort in Serie gehen**, sie müssen erst wieder anfahren.

**China hat 700 Köpfe und eine warme Massenlinie.** Neue Silos, neue Werke, Zuwachs rund
100 im Jahr. In der Zahl liegt China weit hinten, in der **Rate** liegt es vorn.

**Indien: 190 Köpfe, keiner disloziert.** Das ist die indische Doktrin in einer Zeile —
Sprengköpfe und Träger getrennt gelagert. Zeit zum Reagieren, aber keine Zweitschlag-
Bereitschaft in Minuten.

---

## 4. DW-01 »DENKWERK« — Rechenleistung als Ressource

100 RP (Rechenpunkte) Weltbestand 2026:

| USA | CHN | REST | EU | IND | RUS |
|---|---|---|---|---|---|
| **55** | **20** | **13** | **8** | **3** | **1** |

**Die EU hat 8 von 100.** Roman führt den besten Energieblock der Welt und den
viertgrößten Rechenblock. Chinas Zubau steht unter `ck_sperre` (kein EUV — Extrem-
Ultraviolett-Lithografie, das Werkzeug für die Spitzenkante der Chipfertigung) auf dem
Autarkiepfad: langsamer, aber unabhängig.

**Härtung fast überall H0.** Niemand hat seine Rechenzentren gehärtet — 55 amerikanische
RP stehen in 12 Standorten, 11 davon ungeschützt. Das ist ein Ziel, kein Bestand.

---

## 5. EW-01 »EICHWERK« — was ab jetzt verdeckt mitläuft

Hauptbuch im Modus **STILL** eröffnet. Sichtbarkeit, Signaturfront und Kontaktwürfe laufen
ab Zug 2 beim GM mit; Sie erfahren davon nur auf Ansprache. **Doktrin aller sechs
Fraktionen 2026: LAUT** — niemand hat Funkstille angeordnet.

---

*Rechenprotokolle im Audit unter `zeughaus.buchungen`. Rohausgaben `zh01.py konto` und
`zh01.py pruefe` im Journal. Belege ZH-01 Z-1, QZ-01/QZ-02.*
