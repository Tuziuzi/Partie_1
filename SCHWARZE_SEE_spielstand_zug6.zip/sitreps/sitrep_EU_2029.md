═══ SITREP — EU — Jahr 2029 ═══
GEHEIM — NUR FÜR EU

▸ Weltlage: 2 öffentliche Auflösungen (Annihilation/Kessler) — Details unten
▸ Eigene Würfe diese Runde: 0
▸ Gebuchte Änderungen (eigene): 9
   · factions.EU.economy.resources.propellant.lh2.stored_t: 1.2487 → 0.8056  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.EU.economy.resources.propellant.lox.stored_t: 5.6231 → 5.0398  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.EU.economy.resources.propellant.ch4.stored_t: 2.0824 → 1.7349  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.EU.economy.resources.launch.restraum_vortrag_t: 45.0 → 45.0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.EU.economy.resources.launch._vortrag_beleg: {'gilt_fuer_jahr': 2029, 'herkunftsjahr': 2028, 'gestartet_gewichtet_t_2028': 0.0, 'regelref': 'launch_c2.md §5.6 (B-16)'} → {'gilt_fuer_jahr': 2030, 'herkunftsjahr': 2029, 'gestartet_gewichtet_t_2029': 0.0, 'regelref': 'launch_c2.md §5.6 (B-16)'}  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.EU.economy.resources.launch.committed_t: 0.0 → 0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.EU.economy.resources.c2.slots_committed: 0 → 0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.EU.economy.resources.industrial.available_t: 5.0 → 5.0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.EU.economy.resources.industrial.committed_t: 0 → 0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
▸ Wirtschaft: Produktion 0 t · Upkeep 0 t
▸ Flotte: 0 Einzelschiffe
▸ Ω-Lage (öffentlich): P_Raum 1000000.0 W · Beleg SETUP: leistungsbuch §6.1, EU-Zeile (Startbestand Juli 2026, Güte C)
▸ Welt [annihilation] R4-annihilation-noop: übersprungen — keine Nukleareinsätze in der Vorrunde
▸ Welt [kessler] R4-kessler-zerfall: {"mechanik": "K-Z1", "sonnenphase": "mittel", "sonnenfaktor": 1.0, "hoehenfaktor": 1.0, "h
▸ Nächste Befehle fällig für: Jahr 2030
— Dies ist die Stufe-1-Kurzfassung (Standard). Literarischer Vollbericht nur auf Befehl `SITREP LANG` (Eingabe: diese Datei + kompakt.py-View, Deckel 15 KB).
═════════════════════════════════════════
