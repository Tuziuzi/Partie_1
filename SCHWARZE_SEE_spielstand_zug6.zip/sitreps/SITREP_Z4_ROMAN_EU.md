# SITREP ZUG 4 · 2029 · **EUROPÄISCHE UNION**
**An:** Roman · **Von:** GM · **Einstufung:** nur für die EU
Kampagne SCHWARZE SEE · Stand 31.12.2029

> **Dieser Zug wurde wieder vertreten** — A3/V2, nach Ihrem Profil aus Zug 1, mit vollen
> Treuhand-Schranken. Nicht der generische Doktrinbaum wie in Zug 3. Rückgabebrief am Ende.

---

## 1. Jemand hat versucht, einen Ihrer Satelliten zu rammen

**Indien.** Zwei SPADEX-Kleingeräte haben ihr Perigäum von 700 auf 500 km abgesenkt und sind
zweimal auf Kollisionskurs an **SARah/SARLupe** vorbeigezogen. Beide Versuche gingen daneben
(Trefferwahrscheinlichkeit 0,1995 je Rumpf, Würfe 9434 und 4110).

**Und diesmal wissen Sie, wer es war.** Eine Bahnänderung ist kein verdeckter Vorgang — jedes
Boden-Radar verfolgt sie. Zwei indische Satelliten, die sich auf die Höhe eines deutschen
Radaraufklärers absenken und zweimal nahe vorbeiziehen, sind nicht abstreitbar. **Attribution
A1, ohne Wurf.** Ab A1 haben Sie **Eskalationsrecht**.

Damit halten Sie gegen Indien nun zwei Karten: die **B2** aus Zug 1 (falsche Flagge
durchschaut) und diese **A1**. Ihre Vertretung hat beide bewusst **nicht** gespielt — eine
öffentliche Attribution ist eine eigene Ansage mit eigenem Wurf, und ein Fehlschlag würde alle
künftigen EU-Attributionen um eine Stufe senken. Das ist Ihre Entscheidung, nicht die des
Vertreters.

---

## 2. Was in Ihrem Namen entschieden wurde

**Budget 36/29/30/5.** Teilkorrektur des A1-Zuges: Militär von 20 zurück auf 29, Forschung
zurück auf Ihre 30, Wirtschaft von 45 auf 36, verdeckt von 10 auf 5. Jede Bewegung innerhalb
der ±10-Punkte-Schranke; die volle Rückkehr auf Ihre 38/0 braucht noch einen Zug.

**Verdeckt bleibt nicht auf null.** Nach zwei blinden Zügen — zweimal angegriffen, zweimal
ohne benennbaren Täter — geht Gegenspionage mit Gewicht 1 in die Attributionsformel ein. Das
ist Ihr Weg zum öffentlichen Benennen, kein verdeckter Gegenschlag.

**Erstmals ein Bodenkonto: 1 619,9 t** (HE-19 — ab diesem Zug führen alle sechs Fraktionen
eines). Verteilt auf 6 % Geheimdienste (**5 Operationsslots** statt der bisherigen zwei),
20 % Force Projection, 15 % Modernisierung auf die **Marine** — Ostsee und
Unterwasserinfrastruktur, genau Ihre Aufträge aus Zug 1. Keine Sprengköpfe.

Frankreich-Gespräche, europäischer Pfeiler, Trägerprogramm und Ariane wieder aufgenommen —
die vier Posten, die der Doktrinbaum liegen ließ. Das amerikanische Angebot wurde **gehalten,
nicht gezeichnet**; um Fristverlängerung bis Zug 6 wurde gebeten.

**Wirtschaft: 19,3269 → 19,1162 Bio USD (−1,09 Pp).** Chinas Handelsabbruch erodiert im
vierten Jahr (−0,74), Indiens Sanktionen kosten weiter −0,90, das Zivilkonto bringt +0,60.

---

## 3. Die Welt hat sich verschoben

**China hat den Weltraum genommen.** Neun Satelliten gestartet, **alle fünf Zonen gescort** —
LEO, MEO, HEO, SSO, GEO. Dazu zwei Aufklärer, die ab sofort jedes Bahnobjekt bis GEO
auflösen, und zwei GEO-Relais. **Serie China 2 — eine Runde vor »Krieg gewonnen«.**

**In China ist die Präferenzkaskade eingetreten.** Nach vier Jahren mit knapp zehn Prozent
Risiko je Zug: Wurf 258 gegen 975. Die geäußerte Zustimmung bricht auf den wahren Wert
zusammen. Peking hat ein innenpolitisches Ereignis erster Ordnung, mitten in der
Kapitalmarktsperre.

**Die USA haben Earth Surface gewonnen** und beide Budgetzeilen dazu — mit einem Bodenkonto
von 7 463,6 t, dem Vierfachen Ihres. Washington hat China öffentlich benannt, auf das
Eskalationsrecht verzichtet und den Halbleiterhebel zum dritten Mal ungezogen gelassen.

**Moskau** hält das Energieabkommen mit Peking fort, ohne zu zeichnen, und liefert weiter
Festpreisgas an einzelne Ihrer Hauptstädte am Rat vorbei. Eine dritte Einflusskampagne gegen
europäische Öffentlichkeiten ist **geglückt** und blieb bei Güte F6 — unbenennbar.

**Energie: EU 69,8 — weiterhin Platz eins**, vor USA 58,4 · Russland+Rest 56,0 · China 48,1 ·
Indien 47,9. **Welt:** 436,0 ppm · +1,4131 °C · Biosphäre 97,71.

---

## 4. RÜCKGABEBRIEF (SV-01 §2)

**GETAN**
- Budget in Richtung Ihrer Linie korrigiert, innerhalb der Schranken.
- Erstes europäisches Geheimdienstnetz aufgebaut: 5 Operationsslots.
- Marine modernisiert (Ostsee, Unterwasserinfrastruktur).
- Frankreich, europäischer Pfeiler, Trägerprogramm, Ariane wieder aufgenommen.
- US-Angebot gehalten, Fristverlängerung erbeten.

**DURCH SCHRANKEN ABGELEHNT**
- Nichts. Keine Zeile musste durch HALTEN ersetzt werden.

**BEWUSST NICHT ENTSCHIEDEN — das liegt bei Ihnen**
- **Zwei Attributionen gegen Indien**, B2 und jetzt A1. Die A1 gibt Ihnen Eskalationsrecht.
  Ein Rammversuch gegen einen Aufklärungssatelliten im Frieden ist ein Präzedenzfall, den
  außer Ihnen niemand verhandeln kann.
- **Das amerikanische Angebot** — Abschluss wäre Schranke 3.
- **Die französische Unterschrift**, **Kanada**, **Moskaus Umgehungsangebote**, **Chinas
  antikoloniale Front**: alles Richtungsentscheidungen.
- **45 t/a Startkapazität** und 8 C2-Slots weiterhin ungebunden, kein freigegebener Entwurf.
  Während China gerade fünf Zonen besetzt hat.

**LAGE**
China gewinnt im Weltraum und wackelt im Inneren. Die USA gewinnen am Boden und tun sonst
nichts. Indien greift Sie offen an und trifft nicht. Sie sind Energieerster, wirtschaftlich
zweitstärkster Block — und der Einzige, der noch kein einziges Objekt im Orbit hat.

**ANSTEHEND**
Zug 5. Die Vertretung ist beendet.

---

## 5. Domänen-Checkliste Zug 4

| Domäne | Status |
|---|---|
| energie · wirtschaft · innenpolitik · aussenpolitik · intel · militaer · forschung | **alle aufgelöst** |

WN-01-Validator: **BESTANDEN** (0 Fehler, 0 Warnungen, 3 Hinweise).
