═══ SITREP — CHN — Jahr 2029 ═══
GEHEIM — NUR FÜR CHN

▸ Weltlage: 2 öffentliche Auflösungen (Annihilation/Kessler) — Details unten
▸ Eigene Würfe diese Runde: 0
▸ Gebuchte Änderungen (eigene): 18
   · factions.CHN.swarms.CHN_AUFKL_LEO: None → {'design': 'CHN_aufklaerer', 'count': 2, 'zone': 'LEO', 'orbit_km': 600, 'dv_kms': 0.0, 'status': 'aktiv', 'bewaffnet': False, 'rolle': 'Aufklaerung bis GEO'}  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.CHN.swarms.CHN_SCORE_LEO: None → {'design': 'CHN_scorer', 'count': 1, 'zone': 'LEO', 'orbit_km': 600, 'dv_kms': 1.0, 'status': 'aktiv', 'bewaffnet': False}  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.CHN.swarms.CHN_SCORE_MEO: None → {'design': 'CHN_scorer', 'count': 1, 'zone': 'MEO', 'orbit_km': 20000, 'dv_kms': 1.0, 'status': 'aktiv', 'bewaffnet': False}  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.CHN.swarms.CHN_SCORE_HEO: None → {'design': 'CHN_scorer', 'count': 1, 'zone': 'HEO', 'orbit_km': 39000, 'dv_kms': 1.0, 'status': 'aktiv', 'bewaffnet': False}  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.CHN.swarms.CHN_SCORE_SSO: None → {'design': 'CHN_scorer', 'count': 1, 'zone': 'SSO', 'orbit_km': 700, 'dv_kms': 1.0, 'status': 'aktiv', 'bewaffnet': False}  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.CHN.swarms.CHN_SCORE_GEO: None → {'design': 'CHN_scorer', 'count': 1, 'zone': 'GEO', 'orbit_km': 35786, 'dv_kms': 1.0, 'status': 'aktiv', 'bewaffnet': False}  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.CHN.swarms.CHN_RELAIS_GEO: None → {'design': 'CHN_geo_relais', 'count': 2, 'zone': 'GEO', 'orbit_km': 35786, 'dv_kms': 0.0, 'status': 'aktiv', 'bewaffnet': False, 'rolle': '+1 C2-Slot je Stueck (launch_c2 §2.1)'}  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.CHN.economy.resources.c2.slots_total: 12.0 → 14.0  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.CHN.economy.resources.launch.committed_t: 0.0 → 66.0  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.CHN.economy.resources.propellant.lh2.stored_t: 9.9894 → 6.4447  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.CHN.economy.resources.propellant.lox.stored_t: 48.1977 → 43.198  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.CHN.economy.resources.propellant.ch4.stored_t: 19.4357 → 16.1928  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.CHN.economy.resources.launch.restraum_vortrag_t: 400.0 → 334.0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.CHN.economy.resources.launch._vortrag_beleg: {'gilt_fuer_jahr': 2029, 'herkunftsjahr': 2028, 'gestartet_gewichtet_t_2028': 0.0, 'regelref': 'launch_c2.md §5.6 (B-16)'} → {'gilt_fuer_jahr': 2030, 'herkunftsjahr': 2029, 'gestartet_gewichtet_t_2029': 66.0, 'regelref': 'launch_c2.md §5.6 (B-16)'}  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.CHN.economy.resources.launch.committed_t: 66.0 → 0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
▸ Wirtschaft: Produktion 0 t · Upkeep 0 t
▸ Flotte: 0 Einzelschiffe + 7 Schwärme (9 Rümpfe)
▸ Ω-Lage (öffentlich): P_Raum 1500000.0 W · Beleg SETUP: leistungsbuch §6.1, CHN-Zeile (Startbestand Juli 2026, Güte C)
▸ Welt [annihilation] R4-annihilation-noop: übersprungen — keine Nukleareinsätze in der Vorrunde
▸ Welt [kessler] R4-kessler-zerfall: {"mechanik": "K-Z1", "sonnenphase": "mittel", "sonnenfaktor": 1.0, "hoehenfaktor": 1.0, "h
▸ Nächste Befehle fällig für: Jahr 2030
— Dies ist die Stufe-1-Kurzfassung (Standard). Literarischer Vollbericht nur auf Befehl `SITREP LANG` (Eingabe: diese Datei + kompakt.py-View, Deckel 15 KB).
═════════════════════════════════════════
