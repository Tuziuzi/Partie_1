═══ SITREP — CHN — Jahr 2026 ═══
GEHEIM — NUR FÜR CHN

▸ Weltlage: 2 öffentliche Auflösungen (Annihilation/Kessler) — Details unten
▸ Eigene Würfe diese Runde: 3
   · [bau] R1-bz01-CHN-1: {
   · [bau] R1-bz01-CHN-2: {
   · [bau] R1-bz01-CHN-3: {
▸ Gebuchte Änderungen (eigene): 6
   · factions.CHN.economy.resources.industrial.available_t: 40.0 → 0.0  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md §2 + launch_c2.md §1.1/§2.1/§5.2]
   · factions.CHN.economy.resources.industrial.stockpile_t: 100.0 → 44.0  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md §2 + launch_c2.md §1.1/§2.1/§5.2]
   · factions.CHN.economy.resources.launch.committed_t: 0 → 66.0  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md §2 + launch_c2.md §1.1/§2.1/§5.2]
   · factions.CHN.designs.CHN_aufklaerer: None → {'name': 'Aufklaerungssatellit', 'klasse': 'satellit', 'masse_t': 2, 'aufbau': "Sensor 'bis GEO alles aufdecken' 1 t (construction.md §2) + Struktur 1 t", 'bewaffnung': 'keine'}  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md §2 + launch_c2.md §1.1/§2.1/§5.2]
   · factions.CHN.designs.CHN_scorer: None → {'name': 'Scoring-Raumschiff', 'klasse': 'satellit', 'masse_t': 2, 'aufbau': 'Struktur 1 t + 1 t Treibstoff (dv-Reserve fuer Scoring, 1 km/s je Versuch)', 'bewaffnung': 'keine'}  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md §2 + launch_c2.md §1.1/§2.1/§5.2]
   · factions.CHN.designs.CHN_geo_relais: None → {'name': 'GEO-Relais', 'klasse': 'satellit', 'masse_t': 5, 'aufbau': 'launch_c2.md §2.1: GEO-Relais = +1 C2-Slot fuer 5 t nach GEO', 'bewaffnung': 'keine'}  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md §2 + launch_c2.md §1.1/§2.1/§5.2]
▸ Wirtschaft: Produktion 0 t · Upkeep 0 t
▸ Flotte: 0 Einzelschiffe
▸ Ω-Lage (öffentlich): P_Raum 1500000.0 W · Beleg SETUP: leistungsbuch §6.1, CHN-Zeile (Startbestand Juli 2026, Güte C)
▸ Welt [annihilation] R1-annihilation-noop: übersprungen — keine Nukleareinsätze in der Vorrunde
▸ Welt [kessler] R1-kessler-zerfall: {"mechanik": "K-Z1", "sonnenphase": "mittel", "sonnenfaktor": 1.0, "hoehenfaktor": 1.0, "h
▸ Nächste Befehle fällig für: Jahr 2027
— Dies ist die Stufe-1-Kurzfassung (Standard). Literarischer Vollbericht nur auf Befehl `SITREP LANG` (Eingabe: diese Datei + kompakt.py-View, Deckel 15 KB).
═════════════════════════════════════════
