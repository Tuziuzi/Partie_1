# NACHTRAG ZUG 1 (2026) — VOLKSREPUBLIK CHINA (CHN)
**Kampagne SCHWARZE SEE** · Validator **BESTANDEN** · Belege R-Z1-06 bis R-Z1-11

> **Korrektur.** Fünf der sieben ERDE-01-Domänen waren im ersten Durchlauf unaufgelöst im
> Postfach liegen geblieben; die SITREPs haben das nicht ausgewiesen. Hier stehen die
> nachgeholten Ergebnisse. Sie ergänzen den SITREP Zug 1, sie ersetzen ihn nicht.

## Wirtschaft — der teuerste Zug am Tisch
| Posten | Wirkung |
|---|---|
| C-7 I1 Zünderkosten (Ihr Exportverbot) | **−1,5600 Bio USD** (−8 Pp) |
| C-4 EU-Strafzölle E-Autos | −0,1256 Bio USD (−0,7 Pp/a, 7 Jahre) |
| C-4 Huawei-Ausschluss 5G | −0,0695 Bio USD (−0,39 % Niveau) |
| **BIP 2026** | **19,5 → 17,7449 Bio USD (−9,0 %)** |

2027 folgen weitere −4 Pp aus der eigenen Zündung, danach dauerhaft −3 Niveau. Die
EU-Zölle laufen **sieben Jahre** und summieren sich auf −4,9 Pp; ab Zug 4 baut sich die
Wirkung mit −20 % je Zug auf 40 % Restwirkung ab.

Ihr Innenbericht meldet das mit Faktor **1,2834** — also rund 28 % günstiger, als es ist.

## Innenpolitik — die Repressionsfalle
Repression **0,72 → 0,80**. Nach B-2: **9,75 % Kaskadenrisiko je Zug, 64,15 % über zehn
Züge.** Das ist mit Abstand der höchste Wert am Tisch, und Sie haben ihn selbst erhöht.
Ab 2027 zählt zusätzlich die selbst ausgelöste Rezession voll auf den Coup-Track (×1,47).

## Forschung — Safety-Slider auf **0,0**
Fortschritt **1,00**, X-Risk **0,4 % je Zug, 11,33 % über 30 Züge.**
Programme: KI und Rechenzentren, kleine serienmäßige Kernkraftwerke.

## Außenpolitik
Bilaterale Gespräche mit Washington laufen, ohne Brüssel. Russland ist mit Waffen und
Wirtschaftshilfe gestützt und hat sich um +1 verhärtet. EU-spaltende Parteien gefördert —
wirkt auf Brüssels Kaskadenleiste, kein Sofortschaden.

---

## Domänen-Checkliste Zug 1

| Domäne | Status |
|---|---|
| energie | ✅ aufgelöst (EH-01) |
| wirtschaft | ✅ aufgelöst (C-7, C-4, BIP gebucht) |
| innenpolitik | ✅ aufgelöst (B-2 Kaskade) |
| aussenpolitik | ✅ aufgelöst |
| intel | ✅ aufgelöst (D-2 Attribution) |
| militaer | ✅ aufgelöst (kein Gefecht) |
| forschung | ✅ aufgelöst (F-3 Safety) |

**Offen: keine.**

---
*Alle Buchungen unter `truth.buchungen`, alle Rechnungen unter `audit.rechenprotokolle`.*
