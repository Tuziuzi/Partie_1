# SITREP ZUG 2 · 2027 · **INDIEN**
**An:** Jakob · **Von:** GM · **Einstufung:** nur für Indien
Kampagne SCHWARZE SEE · Stand 31.12.2027

---

## 1. Was Ihre Befehle bewirkt haben

**Die Sabotage ist geglückt — und niemand weiß, dass Sie es waren.**
Umfang 5 gegen europäische Pipelineinfrastruktur. Erfolgswurf 319 gegen 390: durch.
Entdeckungswurf 605 gegen 600 — um fünf Punkte an der Aufdeckung vorbei. Kein Blowback.
Brüssel sieht beschädigte Leitungen und hat keinen Täter. Sie haben in Europa etwas zerstört
und stehen sauber da.

**Ihre Entkopplung wurde auf ein Drittel begrenzt** (Spielerentscheid). Statt eines vollen
C-7-Totalabbruchs trennen Sie Technologie, Energie und Rüstung und lassen den Rest laufen.
Zünderpreis: **−2,7 Prozentpunkte Wachstum 2027**, −1,33 Pp 2028, danach dauerhaft −1,0 Niveau.
Das Freihandelsabkommen bleibt formal in Kraft, während Sie es aushöhlen.

**Die Sanktion war so nicht zu haben.** »UN umfassend« braucht eine Ratsresolution; Frankreich
sitzt dort mit Veto und gehört zum Ziel. Herabgestuft auf unilateral: 1W5 = 5 → **−0,9 Pp/a auf
die EU, sieben Jahre**, das obere Ende der Spanne. Ab Zug 4 sucht Brüssel Ersatzhandel.

**Ihr BIP: 4,3000 → 4,1839 Bio USD (−2,70 Pp).** Rezessionsflag −0,089, Coup-Track ×1,47
(2,94 %/Zug, kein Putsch).

---

## 2. Was Sie über die anderen wissen

**China hat Sie ausspioniert — und Sie haben es gemerkt.**
Eine chinesische Beschaffungsoperation gegen indische Industrie, getarnt als europäische.
Sie ist **gescheitert und aufgeflogen**. Ihre Gegenspionage hat die falsche Flagge
durchschaut: Attribution **C3** (Score 10,8). Sie dürfen China öffentlich benennen.
Ein Eskalationsrecht haben Sie nicht — dafür bräuchten Sie B2, und genau diese drei Punkte
hat die falsche Flagge gekostet.

Im selben Jahr stationiert Peking **50 Sprengköpfe** bei Ihnen. Ihr Patron teilt sein Arsenal
mit Ihnen und bricht bei Ihnen ein. Beides gleichzeitig, beides absichtlich.

**China hat sich schwer verwundet.** Der Finanzschlag gegen Europa — Fire-Sale europäischer
Staatsanleihen plus Konfiskation europäischer Fabrikationsanlagen — hat eine eigene Bankenkrise
ausgelöst (Doom-Loop-Wurf 13 ≤ 16). Chinas BIP fällt von 17,74 auf **16,01 Bio USD (−9,8 Pp)**,
Kapitalmarktausschluss zehn Züge, Risikoaufschlag +2 Pp dauerhaft. Ihr Patron ist der
schwächste Patron, den Sie je hatten.

**Die EU hat China öffentlich benannt**, Güte A1, vor dem Europäischen Rat und in der WTO —
als Rechtsgrundlage der laufenden Strafzölle. Die Attribution gegen **Indien**, die Brüssel
seit Zug 1 in der Hand hält, hat es **nicht** gezogen.

**Energie 2027:** EU 68,3 · USA 56,0 · Russland+Rest 53,5 · China 46,7 · **Indien 45,8.**
**Welt:** 429,4 ppm · +1,3656 °C · Biosphäre 98,92.

---

## 3. Ihr Bodenkonto

| Posten | Einsatz | Wirkung |
|---|---|---|
| Geheimdienste 80 % | **503,0 t** | 8 Operationsslots (Deckel; 12 % hätten gereicht) |
| Sprengköpfe 9 | 90,0 t | zu P0-Preis 10 t/Stück — China zahlt 5 t |
| **Summe** | **593,0 t** von 628,8 t | 35,8 t verfallen (Z-1.4, Fluss statt Bestand) |

Die 503 t haben trotzdem etwas gekauft: Sie gewinnen den Tonnenvergleich gegen Chinas 263,7 t
und damit das zusätzliche Erd-Scoring — es hat den **Infowar-Punkt** auf Earth Surface geholt.

**Doktrin:** deklariert war `ersteinsatz_begrenzt` — zwei Stufen auf einmal. E-2.1 erlaubt eine.
Von NFU aus steht Indien jetzt auf **`ambiguitaet`**. Die begrenzte Ersteinsatzoption ist ab
Zug 3 erreichbar.

**Repression 0,4 → 1,0.** Ihr Kaskadenrisiko springt von 3,75 % auf **12,75 % pro Zug**
(74,4 % über zehn Züge). Der Wurf dieses Jahres — 2805 gegen 1275 — ging gut aus. Die
Repressionsfalle B-2 macht den Weg zurück teurer als den Weg hinein.

---

## 4. Rechenwerk und Forschung

Ihre 3 Rechenpunkte liegen vollständig im Training: g_T 0,775, X-Risk 0,0031/Zug.
**Das Operationskonto steht auf 0** — das kostet −1 Initiative und −1 auf Duelle je zwei
fehlende Slots (launch_c2 §3.2). Bei drei C2-Slots hätten 0,06 RP gereicht.

Spionageerträge, gebucht auf Ihr Beutekonto: **0,2375 JB offen.**
Der Nachbau des chinesischen Trägerraketenwracks lief schlecht — 1W6 = 1, Erhaltungsgrad nur
0,25, macht 0,0625 JB über zwei Züge. Die US-Lizenz für moderne Sprachmodelle bringt 0,175 JB,
Decke 0,7 E₀, politischer Preis: Bündnisbindung und Auflagen.

Keine Techstufe offen — L1 öffnet erst 2035/36.

---

## 5. Orbit

Vier SPADEX-Rümpfe aktiv: 2 × LEO 460 km, 2 × SSO 700 km. Nichts gestartet, nichts gebaut.
Ihre gesamte Startkapazität von 40 t/a bleibt stehen und geht als **voller Vortrag ins
Bodenkonto 2028** — das hebt Ihr Konto gegenüber 2027 um 1,032 t.

**Scoring:** keine Zone gescored. Scoring verlangt ein Asset, das 1 km/s Δv aufwendet; Ihre
SPADEX führen 0,15 km/s. Präsenz allein kontrolliert keine Zone.

**Earth Surface ging an die USA, 2:1.** Militärpunkte USA (678 SP gegen Ihre 219),
Eskalationsdominanz USA (Washington hat den Halbleiterhebel ungezogen gelassen, während China
und Sie beide Munition verbraucht haben), Infowar Indien. Serie USA 1.

---

## 6. Domänen-Checkliste Zug 2

| Domäne | Status |
|---|---|
| energie | aufgelöst |
| wirtschaft | aufgelöst |
| innenpolitik | aufgelöst |
| aussenpolitik | aufgelöst |
| intel | aufgelöst |
| militaer | aufgelöst |
| forschung | aufgelöst |

WN-01-Validator: **BESTANDEN** (0 Fehler, 0 Warnungen, 3 Hinweise).
