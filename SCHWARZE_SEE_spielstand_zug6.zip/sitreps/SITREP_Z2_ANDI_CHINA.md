# SITREP ZUG 2 · 2027 · **CHINA**
**An:** Andi · **Von:** GM · **Einstufung:** nur für China
Kampagne SCHWARZE SEE · Stand 31.12.2027

> **Hinweis zur Berichtslage.** China ist ein Einparteienstaat. Was in diesem SITREP aus dem
> eigenen Apparat kommt, ist **geschönt** (Bias-Funktion B-1, Repression 0,80, Medienfreiheit
> 0,20 → Faktor 1,285). Was von außen kommt, ist ungeschönt. Der Unterschied ist Teil des Spiels
> und wird nicht aufgelöst.

---

## 1. Der Finanzschlag

Sie haben gezündet: Fire-Sale europäischer Staatsanleihen **und** Konfiskation europäischer
Fabrikationsanlagen in China. Das ist C-7 Zündstufe **I2**, zusätzlich zum I1 aus Zug 1.

**Implosionspunkte 2,9** (I1 Handel 1,4 + I2 Marktgewicht 1,0 + Fire-Sale 0,5).
Der Fire-Sale zählt nur halb: die EZB ist eine harte Notenbank und kauft dagegen — *buyer of
last resort*. **Direktschaden am Ziel: null.**

Kaskadenwurf gegen Schwelle 5,6: **2W10 = 12. Keine globale Kaskade.** Die Zündung bleibt
aktiv, der Wurf wiederholt sich in Zug 3 mit rund 10 Prozent.

**Der Rückschlag.** Doom-Loop-Wurf 13 ≤ 16: **eigene Bankenkrise.** Der I2-Gesamtschaden
steigt von −5 auf −9,5 Pp.

| | |
|---|---|
| Nachwirkung I1, Jahr 2 | −4,0 Pp |
| I2 mit Bankenkrise, Anteil 2027 | −5,7 Pp |
| EU-Strafzölle (laufend) | −0,7 Pp |
| DW-01 Rechenzentren, Zivilkonto | +0,6 Pp |
| **BIP-Wachstum 2027** | **−9,8 Pp** |

**Wahrer Stand: 17,7449 → 16,0059 Bio USD.**
*Interne Meldung an die Führung: −7,6 Pp.* Der Apparat rundet Ihnen den Schaden weg.

Dazu: Kapitalmarktausschluss zehn Züge, Risikoaufschlag +2 Pp auf jede Refinanzierung
dauerhaft, Kreditklemme zwei Züge. Kapitalintensive Programme laufen auf halber Wirkung.

---

## 2. Was Ihnen entgegenschlägt

**Brüssel hat Sie öffentlich benannt.** Attribution der Güte **A1**, vor dem Europäischen Rat
und in der WTO, als Rechtsgrundlage der Strafzölle. Das ist die höchste Stufe — nicht Verdacht,
sondern Feststellung. Ab A1 steht der EU auch ein Eskalationsrecht zu; sie hat es diesmal
nicht gezogen.

**Ihre Operation gegen Indien ist gescheitert.** Beschaffungswurf 449 gegen 390. Kein Ertrag,
Kosten bleiben. Die Residentur meldet die Operation als abgebrochen und die falsche Flagge als
gehalten.

**Indien ist in wirtschaftlicher Notwehr.** Neu-Delhi entkoppelt sich teilweise von Europa,
verhängt eigene Sanktionen gegen Brüssel und hat die Repression im Inland auf das Maximum
gezogen. Indiens BIP fällt auf 4,1839 Bio (−2,7 Pp).

**Energie 2027:** EU 68,3 · USA 56,0 · Russland+Rest 53,5 · **China 46,7** · Indien 45,8.
Ihre Abregelung 1,05 %. **Welt:** 429,4 ppm · +1,3656 °C · Biosphäre 98,92.

---

## 3. Boden und Arsenal

| Posten | Einsatz | Wirkung |
|---|---|---|
| Geheimdienste 10 % | 263,7 t | 7 Operationsslots |
| Force Projection 8 % | 211,0 t | a_max in BD-01 §10 |
| Modernisierung 8 % | 211,0 t | Tonnenvergleich unbestritten gewonnen |
| Advanced 99 Punkte | 99,0 t | Präzisionsleiter, kein Deckel |
| State-of-the-Art 8 Pp | 80,0 t | Hochtechnologie |
| Future 10 SP | 100,0 t | Hochtechnologie |
| Sprengköpfe 20 | 100,0 t | **P4-Preis 5 t/Stück** — halber Erdpreis |
| **Summe** | **1 064,7 t** von 2 636,9 t | 1 572,2 t verfallen (Z-1.4) |
| Hochtechnologie | 280,0 t von 395,5 t | Deckel gehalten |

**Ihre Serienfertigung ist die beste der Welt.** 700 kumulierte Stück bringen Sie auf BZ-01
Stufe P4: 5 t je Sprengkopf gegen Indiens 10 t, Kadenz frei, Bauzeit 0,4 Jahre. Die 20 Köpfe
sind noch dieses Jahr fertig.

**Aufwertung Z-2d:** Modernisierung, Advanced und Future gelten je Runde für **eine**
Teilstreitkraft. Ziel war SAM → Kategorie **future**, q 1,40. Ihre Luftverteidigung ist damit
die modernste Teilstreitkraft im Spiel.

**Ihr Programmschritt L2 → L3 ist nichtig.** China ist seit 1964 Kernwaffenstaat und steht
bereits auf L3. Die Tonnage wurde nicht gebucht.

**Proliferation.** 50 Sprengköpfe unter nuklearer Teilhabe nach Indien verlegt (Deckel 10 %
von 700 gehalten). Eigentum bleibt bei China, Zweitschlüssel bei Ihnen, jeder Einsatz zählt
als **Ihr** Einsatz — für Verbote wie für Annihilationsrechnung. E-2-Ereignis »Stationierung«,
öffentlich.

**Doktrin** eine Stufe von NFU auf `vergeltung_nur`.

**Kaskadenrisiko** 9,75 %/Zug (Wurf 5221 — ruhig). **Coup-Track** 1,76 %/Zug mit
Rezessionsmultiplikator ×1,47, der ab diesem Zug voll zählt.

---

## 4. Rechenwerk

**Ihr Blatt 4 trug keine Zuteilung.** DW-01 Schritt 3 verlangt sie vor der Handlungsphase,
verbindlich für die Runde. Der GM hat sie aus Ihren Blatt-1/2-Befehlen abgeleitet
(»KI-Ausbau und Rechenzentren forcieren«, Forschung auf KI, Chips, Rechenzentren):

**T 14 · F 3 · O 1 · Z 2 · D 0** von 20 RP.

- **T 14** = 14 % Weltanteil → g_T **1,673**, der höchste Wert der Welt. X-Risk 0,0067/Zug.
- **F 3** = Stufe 2 → −20 % Forschungszeit.
- **O 1** deckt alle 12 C2-Slots vierfach: Slotkosten −1 Stufe, +1 Diskriminierung.
- **Z 2** = Stufe 2 → +0,60 % BIP/a (in der Bilanz oben enthalten).
- **D 0** — kein Datenkonto. Solange kein Trainingslauf ansteht, kostet das nichts; sobald
  einer ansteht, drückt g_D auf alles, was g_T tut.

**Widersprechen Sie in Zug 3, wenn das nicht Ihre Absicht war.** Die Auslegung ist als solche
gebucht, nicht als Ihre Entscheidung.

---

## 5. Orbit

Die drei Neuentwürfe aus Zug 1 — 2 Aufklärer, 5 Scorer, 2 GEO-Relais — bleiben **im Bau bis
2029**. Was bindet, ist die Stückzeit (Satellit 1,0 a × P0n-Zeitfaktor 3,0), nicht die Werft:
Ihre Fertigungslinie ist frei, die 40 t Jahreskapazität sind unangetastet.

Nichts gestartet. Startkapazität 400 t/a bleibt stehen, voller Vortrag ins Bodenkonto 2028.
Boiloff kostet Sie 8,5 t LH2, 6,2 t LOX, 4,7 t CH4.

**Earth Surface ging an die USA, 2:1** (Militärpunkte USA, Eskalationsdominanz USA, Infowar
Indien). Ihr Gefechtswert mit der SAM-Aufwertung: 486,4 gegen 678 der USA. Serie USA 1.

---

## 6. Domänen-Checkliste Zug 2

| Domäne | Status |
|---|---|
| energie | aufgelöst |
| wirtschaft | aufgelöst |
| innenpolitik | aufgelöst |
| aussenpolitik | aufgelöst |
| intel | aufgelöst |
| militaer | aufgelöst |
| forschung | aufgelöst |

WN-01-Validator: **BESTANDEN** (0 Fehler, 0 Warnungen, 3 Hinweise).

**Zwei Blattbefunde für Zug 3:** Sie haben das alte Rev.-B-Blatt 3 verwendet — die Zeile
»Kategorie je Teilstreitkraft« gibt es nicht mehr, sie wurde gelesen und **nicht gebucht**
(V19). Und die Bodenbrücke-Zeile Arktis/E-1 blieb ohne Kontingentanteil `a`, der vor dem
Gefecht feststehen muss (V14) — ohne Krieg im Norden lief sie ohnehin ins Leere.
