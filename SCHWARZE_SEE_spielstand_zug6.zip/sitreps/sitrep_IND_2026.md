═══ SITREP — IND — Jahr 2026 ═══
GEHEIM — NUR FÜR IND

▸ Weltlage: 2 öffentliche Auflösungen (Annihilation/Kessler) — Details unten
▸ Eigene Würfe diese Runde: 1
   · [bau] R1-bz01-IND-1: {
▸ Gebuchte Änderungen (eigene): 6
   · factions.IND.economy.resources.industrial.available_t: 4.0 → 1.42  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md + launch_c2.md §5.2 + schwarm.md (E13) + OW-01 systemkatalog.md]
   · factions.IND.economy.resources.launch.committed_t: 0 → 1.032  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md + launch_c2.md §5.2 + schwarm.md (E13) + OW-01 systemkatalog.md]
   · factions.IND.economy.resources.c2.slots_committed: 0 → 2  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md + launch_c2.md §5.2 + schwarm.md (E13) + OW-01 systemkatalog.md]
   · factions.IND.designs.IND_SPADEX: None → {'name': 'SPADEX Zwillingsbund', 'klasse': 'kleingeraet', 'quelle': 'OW-01 systemkatalog.md', 'dryMass_t': 0.2403, 'propellantMass_t': 0.0173, 'nassMasse_t': 0.258, 'isp_s': 220, 'dv_total_kms': 0.15, 'bewaffnung': 'keine', 'faehigkeiten': ['autonomes Docking', 'Lidar', 'Strahlungshaertung']}  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md + launch_c2.md §5.2 + schwarm.md (E13) + OW-01 systemkatalog.md]
   · factions.IND.swarms.SDX-LEO: None → {'design': 'IND_SPADEX', 'count': 2, 'zone': 'LEO', 'orbit_km': 460, 'dv_kms': 0.15, 'status': 'aktiv', 'bewaffnet': False}  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md + launch_c2.md §5.2 + schwarm.md (E13) + OW-01 systemkatalog.md]
   · factions.IND.swarms.SDX-SSO: None → {'design': 'IND_SPADEX', 'count': 2, 'zone': 'SSO', 'orbit_km': 700, 'dv_kms': 0.15, 'status': 'aktiv', 'bewaffnet': False}  [werkbuch-bauzeiten:regeln.md §1-§3 + construction.md + launch_c2.md §5.2 + schwarm.md (E13) + OW-01 systemkatalog.md]
▸ Wirtschaft: Produktion 0 t · Upkeep 0 t
▸ Flotte: 0 Einzelschiffe + 2 Schwärme (4 Rümpfe)
▸ Ω-Lage (öffentlich): P_Raum 210000.0 W · Beleg SETUP: leistungsbuch §6.1, IND-Zeile (Startbestand Juli 2026, Güte C)
▸ Welt [annihilation] R1-annihilation-noop: übersprungen — keine Nukleareinsätze in der Vorrunde
▸ Welt [kessler] R1-kessler-zerfall: {"mechanik": "K-Z1", "sonnenphase": "mittel", "sonnenfaktor": 1.0, "hoehenfaktor": 1.0, "h
▸ Nächste Befehle fällig für: Jahr 2027
— Dies ist die Stufe-1-Kurzfassung (Standard). Literarischer Vollbericht nur auf Befehl `SITREP LANG` (Eingabe: diese Datei + kompakt.py-View, Deckel 15 KB).
═════════════════════════════════════════
