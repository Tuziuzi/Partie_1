# SITREP ZUG 4 · 2029 · **CHINA**
**An:** Andi · **Von:** GM · **Einstufung:** nur für China
Kampagne SCHWARZE SEE · Stand 31.12.2029

> **Berichtslage — Änderung.** Bis zu diesem Zug war alles Interne geschönt (Bias-Funktion
> B-1). Das ist vorbei; warum, steht in §3. Dieser Bericht ist ungeschönt.

---

## 1. Der Weltraum gehört Ihnen

Die neun Entwürfe aus Zug 1 sind fertig geworden und **alle gestartet**. Nach B-16 wird die
Startkapazität erst im Fertigstellungsjahr gebunden — Ihre 400 t/a standen bereit:

| Auftrag | Zone | zonengewichtet |
|---|---|---|
| 2 × Aufklärer | LEO | 4,0 t |
| 5 × Scorer | LEO · MEO · HEO · SSO · GEO | 22,0 t |
| 2 × GEO-Relais | GEO | 40,0 t |
| **Summe** | | **66,0 t von 400,0 t** |

**Sie haben alle fünf Zonen gescort.** Jeder Scorer trägt 1 t Treibstoff = genau 1 km/s, also
einen Versuch — Sie haben ihn beim Bau richtig eingeplant. Unbestritten: Indiens SPADEX führen
nach einem gescheiterten Rammversuch noch 96 m/s, die Schwelle liegt bei 1 000.

**LEO · MEO · HEO · SSO · GEO — fünf Zonen, fünf Punkte.**

Dazu: Ihre zwei Aufklärer decken ab sofort **jedes Bahnobjekt bis GEO** auf. Die zwei
GEO-Relais heben Ihre C2-Slots von 12 auf **14**.

**Rundenstand: China 5, USA 3.** Sie sind eindeutiger Rundensieger. **Serie 2.**
Noch **eine** Runde bis »Krieg gewonnen« — und die zahlt sich mit einem freien
Forschungsdurchbruch aus, timelinefrei, ohne auf 2035 zu warten.

---

## 2. Der Deckel hat zum zweiten Mal gekürzt

Bestellt: 99 Future-SP (990 t), 10 ASAT (200 t), 20 Sprengköpfe (100 t), 8 Pp State-of-the-Art
(80 t) — zusammen **1 370 t** gegen eine Tranche von **350,9 t**.

Gekürzt in Blattreihenfolge (HE-16), weil wieder keine Rangfolge daraufstand:

| Posten | gewünscht | gebucht |
|---|---|---|
| State-of-the-Art (§16) | 80,0 t | **80,0 t** |
| Future-SP (§17) | 99 | **27** |
| ASAT (§17) | 10 | **0** |
| Sprengköpfe (§17) | 20 | **0** |

Das ist das zweite Jahr in Folge, in dem ASAT und Sprengköpfe hinten herunterfallen. **Eine
Zeile »Rangfolge« auf dem Blatt ändert das.** Wenn Ihnen ASAT wichtiger ist als Future-SP,
schreiben Sie es hin — der GM kürzt sonst nach Druckreihenfolge, nicht nach Absicht.

Das ganze Konto (2 339,2 t): 280,7 t Geheimdienste (8 Slots) · 280,7 t Force Projection ·
233,9 t Modernisierung · 99 Advanced-Punkte · 350,0 t Hochtechnologie. **1 094,9 t verfallen.**

**Aufwertung: Ihre Marine auf »future«** (q 1,40). Sie haben damit **drei von vier**
Teilstreitkräften auf dem Höchstwert — Heer, SAM, Marine. Gefechtswert 563,5 gegen 625,9 der
USA; der Abstand ist auf 62 Punkte geschmolzen.

**Doktrin** `nfu` → `ambiguitaet` (+1).

**Alle drei Tonnenvergleiche haben Sie verloren.** Ab diesem Zug führen alle Fraktionen ein
Bodenkonto (HE-19), und die USA haben mit 7 463,6 t das dreifache Ihres. Geheimdienste
746,4 gegen Ihre 280,7. Force Projection 447,8 gegen 280,7. Modernisierung 746,4 gegen 233,9.
Die zwei automatischen Erd-Scorings, die Ihnen zwei Züge lang kampflos zufielen, sind weg.

---

## 3. Die Kaskade

**Nach vier Jahren mit 9,75 Prozent Risiko je Zug ist der Wurf gefallen: 258 gegen 975.**

Das ist B-2, die Repressionsfalle. Repression hebt die *geäußerte* Zustimmung und senkt die
*tatsächliche* im gleichen Maß; sie vergrößert die Lücke, und irgendwann bricht die Lücke
zusammen — binnen eines Zuges, auf den wahren Wert. Die Regel sieht ausdrücklich vor, dass der
Autokrat **keine Vorwarnung** bekommt. Sie haben keine bekommen.

Die unmittelbare Folge steht oben im Kopf dieses Berichts: **Ihr Apparat kann Sie nicht mehr
schönen.** Die Bias-Funktion ist gebrochen, weil die Lücke öffentlich geworden ist. Ab sofort
lesen Sie dieselben Zahlen, die der GM führt.

Wirtschaftlich buche ich **−2,0 Prozentpunkte** — und das ist eine GM-Bemessung ohne
Regeltafel, die ich ausdrücklich als **Regellücke RG-Z4-01** melde: B-2 sagt, die Zustimmung
bricht auf den wahren Wert, aber diese Kampagne hat nie einen Zustimmungswert geführt. Die
Zahl ist revidierbar, sobald am Tisch entschieden wird, wie tief eine Kaskade schneidet.

**Wirtschaft: 15,3817 → 15,0587 Bio USD (−2,10 Pp).** Die I2-Bankenkrise ist mit −9,5 Pp über
zwei Jahre abgeschrieben; es bleiben EU-Zölle (−0,7), Zivilkonto (+0,6) und die Kaskade (−2,0).
Kapitalmarktausschluss noch sieben Züge. Ihre C-7-Zündung ist weiter aktiv — vierter
Kaskadenwurf, Wurf 11 gegen 5,6, wieder vorbei.

---

## 4. Nachrichtendienstlich Ihr bestes Jahr

- **Sabotage gegen die USA: geglückt und UNENTDECKT** (Wurf 368, diesmal ohne falsche Flagge).
  Washington weiß nicht einmal, dass es passiert ist — und benennt im selben Zug öffentlich
  die Sabotage des Vorjahres. Deren Blowback ist mit 993 gegen 450 verpufft.
- **Zwei Nachbau-Käufe**, ASML und NVIDIA, über Mittelsmänner statt über Agenten:
  Erhaltungsgrad 1,0, **je 0,25 JB über zwei Züge**, keine Entdeckung, keine Attribution.
  **0,50 JB zusammen — der größte Beuteertrag der Partie.** Gekauft, nicht gestohlen.
- Jemand hat versucht, Ihre Trägerraketentechnik abzugreifen. Entdeckt, Attribution D4 —
  nicht benennbar.

**Rechenwerk: Sie holen sich die KI-Führung zurück.** T 20 von 20 RP, g_T **2,00** — der
Deckel. Von 0,894 im Vorjahr, an den USA (1,414) vorbei. Der Preis ist vollständig: kein
Forschungsrabatt, kein Zivilkonto, kein Operationskonto für vierzehn C2-Slots, X-Risk auf
dem Maximum. Prüfer P1.

---

## 5. Die Lage

Die USA haben Sie öffentlich als Urheber der Sabotage von 2028 benannt (C3), **auf das
Eskalationsrecht ausdrücklich verzichtet** und einen Zwischenfallkanal angeboten. Der
Halbleiterhebel bleibt zum dritten Mal ungezogen — demonstrativ im selben Zug.

Indien steht auf der obersten Doktrinstufe (`de_eskalationsschlag`) und hat einen offenen,
für alle sichtbaren Rammversuch gegen einen deutschen Aufklärungssatelliten unternommen —
gescheitert, aber bei Güte A1 attributierbar. Ihr Bündnispartner eskaliert sichtbar und
erfolglos.

**Energie:** EU 69,8 · USA 58,4 · Russland+Rest 56,0 · **China 48,1** · Indien 47,9. Ihre
Abregelung steigt auf 3,25 %. **Welt:** 436,0 ppm · +1,4131 °C · Biosphäre 97,71.

**Für Zug 5:** Ihre Startkapazität 2030 trägt einen Vortrag von 334,0 t statt 400 — die
66 geflogenen Tonnen fehlen dem Bodenkonto. Das ist Z-1.5: zwei Ausgänge, eine Tonne.

---

## 6. Domänen-Checkliste Zug 4

| Domäne | Status |
|---|---|
| energie · wirtschaft · innenpolitik · aussenpolitik · intel · militaer · forschung | **alle aufgelöst** |

WN-01-Validator: **BESTANDEN** (0 Fehler, 0 Warnungen, 3 Hinweise).
