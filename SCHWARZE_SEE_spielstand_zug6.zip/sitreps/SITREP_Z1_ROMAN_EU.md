# SITREP ZUG 1 — EUROPÄISCHE UNION (EU)
## Lagebild aus Berliner Sicht
**Kampagne SCHWARZE SEE · Jahr 2026 abgeschlossen · nächster Zug: 2027**
Spieler: Roman · WN-01-Validator: **BESTANDEN** (0 Fehler)

---

## 1. Der wichtigste Vorgang des Jahres

**Zwei fremde Mächte haben in diesem Jahr verdeckt gegen die Union gearbeitet.
Ihre Dienste haben beide aufgeklärt.**

| Akteur | Operation | Attributionsgüte | Folge |
|---|---|---|---|
| **China** | Sabotage, massive Hackerangriffe | **A1** | öffentliche Benennung erlaubt · Eskalation erlaubt |
| **Indien** | Einflussoperation, Psyop über ein Kulturinstitut, **unter falscher Flagge** | **B2** | öffentliche Benennung erlaubt · Eskalation erlaubt |

**A1** ist die Spitze der Admiralty-Skala: völlig zuverlässige Quelle, bestätigte
Information. Bei Peking gibt es keinen Zweifel und keine Ausrede.

**B2** bei Indien ist fast so gut — und bemerkenswerter, denn Neu-Delhi hat unter
**falscher Flagge** gearbeitet. Die Täuschung ist durchschaut. Jakob weiß, dass Sie es
wissen.

Das ist Ihr Regimevorteil in Reinform: Repression 0,08, Medienfreiheit 0,88 — offene,
wache Institutionen. Ihr Apparat meldet Ihnen die Wahrheit, und er sieht viel.

**Was Sie damit tun, ist die Entscheidung des Jahres.** Beide Länder sind Demokratien
beziehungsweise Handelspartner, denen Sie im selben Zug Angebote gemacht haben — Indien
sogar ein Freihandelsabkommen. Sie können benennen, eskalieren, still verhandeln oder das
Wissen als Faustpfand behalten.

---

## 2. Ihre eigenen Befehle

Alle sechs Befehlszeilen und sechs Freitextvorgänge liegen im Postfach und werden in der
Auflösung der Außen-, Innen- und Militärdomäne wirksam: Huawei-Ausschluss aus dem
5G-Netz, Strafzölle auf chinesische E-Autos, AfD-Verbotsprüfung im Bundesrat,
Freihandelsangebot an Indien, Beitrittsangebot an Kanada, Ausbau der europäischen
NATO-Struktur, Nukleargespräche mit Frankreich, deutsch-französisches Trägerprogramm
statt FCAS, Ostsee-Überwachung, Frontex-Stärkung, Schließung des Russischen Hauses und
die TAURUS-Drohung an Moskau.

**Befund V9 — Memorandum.** Ihr Förderprogramm für **dual-use**-Weltraumtechnologie
(Schwerpunkt Ariane) steht neben dem gemeinsamen Memorandum Zug 1, das wörtlich lautet:
*»Keiner schießt Militär- oder Dual-use-Güter ins All.«*

Der Befehl wurde **ausgeführt, nicht zurückgewiesen** — das Memorandum verbietet den
**Start**, nicht die Entwicklung. Aber alle drei Postfächer haben den Befund bekommen,
damit die Absprache nicht durch die Hintertür erodiert. Vor dem ersten Start eines
dual-use-Trägers sollten Sie das Memorandum ausdrücklich erneuern oder aufkündigen.

**Delta V:** kein Bauauftrag. Ein Förderprogramm ist Forschung, keine Stückfertigung —
keine Bauzeit, keine Startmasse. Ihre 5 t Jahresfertigung und 11 t Lager sind unangetastet,
alle 8 C2-Slots frei, 45 t/a Startkapazität ungenutzt.

---

## 3. Energie (Block EU, von Ihnen geführt) — der beste Block der Welt

| Kennzahl | EU | zum Vergleich |
|---|---|---|
| Primärenergie | 53,8 EJ | China 162,3 · Indien 36,2 |
| Versorgung | 99,0 | alle anderen 100 |
| **Klima** | **48,1** | USA 29,2 · ROW 22,0 · China 10,1 · Indien 8,2 |
| Nachhaltigkeit | 62,1 | bester Wert |
| **Gesamtscore** | **67,6** | **Platz 1 von 5** |

Die Vorwahl »erneuerbar« bei 100 % Budget hat funktioniert. Klima 48,1 ist mehr als das
Vierfache des chinesischen Werts.

Zwei Warnzeichen:

⚠️ **Abregelung 0,99 %** — Marktabregelung, keine Zwangsrationierung. Kein
Legitimitätsabzug, aber Preis- und Industriedrosselung. Das ist die Kehrseite von viel
Erneuerbarem ohne genug Speicher und Netz.

⚠️ **Rezessionsflag.** Ihre Reservemarge liegt bei **−0,1123** gegen eine Schwelle von
−0,03 — der schlechteste Wert am Tisch, deutlicher als bei Indien (−0,0518). Sie fahren
Ihr System ohne Puffer. Als Demokratie haben Sie keinen Coup-Track, aber wirtschaftlich
beißt es.

*Und die rote Zeile von Blatt 2 bleibt: eine Technologie lässt 18–34 % ungedeckt, sieben
nebeneinander nur 2,3 %. **Breite schlägt Rangfolge** — auch bei Erneuerbaren.*

---

## 4. Weltlage 2026 → 2027

| | 2025 | 2026 |
|---|---|---|
| CO₂ | 422,8 ppm | **426,1 ppm** |
| ΔT | 1,30 °C | **1,3421 °C** |
| Biosphäre B | 100 | **99,47** |

Die Atmosphäre ist geteilt: Ihr sauberer Zubau schützt Sie nicht vor dem ppm der anderen.
Das ist die Trittbrettfahrer-Klemme, und sie ist Ihr strukturelles Problem.

**Scoring:** niemand hat kΔv ausgegeben — kein Schiff im Orbit. Remis an der Spitze, alle
Serien bei 0.

**Weltereignis:** 2W10 fiel auf **2** (1+1). `ereignisse.md` führt unter »Ereignistafel«
nur die Konvention, **keine Ergebniszeilen** — **REGELLÜCKE**, gemeldet statt geschätzt.

**Kriegswirtschaft:** Sie bleiben Vasall der KI-geführten USA, 1 freier Schritt von 2.
Die L1-Tech »Umbau der heimischen Wirtschaft« ist weiter der Weg zur strategischen
Autonomie.

---

## 5. Für Zug 2

- **Zwei Attributionen in der Hand.** Benennen, eskalieren, verhandeln oder aufheben.
- **Rezessionsflag −0,1123.** Reservemarge und Speicher gehören ins Energiebudget.
- **Kein Kilogramm im Orbit**, während Indien schon vier Rümpfe oben hat und China 24 t
  in der Werft. Mit 45 t/a Startkapazität und 8 C2-Slots haben Sie die zweitbeste
  Infrastruktur am Tisch und nutzen nichts davon.
- **Memorandum klären**, bevor Ariane dual-use fliegt.
- Freihandelsangebot an Indien liegt bei Jakob auf dem Tisch — dieselbe Woche, in der Sie
  seine Psyop aufgedeckt haben.

---
*Fog of War: dieser Bericht enthält keine verdeckten Daten anderer Fraktionen. Alle Würfe
und Rechnungen liegen im Journal, Belege W-001-0001 ff. und R-Z1-01 ff.*
