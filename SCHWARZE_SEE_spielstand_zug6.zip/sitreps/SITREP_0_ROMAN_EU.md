# SITREP 0 — EUROPÄISCHE UNION (EU)
## Lagebild aus Berliner Sicht

**Kampagne:** SCHWARZE SEE · **Zug 1 · Jahr 2026** · Spieler: **Roman**
**Skala:** orbital · Module: Delta V + ERDE-01 + EH-01 (Energie) + OB-01/C-9
**Status:** WN-01-Validator **BESTANDEN** — Zustellung freigegeben

*Abkürzungen beim ersten Auftreten erklärt; danach als bekannt vorausgesetzt.*
*SITREP = Situation Report, Lagebericht. Δv (Delta v) = Geschwindigkeitsänderungs-
budget eines Raumfahrzeugs in km/s. LEO = Low Earth Orbit, niedrige Erdumlaufbahn.
GEO = geostationärer Orbit, 35.786 km. C2 = Command and Control, Führung.*

---

## 0. Ihre Rolle — festgelegt, nicht ausgelost

Sie führen die **Europäische Union** aus **deutscher Perspektive**. Das ist ein
**Erzählrahmen, keine Sonderregel**: Ihre Lagebilder kommen aus Berliner Sicht,
Ihre EU-Entscheidungen werden als deutsche Koalitionspolitik erzählt und begründet.
Es gibt dafür keine zusätzliche Mechanik, keinen Kohäsionswurf, keine neue Leiste.
ERDE-01 kennt als Spielobjekt nur den Staat `eu` — Deutschland ist die Kamera,
nicht die Figur. (Protokolliert als Hausentscheidung 2 im Spielstand.)

---

## 1. Ihre Regimeform — das ist Ihre Kernmechanik

Sie führen **die Regierung als Kollektiv**, nicht eine Person.

| | Wirkung |
|---|---|
| **Ihr Lagebild ist ehrlich** | Was Ihr Apparat meldet, entspricht der Wahrheit. Keine geschönten Innenberichte — anders als bei Ihrem chinesischen Gegenüber. |
| **Ihr Lagebild ist öffentlich** | Ihre Zahlen sind für andere leicht greifbar. Sie haben keine Überraschung im Rücken. |
| **Kein Coup-Risiko** | Ihre Führung fällt nicht über Nacht. Dafür entscheiden Sie langsamer als eine Autokratie. |

**Ihre Regimeparameter — die saubersten am Tisch:** Repression **0,08** ·
Medienfreiheit **0,88** · Personalismus **0,10** · Parteidominanz **0,10** ·
Militärherrschaft **0,10**. Kein anderer Spieler startet so weit von der
Regimekippe entfernt. Das ist Ihre eigentliche Reserve: Sie können Druck aushalten,
ohne ins Autoritäre zu rutschen.

- **Doktrin:** `nfu` — No First Use (nuklearer Erstschlagverzicht)
- **Persönlichkeit:** Status quo
- **Kernwaffen:** ja (französische Force de dissuasion im EU-Rahmen)
- **Rüstungsquote 2026:** 1,9 % BIP (EU-Mitgliedstaaten zusammen, SIPRI 2024, Güte A)

---

## 2. Ihre strategische Fessel: Vasall der USA

**`dependsOn: USA` · Rolle `vasall` · 1 Kriegswirtschaftsschritt gebunden · 1 frei**

Das ist Kanon (`kriegswirtschaft.md` §2.2) und bleibt so stehen — auf ausdrückliche
Entscheidung des Spielleiters. Was es bedeutet:

- Sie können nur **einer** Eskalation folgen, wo eine blockfreie Macht **zwei** folgen kann.
- Ihr Patron Washington wird von der **KI** gespielt. Sie sind an Entscheidungen
  gebunden, die Sie nicht treffen.
- **Es ist ein Anfangs-Handicap, kein Dauerzustand.** Zwei Wege heraus:
  1. **L1-Tech »Umbau der heimischen Wirtschaft«** (§4.1) — reguläre Forschung,
     0,25 × Jahresbudget, Erfolg ab **4 auf 1W6**. Wirkt auch **auf Vorrat**.
  2. **Verrat am Patron** (§4.2 / KW-02) — der Patron kann Sie nicht entlassen, nur
     Sie können das Verhältnis aufkündigen. Ein unabhängig gewordener Vasall hat
     danach **beide** Schritte gebunden, gewinnt sie aber über Forschung zurück.

Aus Berliner Sicht ist das die Leitfrage der ganzen Partie: **strategische Autonomie
Europas — oder transatlantische Rückversicherung?** Sie müssen sie beantworten.

---

## 3. Ihre Startbestände (Beleg: SETUP, alle kanonquellenbelegt)

### Raumfahrt

| Posten | Wert | Quelle |
|---|---|---|
| **Startkapazität** | **45 t/a** LEO-Äquivalent (Ariane 6 + Vega C) | launch_c2.md Tab. 1 |
| **C2-Slots** | **8** (ESTRACK, EDRS) | launch_c2.md Tab. 2 |
| **Ω-Raumleistung P_Raum** | **1,00 · 10⁶ W** (Omega = gebuchte Leistung im Orbit) | leistungsbuch §6.1 |
| **K_Raum** | 0,000 (Kardaschew-Index Ihres Raumsegments) | leistungsbuch §6.1 |
| Weltanteil Raumleistung | 1,7 % | leistungsbuch §6.1 |
| **q_raum (Raumfahrtquote)** | 0,0005 (0,05 % BIP) | C-9 Rev. B §1.1 |

**Bemerkenswert:** Sie haben **8 C2-Slots** bei nur 45 t/a Startkapazität — das
zweitbeste Führungsnetz nach den USA, aber kaum Masse, um es auszulasten. Umgekehrt
hat Indien 3 Slots. Ihr Bodensegment ist Ihr unterschätztes Kapital: ESTRACK und EDRS
sind Infrastruktur, die andere erst bauen müssten.

### Bodenstreitkräfte (BL-01, aus SIPRI 2024 kompiliert, kein Zufall)

| Heer | Luft | SAM | See | ASAT |
|---|---|---|---|---|
| 93 | 97 | 86 | 94 | 2 |

*SAM = Surface-to-Air Missile, bodengestützte Flugabwehr. ASAT = Anti-Satellite,
Satellitenabwehr — Ihr Wert von 2 ist der zweitniedrigste am Tisch. Europa kann
Satelliten kaum abschießen. Das ist eine Lücke, keine Meinung.*

### Flotte, Industrie, Forschung
Alles auf **Null**. Keine Schiffe, keine Fabriken, keine laufende Forschung.
Das ist der reguläre Start 2026.

---

## 4. Die Weltlage — wer am Tisch sitzt

| Fraktion | Spieler | t/a | C2 | Ω P_Raum | Regime | Kernwaffen | Bindung |
|---|---|---|---|---|---|---|---|
| **USA** | KI | 2.000 | 24 | 5,24·10⁷ W | Demokratie | ja | **Ihr Patron** |
| **CHN** | **Andi** | 400 | 12 | 1,50·10⁶ W | Einparteien | ja | Patron von RUS + IND |
| **RUS** | KI | 100 | 5 | 2,70·10⁵ W | personalistisch | ja | Vasall CHN |
| **EU** | **Sie** | 45 | 8 | 1,00·10⁶ W | Demokratie | ja | Vasall USA |
| **IND** | **Jakob** | 40 | 3 | 2,10·10⁵ W | Demokratie | ja | Vasall CHN |
| **REST** | KI | 0 | 0 | 0 W | hybrid | nein | ungebunden |

**Ihre Lage in einem Satz:** Sie sind die einzige menschlich geführte Macht im
US-Block — und stehen zwei Spielern gegenüber, die beide an Peking hängen.

Jakobs Indien ist formal Vasall Chinas, aber eine Demokratie mit eigenem Kopf und der
schwächsten Raumfahrtbasis am Tisch. **Das ist Ihr natürlicher Gesprächspartner:**
zwei Demokratien in fremden Blöcken, beide mit demselben Emanzipationsproblem, nur in
entgegengesetzte Richtung. Ein europäisch-indisches Arrangement wäre die interessanteste
diplomatische Bewegung der frühen Partie.

---

## 5. Was Sie für Zug 1 entscheiden müssen

**Blatt 1 — Staatsführung**
1. **Rüstungsquote** (Regler; C-3-Sprungdeckel begrenzt den Jahressprung) — aus
   Berliner Sicht die Frage nach dem Sondervermögen und der 2-%-Debatte
2. **Safety-Slider** (KI-Sicherheit gegen Tempo) — Europa ist der Regulierungsakteur
3. **Repression** — bei 0,08 haben Sie enormen Spielraum nach oben, den Sie nicht
   brauchen sollten
4. **Orbitalanteil** — wie viel Ihres Budgets in den Raum geht
5. Bis zu **6 Befehle** (Domäne · Ziel · Freitext), Sonderbefehle, 2 Conditionals

**Blatt 2 — Energiepolitik (EH-01, Block EU, von Ihnen geführt)**
6. Energiebudget 0–100 % des Jahreskapitalbudgets
7. Baureihenfolge oder freie Rangliste über 19 Träger
> **Gemessen und nicht offensichtlich:** eine einzige Technologie lässt 18–34 % des
> Bedarfs ungedeckt, sieben nebeneinander nur 2,3 %. **Breite schlägt Rangfolge.**
> Für die deutsche Perspektive ist das die pointierteste Zahl im ganzen Spiel.

**Blatt 3 — Mitlaufende Module** (Delta V als Nachbarmodul)

**Delta V (Raumsegment)** — für Zug 1 typischerweise:
- Schiffsentwürfe (über den Shipyard-Rechner) oder Bau von Standardgerät
- Zielbahn: LEO / MEO / GEO / EML — jede Zone hat einen Massenfaktor gegen Ihre 45 t/a
- Forschungsslot setzen — **»Umbau der heimischen Wirtschaft« (L1)** ist der direkte
  Weg aus der Vasallenbindung und wäre ein sehr europäischer erster Zug
- Aufklärung, Diplomatie, Bündnisangebote

**Sie können frei formulieren.** Schreiben Sie mir Ihre Befehle in Prosa; ich übersetze
sie in das Auflösungsformat und weise zurück, was gegen eine Regel läuft — nie
stillschweigend umgedeutet.

---

## 6. Offene Punkte, die Sie kennen sollten

- **C-9 Raumfahrtquote ist aktiv** (Rev. B, ab Setup nach §9.3). Ihre Startkapazität ist
  ab jetzt **endogen**: sie wächst oder schrumpft mit Wirtschaftskraft und q_raum.
  Rampendeckel aufwärts ×1,25 je Zug, abwärts sofort.
  *Der Balancelauf zu C-9 (n ≥ 1200) steht laut Regelwerk noch **OFFEN** — die Regel ist
  unkalibriert. Das ist so im Spielstand vermerkt.*
- **Zeitmodell:** Ära I, 1 Jahr je Zug, Züge 1–25 (2026–2051).
- **Siegkriterien:** UEBERGABE (Kardaschew-Index K ≥ 0,9 bei intakter Biosphäre) ·
  STAGNATION (Zug 75) · WORLD3_KOLLAPS · XRISK_ENDE · BIOZID (Siegsperre).
  Weltstand heute: **K = 0,7285**.

---
*Erzeugt vom Delta-V-GM-Controller, Kampagne SCHWARZE SEE, Seed 516028054.
Fog of War: dieser Bericht enthält keine verdeckten Daten anderer Fraktionen.*
