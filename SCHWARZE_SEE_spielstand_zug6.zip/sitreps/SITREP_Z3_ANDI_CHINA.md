# SITREP ZUG 3 · 2028 · **CHINA**
**An:** Andi · **Von:** GM · **Einstufung:** nur für China
Kampagne SCHWARZE SEE · Stand 31.12.2028

> **Berichtslage.** Einparteienstaat, Repression 0,80, Medienfreiheit 0,20 → Bias-Faktor
> 1,2975. Was aus dem eigenen Apparat kommt, ist geschönt; was von außen kommt, nicht.

---

## 1. Ihre Frage zuerst

> *»Sind denn endlich mal die entwickelten Raumschiffe fertig?«*

**Nein — fertig 2029.** Die drei Neuentwürfe aus Zug 1 (2 Aufklärer, 5 Scorer, 2 GEO-Relais)
stehen auf `fertig_zug 2029`. Was bindet, ist die **Stückzeit**, nicht die Werft: Satellit
1,0 Jahr × BZ-01-Zeitfaktor 3,0 für einen Neuentwurf auf Stufe P0n = drei Züge, beauftragt
2026. Ihre Fertigungslinie war die ganze Zeit frei; blockiert waren drei Konstruktionsbüros.

> *»Der GM hat mir das Wahl nicht gutgeschrieben.«*

In Zug 2 stand auf Ihrem Blatt 4 **keine einzige Zahl** in den Forschungsfeldern — kein
Projekt, kein Einsatz. Es gab nichts zu würfeln. Diesmal haben Sie drei Vorhaben mit je
1 E₀ eingetragen; die sind gebucht (siehe §4).

**Für Zug 4:** die Schiffe werden 2029 fertig, die Startkapazität wird nach launch_c2 §5.2
erst **im Fertigungsjahr** gebunden — Ihre 400 t/a stehen dafür bereit. »Je zwei Schiffe in
die niedrigsten fünf Orbits« ist dann ausführbar. Zum Scoren braucht jedes Asset **1 km/s Δv**;
prüfen Sie das beim Entwurf.

---

## 2. Ihr bester Zug bisher

**Sie haben Earth Surface gewonnen, 2:1.**

| Kategorie | Sieger | Warum |
|---|---|---|
| Militärpunkte | USA | Gefechtswert 610,2 gegen Ihre 506,5 — Abstand von 238 auf 104 geschrumpft |
| **Eskalationsdominanz** | **China** | Sie haben eine Sabotage auf amerikanischem Boden durchgebracht, während Washington sich verbindlich festlegte, den Halbleiterhebel **nicht** zu ziehen |
| **Infowar** | **China** | Tonnenvergleich 145,1 t gegen Indiens 24,6 t — und die beiden einzigen geglückten Operationen des Zuges |

Serie **China 1**, USA zurück auf 0.

**Die Abwerbung ist der stillste Erfolg der Partie.** Wurf 100 gegen 390: Sie haben ein
Schlüsselteam von Falcon Heavy geholt, **unentdeckt**. Dauerhaft: Absorption +0,20,
Verhärtung −1, die Tacit-Decke fällt — und die amerikanische Absorption sinkt um 0,20.
Sie haben nicht nur gewonnen, Sie haben dem Gegner etwas weggenommen.

**Die Sabotage gegen die USA ist durchgekommen** (Wurf 181), aber sie wurde **entdeckt**.
Attribution 9,8 → **C3**: Washington darf Sie öffentlich benennen. Ein Eskalationsrecht hat
es nicht — dafür bräuchte es B2, und Ihre falsche Flagge hat genau diese drei Punkte gekostet.
**Blowback bereits im nächsten Zug fällig.**

Die Beschaffung gegen die US-Frontier-KI ist gescheitert (Wurf 586 gegen 320) und entdeckt,
Attribution D4 — nicht benennbar.

---

## 3. Der Deckel hat Ihren Sprengkopfauftrag zerlegt

Sie haben **99 Sprengköpfe** bestellt. Zum P4-Preis von 5 t sind das 495 t. Daneben standen
20 Future-SP (200 t) und 3 Pp State-of-the-Art (30 t) — alles drei auf der
**Hochtechnologie-Leiter**, zusammen **725 t** gegen eine Tranche von **362,6 t**.

Gekürzt in Blattreihenfolge (Z-3.1), weil keine Rangfolge angegeben war:

| Posten | gewünscht | gebucht |
|---|---|---|
| State-of-the-Art (§16) | 30,0 t | 30,0 t |
| Future 20 SP (§17) | 200,0 t | 200,0 t |
| Sprengköpfe (§17) | 99 Stück / 495 t | **26 Stück / 130,0 t** |

**Schreiben Sie ab Zug 4 eine Rangfolge auf das Blatt**, dann kürzt der GM nicht nach
Druckreihenfolge, sondern nach Ihrer Absicht.

Das ganze Konto:

| Posten | Einsatz |
|---|---|
| Geheimdienste 6 % | 145,1 t → 5 Slots |
| Force Projection 6 % | 145,05 t |
| Modernisierung 6 % | 145,05 t |
| Hochtechnologie (SotA + Future + Köpfe) | 360,0 t von 362,6 |
| **gebucht** | **795,2 t von 2 417,5 t** |
| **verfallen** | **1 622,3 t** (Z-1.4, Fluss statt Bestand) |

Zwei Drittel Ihres Bodenkontos sind ungenutzt verfallen. Das ist die teuerste Zeile in
diesem Bericht.

**Aufwertung:** Ziel-Teilstreitkraft **Heer** (Ihr Blatt nannte keine — der GM hat sie aus
dem Bündnis mit Indien und der antikolonialen Front abgeleitet). Heer auf »future«, q 1,40,
Gefechtswert 105 → **147,0**. Zusammen mit der SAM aus Zug 2 haben Sie zwei Teilstreitkräfte
auf dem Höchstwert.

**Arsenal:** 700 → **726 Sprengköpfe**. **Doktrin** eine Stufe von `vergeltung_nur` auf `nfu`.

---

## 4. Rechenwerk — Sie haben die KI-Führung abgegeben

Ihre Zuteilung: **T 4 · F 4 · O 4 · Z 4 · D 4**, Prüfer **P0 → P3**.

Gleichmäßig auf fünf Konten ist die teuerste Verteilung, die es gibt. Ihr Trainingskonto
fällt von 14 auf 4 RP, **g_T von 1,673 auf 0,894** — die USA stehen jetzt bei 1,414. Die
Führung im KI-Rennen, die Sie in Zug 2 einen Zug lang hatten, ist weg.

Dafür bekommen Sie: X-Risk fast halbiert (0,0067 → 0,0036), Forschungszeit −20 % (F-Stufe 2),
alle 12 C2-Slots sechzehnfach gedeckt, +0,60 % BIP/a — und mit **P3** erstmals eine ernsthafte
Datenseite: 1,68 QP/a wirksame Synthetik statt null.

Drei Forschungsvorhaben mit je 1 E₀ gebucht: kleine Kernreaktoren, bessere KI, bessere
KI-Chips. **Keine Techstufe ist offen** (L1 erst 2035/36), es gibt also keinen Freischaltwurf —
aber der Einsatz läuft auf `e_kum_eigen` und damit auf Ihre **Absorptionskapazität**. Wer
nichts forscht, kann nichts verwerten; Sie forschen jetzt am breitesten von allen.

---

## 5. Die Wirtschaft

**Wahrer Stand: 16,0059 → 15,3817 Bio USD (−3,90 Pp).**
*Interne Meldung an die Führung: −3,0 Pp.*

Zweites Jahr der Bankenkrise (−3,8), EU-Strafzölle (−0,7), Zivilkonto (+0,6). Der
Kapitalmarktausschluss läuft noch acht Züge, der Risikoaufschlag von +2 Pp bleibt. Ihr
Infrastrukturprogramm zur Stärkung der Binnennachfrage muss rein binnenfinanziert laufen und
wirkt frühestens 2029.

**Ihre C-7-Zündung ist nicht abgebrochen.** Kaskadenwurf 16 gegen Schwelle 5,6 — wieder
vorbei, vierter Wurf in Zug 4. Ein Abbruch ist eine eigene Ansage; die gebuchten Schäden
bleiben auch dann (Hysterese, QI-09).

**Energie:** EU 69,1 · USA 57,2 · Russland+Rest 54,8 · **China 47,3** · Indien 46,8. Ihre
Abregelung steigt auf 2,49 %. **Welt:** 432,7 ppm · +1,3893 °C · Biosphäre 98,34.

**Der Beijing-Delhi Nuclear Pact steht.** Indien hat ihn unabhängig von Ihnen beantragt —
beiderseitiger Wille. Indien hat allerdings im selben Zug die Repression zurückgenommen, den
Nationalismus gestärkt *»als Vorbereitung, das Alignment zu ändern«*, und die Arktis
einseitig zu chinesisch-indischem Eigentum erklärt — Letzteres ohne Ihre Deckung.

---

## 6. Domänen-Checkliste Zug 3

| Domäne | Status |
|---|---|
| energie · wirtschaft · innenpolitik · aussenpolitik · intel · militaer · forschung | **alle aufgelöst** |

WN-01-Validator: **BESTANDEN** (0 Fehler, 0 Warnungen, 3 Hinweise).
