═══ SITREP — IND — Jahr 2029 ═══
GEHEIM — NUR FÜR IND

▸ Weltlage: 2 öffentliche Auflösungen (Annihilation/Kessler) — Details unten
▸ Eigene Würfe diese Runde: 0
▸ Gebuchte Änderungen (eigene): 13
   · factions.IND.swarms.SDX-SSO.orbit_km: 700 → 500  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.IND.swarms.SDX-SSO.zone: SSO → LEO  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.IND.swarms.SDX-SSO.dv_kms: 0.15 → 0.096  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.IND.swarms.SDX-SSO.notiz: None → Perigaeum 700->500 km abgesenkt fuer den Rammversuch gegen SARah (JW-01, beide Fehlschuesse). Rest 96 m/s je Rumpf.  [werkbuch-bauzeiten §10 + deltav E13 (Schwarmregel) + launch_c2 §5.2 (B-16)]
   · factions.IND.economy.resources.propellant.lh2.stored_t: 0.8324 → 0.537  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.propellant.lox.stored_t: 4.8198 → 4.3198  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.propellant.ch4.stored_t: 2.0824 → 1.7349  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.launch.restraum_vortrag_t: 40.0 → 40.0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.launch._vortrag_beleg: {'gilt_fuer_jahr': 2029, 'herkunftsjahr': 2028, 'gestartet_gewichtet_t_2028': 0.0, 'regelref': 'launch_c2.md §5.6 (B-16)'} → {'gilt_fuer_jahr': 2030, 'herkunftsjahr': 2029, 'gestartet_gewichtet_t_2029': 0.0, 'regelref': 'launch_c2.md §5.6 (B-16)'}  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.launch.committed_t: 0.0 → 0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.c2.slots_committed: 0 → 0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.industrial.available_t: 4.0 → 4.0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
   · factions.IND.economy.resources.industrial.committed_t: 0 → 0  [references/economics.md §7 + launch_c2.md §5.4/§5.6 + wn02_skalenschnitt.md §4.1]
▸ Wirtschaft: Produktion 0 t · Upkeep 0 t
▸ Flotte: 0 Einzelschiffe + 2 Schwärme (4 Rümpfe)
▸ Ω-Lage (öffentlich): P_Raum 210000.0 W · Beleg SETUP: leistungsbuch §6.1, IND-Zeile (Startbestand Juli 2026, Güte C)
▸ Welt [annihilation] R4-annihilation-noop: übersprungen — keine Nukleareinsätze in der Vorrunde
▸ Welt [kessler] R4-kessler-zerfall: {"mechanik": "K-Z1", "sonnenphase": "mittel", "sonnenfaktor": 1.0, "hoehenfaktor": 1.0, "h
▸ Nächste Befehle fällig für: Jahr 2030
— Dies ist die Stufe-1-Kurzfassung (Standard). Literarischer Vollbericht nur auf Befehl `SITREP LANG` (Eingabe: diese Datei + kompakt.py-View, Deckel 15 KB).
═════════════════════════════════════════
