# SITREP ZUG 4 · 2029 · **INDIEN**
**An:** Jakob · **Von:** GM · **Einstufung:** nur für Indien
Kampagne SCHWARZE SEE · Stand 31.12.2029

---

## 1. Der Rammversuch — die Physik sagt ja, der Wurf sagt nein

Ihre Frage ist beantwortet, und die Antwort war **ja**. Reale Satelliten sind seit diesem
Zug Bahnobjekte (HE-21); SARah/SARLupe steht in 500 km sonnensynchron, Ihre SDX-SSO in 700 km.

**Der Δv-Haushalt trägt.** Eine Hohmann-Absenkung des Perigäums von 700 auf 500 km kostet
**54,0 m/s** — Ihre SPADEX führen 150. Und Sie brauchten die Bahnebene gar nicht anzugleichen:
ein Ebenenwechsel hätte 131 m/s je Grad gekostet und Sie sofort ruiniert, aber zum **Rammen**
genügt es, die Bahn des Ziels zu *kreuzen*. Zwei Bahnen unterschiedlicher Neigung schneiden
sich in zwei Knoten. Sie mussten nur den richtigen Moment treffen.

**Beide Rümpfe haben den Moment nicht getroffen.**

| Kettenglied (JW-01 §2–§6) | p |
|---|---|
| Bahnlösung, Q3-Lock auf ein ziviles Ziel mit öffentlichen Bahndaten | 0,95 |
| Knotendurchgang trifft die Zielposition | 0,35 |
| Terminal-Acquire eines Kleingeräts mit Lidar statt Suchkopf | 0,60 |
| Endgame — SARah weicht nicht aus, keine Deckung | 1,00 |
| **PK je Rumpf** | **0,1995** |

Würfe 9434 und 4110 gegen 1995. Zwei Fehlschüsse. Ihre beiden Rümpfe stehen jetzt in
**500 km mit je 96 m/s Rest** und zählen nicht mehr als SSO-, sondern als LEO-Objekte.

**Und jetzt der Teil, der wehtut.** Eine Bahnänderung ist kein verdeckter Vorgang. Jedes
Boden-Radar verfolgt sie. Zwei indische Satelliten, die ihr Perigäum auf die Höhe eines
deutschen Radaraufklärers absenken und zweimal nahe vorbeiziehen, sind kein Zufall und
lassen sich nicht abstreiten. **Attribution A1, ohne Wurf, für die EU, die USA, Russland und
China** (GM-Z4-01). Ab A1 besteht **Eskalationsrecht**. Brüssel hält damit erstmals einen
Nachweis in der Hand, den es öffentlich vorlegen kann — und daneben liegt seit Zug 1 noch die
unbenutzte B2-Attribution gegen Sie.

---

## 2. Ihr Zug am Boden

Konto 606,5 t, praktisch vollständig verbraucht:

| Posten | Einsatz | Wirkung |
|---|---|---|
| Geheimdienste 85 % | 515,5 t | 8 Slots (Deckel) |
| Future 9 SP → Heer | 90,0 t | Hochtechnologie 90,0 von 91,0 t |

**Sie haben den Geheimdienst-Tonnenvergleich diesmal verloren.** Nach HE-19 führen jetzt alle
sechs Fraktionen ein Bodenkonto — und die USA sind mit **7 463,6 t** dreimal so groß wie China.
Washington hat 746,4 t auf Geheimdienste gelegt und schlägt Ihre 515,5 t. Der Extrapunkt geht
an die USA. Das ist die Kehrseite der Regelkorrektur, um die Sie selbst gebeten haben.

**Doktrin: `ersteinsatz_begrenzt` → `de_eskalationsschlag`.** Sie stehen auf der **obersten
Stufe** der Leiter — während 50 chinesische Sprengköpfe unter Pekinger Zweitschlüssel in Ihrem
Land stehen. Weiter geht es nicht.

**Repression 0,4 → 0,6.** Ihr Kaskadenrisiko steigt von 3,75 auf **6,75 % pro Zug**. Der Wurf
(2016 gegen 675) ging gut aus. Bei Ihrem Patron ging er nicht gut aus — siehe unten.

**Wirtschaft: 4,1283 → 4,0870 Bio USD (−1,00 Pp).** Der Zünderpreis der Teilentkopplung ist
abgeschrieben; es bleibt der dauerhafte Niveauabzug.

---

## 3. Ihre Operationen — vier Versuche, vier Fehlschläge

- **Sabotage gegen die EU** (Umfang 5, falsche Flagge): Wurf 953 — gescheitert, immerhin
  unentdeckt. **Dritter Fehlschlag in Folge** gegen Brüssel.
- **Beschaffung gegen die USA** (Starship): Wurf 605 gegen 250 — gescheitert, unentdeckt. Die
  amerikanische Härtung H2 drückt Ihre Erfolgsaussicht auf 0,25 und hebt die Entdeckung auf 0,76.
- **Beschaffung gegen China** (Starship): Wurf 985 — gescheitert und **entdeckt**. Attribution
  7,8 → D4. Peking merkt, dass jemand seine Trägerraketentechnik abgreifen wollte, und kann Sie
  nicht benennen. Sie haben Ihren eigenen Bündnispartner bestohlen, ein Jahr nach dem Pakt.

Beutekonto weiterhin **0,2688 JB** offen, unverändert seit Zug 3.

Ihre 3 Rechenpunkte liegen zum dritten Mal vollständig im Training (g_T 0,775). **Das
Operationskonto steht zum dritten Mal auf 0.**

---

## 4. Was in der Welt passiert ist

**China hat den Weltraum genommen.** Neun Satelliten sind 2029 fertig geworden und gestartet:
zwei Aufklärer, fünf Scorer, zwei GEO-Relais. Jeder Scorer führt genau 1 km/s Reserve — einen
Scoring-Versuch. **China hat alle fünf Zonen gescort: LEO, MEO, HEO, SSO, GEO.** Unbestritten,
weil Ihre SPADEX nach dem Rammversuch 96 m/s führen und die Schwelle 1 000 m/s beträgt.

Chinas zwei Aufklärer decken ab sofort **jedes Bahnobjekt bis GEO** auf. Ihre vier Rümpfe
eingeschlossen.

**Und in China ist die Präferenzkaskade eingetreten.** Nach vier Jahren mit 9,75 % Risiko je
Zug fällt der Wurf: 258 gegen 975. Die Repressionsfalle schlägt zu, die Lücke zwischen
geäußerter und tatsächlicher Zustimmung bricht binnen eines Zuges zusammen. Ihr Patron hat ein
innenpolitisches Ereignis erster Ordnung.

**Die USA haben Earth Surface gewonnen** (Militärpunkte und Eskalationsdominanz; Infowar
remis) und dazu beide Budgetzeilen. **Rundenstand: China 5, USA 3.** China gewinnt die Runde,
**Serie 2 — eine Runde vor »Krieg gewonnen«.**

**Energie 2029:** EU 69,8 · USA 58,4 · Russland+Rest 56,0 · China 48,1 · **Indien 47,9.**
**Welt:** 436,0 ppm · +1,4131 °C · Biosphäre 97,71.

---

## 5. Domänen-Checkliste Zug 4

| Domäne | Status |
|---|---|
| energie · wirtschaft · innenpolitik · aussenpolitik · intel · militaer · forschung | **alle aufgelöst** |

WN-01-Validator: **BESTANDEN** (0 Fehler, 0 Warnungen, 3 Hinweise).
