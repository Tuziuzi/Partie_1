# BUDGETKONTEN ZUG 2 (2027) — öffentlicher Anhang
**Kampagne SCHWARZE SEE** · für alle drei Tische · Validator **BESTANDEN**
**Rev. B (23.08.)** — Jahresend-Abrechnung Zug 1 nachgeholt, Korrektur **K-1**. Zahlen unten sind maßgeblich.

*Startkapazität, Rüstungsausgaben und Rechenbestand sind öffentliche Größen
(SIPRI, Marktdaten, Startlisten). Kein verdeckter Inhalt — dieser Anhang geht an alle.*

**Vier Kassen. Sie sind nicht gegeneinander umbuchbar — mit einer Ausnahme,
und die steht in Kasse 2.**

---

## 1. RAUMKASSE — was in den Orbit kann

| | **IND** · Jakob | **CHN** · Andi | **EU** · Roman |
|---|---|---|---|
| Jahresfertigung | 4,0 t/a — **frei 4,0** | 40,0 t/a — **frei 40,0** | 5,0 t/a — **frei 5,0** |
| Lager | 10,0 t | 44,0 t | 11,0 t |
| Startkapazität | 40,0 t/a | 400,0 t/a | 45,0 t/a |
| **Startraum frei** | **40,0 t** | **400,0 t** | **45,0 t** |
| C2-Slots frei | **3 von 3** | 12 von 12 | 8 von 8 |
| Treibstoff LH2/LOX/CH4 | 2 / 6 / 3 t | 24 / 60 / 28 t | 3 / 7 / 3 t |

**Andis Werft ist frei, seine Konstruktionsbüros sind es nicht.** Die drei Bauten laufen bis
2029 — aber gebunden ist die **Stückzeit** (Neuentwurf P0n, 3 Jahre), nicht die Linie:
BZ-01 braucht dafür 0,25 Jahre Werftdurchsatz. Die 40 t/a stehen für Neues bereit,
solange es ein **Katalogentwurf** ist. Ein weiterer Neuentwurf wartet wieder 3 Jahre.
**Romans Werft ist völlig leer** — 5 t/a, davon 5 frei, 8 Slots offen, nichts im Orbit.
**Jakob hat die einzige Hardware oben** — seine vier Rümpfe brauchen in Zug 2 wieder Slots,
die er auf Blatt 1 zuweist (Slots sind eine Jahreszuteilung an aktive Missionen, kein
Besitz am Gerät).

---

## 2. BODENKASSE — was am Boden gebaut werden kann *(ZH-01, neu)*

| | Rüstungsfluss | + Restraum | **Bodenkonto** | Hochtech-Tranche 15 % |
|---|---|---|---|---|
| **CHN** | 2 236,9 t | 400,0 t | **2 636,9 t** | **395,5 t** |
| **EU** | 1 630,3 t | 45,0 t | **1 675,3 t** | **251,3 t** |
| **IND** | 589,8 t | 40,0 t | **629,8 t** | **94,5 t** |

**Hier ist die Ausnahme:** der *Restraum* ist Startkapazität, die Sie **nicht** verplanen.
Was nicht ins All geht, fällt 1:1 auf den Boden — zwei Ausgänge, eine Tonne (Z-1.5).
Verplanen Sie mehr Startmasse, schrumpft Ihr Bodenkonto in gleicher Höhe.

Die Tranche ist **Fluss, kein Bestand**: nicht gebucht heißt zum Jahresende verfallen.
Unter den Deckel fallen Sprengköpfe, Kernwaffenprogramm, Future-SP, State-of-the-Art,
ASAT. **Nicht** gedeckelt sind Modernisierung, Advanced-Punkte, Flugkörper, SAM, Personal.

### Was die Tranche an Sprengköpfen trägt

| | Preis je Stück | Bauzeit | **aus der ganzen Tranche** |
|---|---|---|---|
| **CHN** | **5,0 t** (Massenlinie P4) | **0,4 a** | **79 Stück** |
| **EU** | 10,0 t | 1,0 a | 25 Stück |
| **IND** | 10,0 t | 1,0 a | 9 Stück |

*Ohne jeden Restraum — wer die volle Startkapazität verplant — sind es 67 / 24 / 8.
Das ist genau die Kalibriertafel ZH-01 Z-7. Die Differenz ist der Restraum.*

**Der halbe Preis ist die eigentliche Zahl.** Andis Konto ist das 1,5-fache von Romans —
seine Sprengkopfausbeute ist das **Dreifache**, weil eine warme Massenlinie den Erdpreis
von 10 t auf 5 t drückt und die Bauzeit auf 0,4 Jahre. Das ist kein Geld, das ist
industrielle Substanz, und sie lässt sich in einem Zug nicht kaufen.

Zum Vergleich das Verhältnis der beiden Kassen: Roman kann am Boden **335-mal** so viel
Masse bewegen wie in seiner Raumwerft, Jakob 157-mal, Andi 64-mal.

---

## 3. RECHENKASSE — 100 RP weltweit *(DW-01, neu)*

| USA | **CHN** | REST | **EU** | **IND** | RUS |
|---|---|---|---|---|---|
| 55 | **20** | 13 | **8** | **3** | 1 |

Aufzuteilen auf fünf Konten: **T** Training · **F** Forschung · **O** Operation ·
**Z** Zivil · **D** Daten. Die Zuteilung gilt für die ganze Runde und steht **vor** der
Handlungsphase fest (Blatt 4). Nicht zugeteilte RP verfallen nicht — sie wirken nur nicht.
Rechenzeit ist nicht lagerfähig.

Schwellen am F-Konto: ≥ 1 % Weltanteil −10 % Forschungszeit · ≥ 3 % −20 % · ≥ 8 % −30 %.
Am O-Konto: 0,02 RP je gebundenem C2-Slot — wer in Zug 2 Slots zuweist, braucht Deckung,
sonst greift der Malus. **Jakob mit drei Slots: 0,06 RP von seinen 3.**

Härtung steht bei allen dreien auf **H0**. Kein Rechenzentrum ist geschützt.

---

## 4. FORSCHUNGSKASSE — ab Zug 2 eine Rate *(FO-01, neu)*

Einsatz in Vielfachen des Jahresbudgets. Bemessungsgrundlage BIP 2026:
**CHN 17,7449** · **EU 20,0056** · **IND 4,3** Bio USD.

```
p = 1 − exp( −ln2 · (E/E₀)^0,5 · m )     E₀ (L1) = 0,25 × Jahresbudget
```

Normeinsatz E = E₀ ergibt **p = 0,500** — exakt den alten Münzwurf 1W6 ≥ 4.
Untereinsatz 0,25 E₀ → p = 0,293 zum Viertelpreis. Vierfacher Einsatz → 0,750.
Zehnfacher → 0,888. **Der Deckel ist die Zeit, nicht das Geld.**

**Für Zug 2 praktisch:** die Zeitfenster sind unberührt, **L1 öffnet erst 2035/2036**.
Es gibt in diesem Zug also noch keine freigeschaltete Techstufe und damit keinen
Forschungswurf. Was ab sofort läuft, ist die **Spionageschicht** — BESCHAFFUNG,
ABWERBUNG, NACHBAU, HANDEL, Härtung und Embargo (Blatt 4, §23/§24).

---

## 5. Das Bild in drei Zeilen

**Andi** hat die größte Bodenkasse, den halben Sprengkopfpreis und die schnellste Linie.
Seine Raumwerft ist frei — was bis 2029 blockiert ist, sind drei Neuentwürfe, nicht die Linie.

**Roman** hat die zweitgrößte Bodenkasse, den besten Energieblock, 8 leere C2-Slots und
45 t ungenutzte Startkapazität — und nutzt von alledem nichts.

**Jakob** hat die kleinste Kasse in jeder der vier Spalten, dafür als Einziger Hardware im
Orbit, Verträge zu beiden Blöcken und mit 40 t freiem Startraum die Wahl, wohin die Tonne
fällt.

---
*Rohausgaben `zh01.py konto` und `zh01.py sprengkopf` im Audit unter `zeughaus.buchungen`.
Raumkasse aus `factions.<F>.economy.resources`. Belege ZH-01 Z-1, DW-01 §2, FO-01 R-1.*

*Rev. B: Korrektur K-1 (Jahresend-Abrechnung nach launch_c2.md §5 Pkt. 4 nachgeholt) und die
Befunde B-16 (Startkapazität für einen Start in drei Jahren) und B-17 (Werft war nie der
Engpass) stehen im Journal.*
