# SITREP ZUG 1 — REPUBLIK INDIEN (IND)
**Kampagne SCHWARZE SEE · Jahr 2026 abgeschlossen · nächster Zug: 2027**
Spieler: Jakob · WN-01-Validator: **BESTANDEN** (0 Fehler)

---

## 1. Was Sie erreicht haben

**SPADEX fliegt. Noch dieses Jahr.**

| | |
|---|---|
| Gebaut | 4 Rümpfe SPADEX Zwillingsbund, je 258 kg nass, Δv 150 m/s |
| Im Orbit | **SDX-LEO** (2 Rümpfe, 460 km) · **SDX-SSO** (2 Rümpfe, 700 km) |
| BZ-01-Stufe | **P0k** (Katalogentwurf, Erststück Indiens) — Kosten ×2,5, Zeit ×2 |
| Bauzeit | 0,2 a — unter dem Jahrestakt, deshalb **im Zug fertig** |
| Material | 2,58 t von 4,0 t Jahresfertigung · **1,42 t Rest** |
| Startmasse | 1,032 t von 40 t/a · C2 **2 von 3 Slots** belegt |
| Serienzähler | **1,032 t** — beim nächsten SPADEX-Los sind Sie auf **P1** (×2,0 statt ×2,5) |

Sie sind damit die einzige Macht am Tisch mit eigener Hardware im Orbit. Beide Verbände
sind **unbewaffnet** — das Memorandum ist gewahrt.

---

## 2. Was nicht geklappt hat

**Chinesische Hilfe: abgelehnt.** Ihre Anfrage (O-indien-08) traf auf Pekings eigenen
Zug-1-Befehl, wörtlich: *»Indien ist ein Freund und Helfer. Kein Technologietransfer aber
wirtschaft helfen.«* SPADEX ist reiner Eigenbau. Wirtschaftlich bleibt China
kooperationsbereit.

**Befund V8 — Blatt 1, Zeile 4 zurückgewiesen.** Domäne `intel`, Ziel `china`, aber kein
Text; auch die Freitexte nennen keine Absicht gegen China. Ohne Auftrag ist keine
Operation auflösbar, und Raten ist verboten. Formulieren Sie ihn in Zug 2 aus.

---

## 3. Die schlechte Nachricht

**Ihre falsche Flagge hat nicht gehalten.**

Die Psyop über das Goethe-Institut-Pendant wurde von der EU aufgeklärt und Ihnen
zugeordnet — Attributionsgüte **B2** nach D-2, trotz der falschen Flagge.
Öffentliche Benennung ist erlaubt, Eskalation ebenfalls.

Rechenweg offengelegt: Umfang 5 kam aus Ihrem Blatt. Gegenspionage 4 und Laufzeit 1 Zug
sind GM-Bemessung — die EU hat mit Repression 0,08 und Medienfreiheit 0,88 offene, wache
Institutionen. Beides steht so im Audit und ist nachprüfbar.

Was das heißt: Roman *kann* Sie im nächsten Zug öffentlich beschuldigen. Ob er es tut,
entscheidet er. Dass Sie gleichzeitig ein Freihandelsangebot von ihm auf dem Tisch haben
(O-eu-04), macht die Lage interessant.

---

## 4. Energie und Wirtschaft (Block INDIEN, von Ihnen geführt)

| Kennzahl | Wert |
|---|---|
| Primärenergie | 36,2 EJ |
| Versorgung | 100 (keine Deckungslücke) |
| Klima | **8,2** — der zweitschlechteste Wert am Tisch |
| Nachhaltigkeit | 37,7 |
| **Gesamtscore** | **44,6** |

⚠️ **Rezessionsflag.** Ihre Reservemarge liegt bei −0,0518, die Schwelle bei −0,03. Die
Vorwahl »ausgewogen« bei 100 % Budget deckt den Bedarf, lässt aber keine Reserve. Klima
8,2 heißt: Sie wachsen fossil.

*Erinnerung an die rote Zeile auf Blatt 2: eine einzige Technologie lässt 18–34 % des
Bedarfs ungedeckt, sieben nebeneinander nur 2,3 %. **Breite schlägt Rangfolge.***

---

## 5. Weltlage 2026 → 2027

| | 2025 | 2026 |
|---|---|---|
| CO₂ | 422,8 ppm | **426,1 ppm** |
| ΔT | 1,30 °C | **1,3421 °C** |
| Biosphäre B | 100 | **99,47** |

**Scoring:** niemand hat kΔv ausgegeben, es gab in Zug 1 kein Schiff im Orbit, das scoren
konnte. `scoring.md` wörtlich: *»Eine Runde, in der niemand scored, ist ein Remis an der
Spitze und damit neutral.«* Alle Serien stehen bei 0.

**Weltereignis:** Die 2W10-Tafel fiel auf **2** (1+1). `ereignisse.md` führt unter
»Ereignistafel« nur die Konvention, **aber keine Ergebniszeilen** — zu einer Summe von 2
existiert kein Eintrag. **REGELLÜCKE**, gemeldet statt geschätzt. Kein Weltereignis.

**Kriegswirtschaft:** Sie bleiben Vasall Chinas, 1 freier Schritt von 2. Der Ausweg über
die L1-Tech »Umbau der heimischen Wirtschaft« steht weiter offen.

---

## 6. Für Zug 2

- **P1 nutzen:** das nächste SPADEX-Los kostet ×2,0 statt ×2,5. Wenige Entwürfe, viele
  Stücke — bei 4 t Jahresfertigung ist das Ihr einziger Hebel.
- **Die Attribution beantworten**, bevor Roman sie ausspielt.
- **Freihandelsangebot der EU** liegt vor (O-eu-04).
- Ein C2-Slot ist noch frei (2 von 3 belegt).
- Zeile 4 des Befehlsblatts nachreichen.

---
*Fog of War: dieser Bericht enthält keine verdeckten Daten anderer Fraktionen. Alle Würfe
und Rechnungen liegen im Journal, Belege W-001-0001 ff. und R-Z1-01 ff.*
