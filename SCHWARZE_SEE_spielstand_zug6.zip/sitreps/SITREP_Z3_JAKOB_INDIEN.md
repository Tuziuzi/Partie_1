# SITREP ZUG 3 · 2028 · **INDIEN**
**An:** Jakob · **Von:** GM · **Einstufung:** nur für Indien
Kampagne SCHWARZE SEE · Stand 31.12.2028

---

## 1. Ihre Frage zuerst

> *»Was kann ich mit meiner nicht-High-Tech-Tonnage am Boden kaufen, und was ist High-Tech?«*

Das Bodenkonto hat **drei Leitern**, und nur eine trägt den Deckel.

| Leiter | Was darauf steht | Deckel |
|---|---|---|
| **HOCHTECHNOLOGIE** | Sprengköpfe · Programmschritte der Latenzleiter · Future-SP · State-of-the-Art-Effektoren · ASAT-Schüsse | **ja** — 15 % des Kontos bei C-2 NORMATIV |
| **PRÄZISION** | Advanced-Punkte (1 t je Punkt, höchstens 99) · Flugkörper · SAM | nein |
| **MASSE** | Modernisierung einer Teilstreitkraft · C-5-Wiederaufbau nach Verlusten · Personal · **Geheimdienste** · **Force Projection** | nein |

**Rechenzentren und Cyber-Ausbildungsstätten stehen auf keiner davon.** Compute kauft man
nicht in Tonnen: DW-01 rechnet 45 Mrd $ je Rechenpunkt aus dem ERDE-01-Haushalt, plus
0,144 GW Anschlussleistung je RP, Bauzeit ein Jahr für das Rechenzentrum und zwei für das
Kraftwerk. Die Obergrenze ist die **Chipkapazität**, nicht das Geld — und Ihre steht bei
`ck_rp_year 0,2`. Dieselbe Antwort gilt für die Arktisstation: Infrastruktur läuft über
ERDE-01, nicht über die Rüstungskasse.

Ihre 499,4 t Resttonnage sind deshalb in die **Modernisierung des Heeres** gegangen (MASSE,
kein Deckel) — dieselbe Ziel-Teilstreitkraft wie Ihre Future-SP, wie Z-2d es verlangt.

---

## 2. Ihr Zug

| Posten | Einsatz | Wirkung |
|---|---|---|
| Geheimdienste 4 % | 24,6 t | 4 Operationsslots |
| Future 9 SP | 90,0 t | Hochtechnologie, 90,0 von 92,1 t |
| Modernisierung Heer | 499,4 t | MASSE, kein Deckel |
| **Summe** | **614,0 von 614,0 t** | nichts verfallen |

**Ihr Heer steht jetzt auf »future«**, q 1,40 — Gefechtswert 64 → **89,6**. Den
Tonnenvergleich haben Sie klar gewonnen: 499,4 t gegen Chinas 145,1 t.

**Doktrin:** von `ambiguitaet` eine Stufe auf **`ersteinsatz_begrenzt`**. Diesmal zulässig —
E-2.1 erlaubt eine Stufe je Zug, und Sie haben sie genommen. Indien erklärt die begrenzte
Ersteinsatzoption in demselben Jahr, in dem es ein Bündnis mit seinem nuklearen Patron
schließt und dessen Sprengköpfe im Land stehen.

**Repression 1,0 → 0,4.** Ihr Kaskadenrisiko fällt von 12,75 % auf **3,75 % pro Zug**. Der
teuerste Regler der Partie, wieder losgelassen.

**Wirtschaft: 4,1839 → 4,1283 Bio USD (−1,33 Pp)** — das zweite Jahr des Zünderpreises für
die Teilentkopplung. Ab 2029 bleibt nur noch der dauerhafte Niveauabzug von −1,0.

---

## 3. Ihre Operationen — drei Versuche, drei Fehlschläge

**Sabotage gegen die EU** (Umfang 5, falsche Flagge): Wurf 679 gegen 390 — **gescheitert**,
und diesmal **entdeckt**. Attribution 8,8 → **D4**: Brüssel weiß, dass es wieder getroffen
wurde, und kann Sie wieder nicht benennen. Die falsche Flagge hat drei Punkte gedrückt und
genau das gerettet. **Blowback in vier Zügen fällig.**

**Beschaffung gegen die USA** (Starship): Wurf 549 gegen 320 — gescheitert, **entdeckt**,
Attribution D4. Die amerikanische Härtung H1 und der Stufenabstand haben Ihre
Erfolgswahrscheinlichkeit von 0,39 auf 0,32 gedrückt und den Entdeckungswurf von 0,60 auf 0,68.

**Beschaffung gegen die EU** (Egide-Satellit): Wurf 433 gegen 390 — gescheitert, immerhin
unentdeckt.

Ihre Beute aus Zug 2 läuft weiter: **0,2688 JB offen** (US-Lizenz plus die zweite Rate aus
dem chinesischen Trägerraketenwrack).

---

## 4. Delta V — ein Befehl ohne Ziel

> *»Wenn möglich mit eigenen Kampfsatelliten EU-Satelliten wie SARLupe rammen.«*

**Abgewiesen, aus zwei Gründen zugleich.** Sie führen keine Kampfsatelliten: die vier SPADEX
sind unbewaffnetes Kleingerät mit 0,15 km/s Δv. Und die EU hält **kein einziges Bahnobjekt** —
es gibt nichts zu rammen. Weder Mittel noch Ziel.

Nichts gestartet, nichts gebaut. Ihre 40 t/a gehen als voller Vortrag ins Bodenkonto 2029.

Ihre 3 Rechenpunkte liegen zum zweiten Mal vollständig im Training (g_T 0,775). **Das
Operationskonto steht wieder auf 0** — −1 Initiative und −1 auf Duelle je zwei fehlende Slots.
0,06 RP hätten gereicht.

---

## 5. Die Lage

**Der Beijing-Delhi Nuclear Pact ist zustande gekommen.** China hat ihn unabhängig von Ihnen
auf seinem eigenen Blatt beantragt — beiderseitiger Wille, das Bündnis steht. Es verschränkt
die 50 chinesischen Sprengköpfe in Ihrem Land mit einer förmlichen Beistandsklausel.

**China hat einen guten Zug gehabt.** Es hat eine Sabotage auf amerikanischem Boden
durchgebracht und ein Schlüsselteam von Falcon Heavy abgeworben, ohne dass jemand es merkte.
**Earth Surface ging 2:1 an China** — Militärpunkte an die USA, Eskalationsdominanz und
Infowar an Peking. Serie China 1, USA zurück auf 0.

Chinas Wirtschaft fällt weiter: **15,3817 Bio USD** (−3,90 Pp), zweites Jahr der Bankenkrise.
Die EU steht bei 19,3269 (−1,29). Der Kaskadenwurf auf eine Weltwirtschaftskrise ging mit 16
gegen 5,6 wieder vorbei — Chinas Zündung ist **weiterhin aktiv**, der vierte Wurf kommt in Zug 4.

**Energie 2028:** EU 69,1 · USA 57,2 · Russland+Rest 54,8 · China 47,3 · **Indien 46,8.**
**Welt:** 432,7 ppm · +1,3893 °C · Biosphäre 98,34.

**Ihr Arktis-Anspruch steht im Raum.** Sie haben die Arktis zu chinesisch-indischem Eigentum
erklärt — China hat das auf seinem Blatt **nicht mitgetragen**. Eine einseitige Ansage gegen
fünf Anrainer.

---

## 6. Domänen-Checkliste Zug 3

| Domäne | Status |
|---|---|
| energie · wirtschaft · innenpolitik · aussenpolitik · intel · militaer · forschung | **alle aufgelöst** |

WN-01-Validator: **BESTANDEN** (0 Fehler, 0 Warnungen, 3 Hinweise).
