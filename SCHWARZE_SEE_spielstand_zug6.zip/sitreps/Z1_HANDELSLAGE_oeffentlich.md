# HANDELSLAGE ZUG 1 (2026) — öffentlicher Anhang
**Kampagne SCHWARZE SEE** · für alle drei Spieler · Validator **BESTANDEN**

*Handelsverträge, Zölle und Exportverbote sind öffentliche Akte. Dieser Anhang enthält
keine verdeckten Daten und geht deshalb an alle drei Tische.*

---

## 1. Was zustande gekommen ist

| Nr. | Partner | Art | Grundlage |
|---|---|---|---|
| **HV-2026-01** | **EU ↔ Indien** | **Freihandelsabkommen** | Beidseitiges Angebot im selben Zug: Romans O-eu-04 und Jakobs O-indien-01. Zwei übereinstimmende Willenserklärungen — der Vertrag kommt zustande. Zollabbau, EU-Normen für Importe. |
| **HV-2026-02** | China ↔ Indien | Wirtschaftsabkommen **ohne Technologieteil** | Jakobs O-indien-02 trifft auf Andis O-china-09, wörtlich: *»Indien ist ein freund und helfer. Kein technologietransfer aber wirtschaft helfen.«* Warenhandel und Investitionen ja, Technologie nein. |
| HV-2026-03 | Indien → USA | einseitige Anpassung | O-indien-06 *»alles schlucken was Trump mag«* — Zugeständnisse ohne Gegenleistung an den KI-geführten US-Block. |
| HV-2026-04 | China ↔ USA | bilaterale Gespräche | O-china-05 / O-china-10 — ausdrücklich **ohne** Beteiligung der EU. |
| HV-2026-05 | China → Russland | Wirtschafts- und Rüstungshilfe | O-china-08 — Waffen und Wirtschaftsstützung, damit Moskau die EU unter Druck setzt. |

**Jakob ist der einzige Spieler mit Verträgen zu beiden Blöcken.** Während sich China und
die EU entkoppeln, hat Indien im selben Jahr Freihandel mit Brüssel und ein
Wirtschaftsabkommen mit Peking geschlossen.

---

## 2. Was gebrochen wurde

### HB-2026-01 — China gegen die EU: **C-7 Zündstufe I1 (Totalabbruch)**

Andis Befehl — *»Exportverbot von Waren, Dienstleistungen und Technologie nach EU«* —
erfüllt die Aktivierungsbedingung des Moduls C-7 »IMPLOSION«. Das ist kein Zoll und keine
Sanktion, das ist die Wirtschaftswaffe.

**REGEL** C-7 §2: `I1 = 10 × Welthandelsanteil des Zünders`
**EINGABEN** Welthandelsanteil China 0,142 · nur I1 gezündet (kein Finanzschlag, keine Blockade)

Rohe Ausgabe von `c7.py ip`:
```
I1=1.42  I2=1.0 (Markt 0.0 + Reserve 0.0 + Rekord 0.0 + FireSale 1.0)  I3=0.0  | IP=2.42
```

**Korrektur mit Regelzitat.** Die Engine addiert den Fire-Sale-Term unbedingt und bietet
keinen Schalter, ihn wegzulassen. `implosion_regeln.md` §2 sagt aber wörtlich:
*»Nur gezündete Stufen zählen.«* China hat keinen Fire-Sale angeordnet. Maßgeblich ist
**I1 allein: IP = 1,42.** Als **REGELLÜCKE** gemeldet, nicht stillschweigend übernommen.

**Damit greift §3:** *»Bei IP < 2 findet kein Wurf statt (Dämpfungsregime).«*
→ **Kein globaler Kaskadenwurf. Die Weltwirtschaft hält.**

### Der Preis — und er ist asymmetrisch

| | 2026 | 2027 | dauerhaft |
|---|---|---|---|
| **China (Zünder)** | **−8,0 Pp BIP** | −4,0 Pp | −3 Niveau |
| **EU (Ziel)** | **−1,45 Pp BIP** | Erosion | — |

**Verhältnis Zünder zu Ziel: 5,52 zu 1.** Andi zahlt das Fünfeinhalbfache dessen, was er
Roman zufügt. Das ist keine Wertung, das ist die Tafel §4 gegen die Formel
`−10 × bilateraler Handelsanteil` (EU–China 0,145, GM-Bemessung, ausgewiesen).

Genau das ist die historische Lehre, die dem Modul zugrunde liegt: London zündete den
Plan 1914 und **brach ihn selbst ab**, als die Kollateralschäden sichtbar wurden.

**Erosion nach C-4:** Ersatzhandel baut die Wirkung um 20 % je Zug ab, Boden bei 40 %
Restwirkung — Zug 1 noch 80 %, Zug 2 64 %, Zug 3 51 %. Die Waffe stumpft ab, die
Zünderkosten bleiben.

**Autokratie-Klausel §4:** Kein Abbruchzwang für Peking — dafür zählt die selbst
ausgelöste Rezession ab Zug 2 **voll auf den Coup-Track (×1,47)**. Und der geschönte
Innenbericht verschleiert die wahren Kosten.

### HB-2026-02 — EU gegen China: **C-4, keine Zündstufe**

Romans Strafzölle auf chinesische E-Autos und der Huawei-Ausschluss aus dem 5G-Netz sind
gezielte Zölle und ein Beschaffungsausschluss — kein Voll-Decoupling. Die
Aktivierungsschwelle von C-7 ist **nicht** erreicht; es gilt die gewöhnliche
Sanktionsregel C-4. Keine Implosionspunkte, kein Kaskadenrisiko.

---

## 3. Das Bild am Ende von 2026

Zwei Blöcke koppeln sich ab, und der teuerste Preis wird von dem bezahlt, der zuerst
gezogen hat. Dazwischen steht Indien mit Verträgen nach beiden Seiten — formal Chinas
Vasall, wirtschaftlich frei beweglich, und seit diesem Jahr Freihandelspartner der EU.

Für die USA, die den größten Block halten und von der KI geführt werden, sind gleich zwei
Türen aufgegangen: Indiens einseitige Zugeständnisse und Chinas bilaterale Gespräche unter
Ausschluss Brüssels. Status-quo-KI sucht die Allianz mit dem Stärksten — und wird 2027
gefragt werden, wer das ist.

---
*Rechenprotokolle R-Z1-06 und R-Z1-07 im Audit. Alle Verträge und Brüche stehen unter
`module.erde01.daten.handelslage` im Spielstand.*
