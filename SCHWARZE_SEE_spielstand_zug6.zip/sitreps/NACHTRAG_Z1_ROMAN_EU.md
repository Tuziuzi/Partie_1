# NACHTRAG ZUG 1 (2026) — EUROPÄISCHE UNION (EU) — aus Berliner Sicht
**Kampagne SCHWARZE SEE** · Validator **BESTANDEN** · Belege R-Z1-06 bis R-Z1-11

> **Korrektur.** Fünf der sieben ERDE-01-Domänen waren im ersten Durchlauf unaufgelöst im
> Postfach liegen geblieben; die SITREPs haben das nicht ausgewiesen. Hier stehen die
> nachgeholten Ergebnisse. Sie ergänzen den SITREP Zug 1, sie ersetzen ihn nicht.

## Wirtschaft — Ihre Zölle waren kein Geplänkel
Die Frage, ob Strafzölle und Huawei-Ausschluss Wirkung haben: **ja, und zwar erheblich.**

| Instrument | Wirkung auf China | Kosten für Sie |
|---|---|---|
| Strafzölle E-Autos (C-4 `us_unilateral`) | **−0,7 Pp/Jahr über 7 Jahre = −4,9 Pp kumuliert** | keine gebuchten |
| Huawei-Ausschluss 5G (Einzelsanktion) | **−0,39 % Niveau** | keine gebuchten |

Verhaltensänderungswurf nach C-4 (p = 0,26): **W100 = 47 → nein.** Peking gibt nicht nach.

**Der Vergleich ist die eigentliche Nachricht.** Andis dramatisches Exportverbot kostet ihn
selbst −8 Pp in einem Jahr, um Ihnen −1,45 zuzufügen. Ihre beiden nüchternen Maßnahmen
kosten Sie nichts und fügen ihm über sieben Jahre −4,9 Pp zu. Das billige Instrument
wirkt länger als das laute.

**Ihr BIP 2026: 20,3 → 20,0056 Bio USD (−1,45 %).** Chinas: 19,5 → 17,7449 (−9,0 %).
Sie sind aus diesem Handelskrieg als die größere Volkswirtschaft hervorgegangen.

## Innenpolitik — der Preis Ihrer Härte
Repression **0,08 → 0,20**. Frontex-Pushbacks und die AfD-Verbotsprüfung sind nicht gratis:
Kaskadenrisiko **0,75 % je Zug, 7,25 % über zehn Züge.** Immer noch der mit Abstand beste
Wert am Tisch — aber Sie haben Ihren größten strukturellen Vorsprung um mehr als das
Doppelte verkleinert.

## Forschung — Safety-Slider auf **0,6**
Fortschritt **0,4804** — halbes Tempo. X-Risk **0,064 % je Zug, 1,9 % über 30 Züge.**
China und Indien fahren beide auf 0,0 und tragen je 11,33 %. Sie forschen halb so schnell
für ein Fünftel des Risikos. Ob das der richtige Handel ist, entscheidet die Partie.

## Militär — alles aus dem laufenden Haushalt
NATO-Europäisierung eingeleitet, deutsch-französische Trägerkooperation statt FCAS
vereinbart (zweiter Träger plus EU-Carrier-Group, Bauzeit außerhalb von Zug 1),
Nukleargespräche mit Frankreich aufgenommen, Ostsee- und Unterwasserüberwachung verstärkt.
Rüstungsquote bleibt **NORMATIV** — keine Mobilisierungsstufe, kein Sprungdeckel berührt.

## Außenpolitik
Kanada-Beitrittsangebot ausgesprochen, Antwort steht 2027 aus. Russisches Haus in Berlin
geschlossen, TAURUS-Drohung ausgesprochen — bedingte Zusage, keine Lieferung. Moskau hat
sich um +1 verhärtet und wird von Peking mit Waffen und Geld gestützt.

---

## Domänen-Checkliste Zug 1

| Domäne | Status |
|---|---|
| energie | ✅ aufgelöst (EH-01) |
| wirtschaft | ✅ aufgelöst (C-7, C-4, BIP gebucht) |
| innenpolitik | ✅ aufgelöst (B-2 Kaskade) |
| aussenpolitik | ✅ aufgelöst |
| intel | ✅ aufgelöst (D-2 Attribution) |
| militaer | ✅ aufgelöst (kein Gefecht) |
| forschung | ✅ aufgelöst (F-3 Safety) |

**Offen: keine.**

---
*Alle Buchungen unter `truth.buchungen`, alle Rechnungen unter `audit.rechenprotokolle`.*
