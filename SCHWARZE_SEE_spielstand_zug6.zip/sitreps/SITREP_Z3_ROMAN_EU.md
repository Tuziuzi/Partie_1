# SITREP ZUG 3 · 2028 · **EUROPÄISCHE UNION**
**An:** Roman · **Von:** GM · **Einstufung:** nur für die EU
Kampagne SCHWARZE SEE · Stand 31.12.2028

> **Dieser Zug lief auf Autopilot.** Nicht als Vertretung Ihrer Person wie in Zug 2, sondern
> auf **SV-01 Stufe A1**: ein Python-Doktrinbaum, Doktrin `defensiv-oekonomisch`. Kein
> Profilvektor, kein Rückgabebrief, keine Treuhand-Schranken — die Fraktion hat schlicht nach
> Lehrbuch gehandelt. Was dabei herauskam, ist bewusst schmal.

---

## 1. Was der Doktrinbaum entschieden hat

Drei Zeilen, mehr gibt A1 nicht her:

- **Budget** 45 % Wirtschaft · 20 % Militär · 25 % Forschung · **10 % verdeckt**
- **Haltung** defensiv
- **Reaktion** auf Angriff: verteidigen

Das ist eine sichtbare Abweichung von Ihrer eigenen Linie: Sie hatten in zwei Zügen
**null Prozent** in verdeckte Mittel gelegt, der Doktrinbaum setzt reflexhaft 10 %. Und das
Militärbudget fällt von 38 auf 20 %, während das Wirtschaftsbudget von 32 auf 45 steigt.
Der europäische Pfeiler, die Frankreich-Gespräche und das Ariane-Programm sind in diesem Zug
**nicht weitergetrieben** worden — A1 schreibt fort, es baut nicht.

---

## 2. Die Lage

**Ihr BIP: 19,5795 → 19,3269 Bio USD (−1,29 Pp).**
Chinas Zielschaden aus dem Handelsabbruch läuft im dritten Jahr und erodiert (−0,93),
Indiens Sanktionen kosten die vollen −0,90, dessen Teilentkopplung noch −0,06; das
Zivilkonto der Rechenleistung bringt +0,60 zurück. Rezessionsflag −0,1367, Abregelung 2,12 %.

**Sie sind wieder sabotiert worden — und wieder ohne Täter.**
Eine verdeckte Operation gegen europäische Ziele, Umfang 5, unter falscher Flagge. Sie ist
**gescheitert**, und Ihre Abwehr hat sie bemerkt. Attributionsgüte **D4**: nicht öffentlich
benennbar. Zum zweiten Mal in Folge wissen Sie, dass jemand an Ihrer Infrastruktur arbeitet,
und können niemanden nennen. Das ist die direkte Rechnung für ein Geheimdienstbudget, das in
Zug 2 auf null stand.

Daneben: eine **geglückte** Einfluss- und Desinformationskampagne gegen europäische
Öffentlichkeiten, viele kleine Operationen, teils unter falscher Flagge. Auch diese wurde
bemerkt — Attribution **F6**, weit unter jeder Benennbarkeit.

Und eine dritte, gescheiterte und unentdeckte Beschaffungsoperation gegen ein europäisches
Satellitenprogramm, von der Sie nichts wissen.

**Washington bietet an.** Eine auf drei Züge befristete, bepreiste, nicht automatische
bilaterale Zusage samt Zugang zur amerikanischen Startkapazität — ausdrücklich **ohne**
Bündnisautomatik. Die Rückzugsdrohung bleibt daneben auf dem Tisch. Sie hängen weiterhin mit
45 t/a an einem einzigen Weltraumbahnhof.

**Moskau umgeht Sie weiter**: öffentliche Langfrist-Festpreisangebote für Gas an einzelne
Mitgliedstaaten, ausdrücklich am Rat vorbei.

**China und Indien haben ein Verteidigungsbündnis geschlossen** — den Beijing-Delhi Nuclear
Pact, beidseitig beantragt. Es verschränkt die bereits stationierten chinesischen
Sprengköpfe in Indien mit einer förmlichen Beistandsklausel. China baut zusätzlich eine
antikoloniale Front gegen EU und USA auf, mit Reparationsforderungen.

**China hat den Zug gewonnen.** Earth Surface ging 2:1 an Peking — Militärpunkte an die USA,
Eskalationsdominanz und Infowar an China, das eine Sabotage auf amerikanischem Boden
durchbrachte. Serie China 1.

**Energie: EU 69,1 — weiterhin Platz eins**, vor USA 57,2 · Russland+Rest 54,8 · China 47,3 ·
Indien 46,8. **Welt:** 432,7 ppm · +1,3893 °C · Biosphäre 98,34.

---

## 3. Was auf Sie wartet

- Ihre **B2-Attribution gegen Indien** aus Zug 1 ist immer noch ungespielt. Indien hat
  seither sanktioniert, sich entkoppelt und zweimal Sabotage gegen Sie versucht — die Karte
  ist heute mehr wert als vor zwei Jahren.
- Ihr **verdecktes Budget** stand zwei Züge auf null, und beide Male hat Sie das blind
  gemacht, als jemand an Ihrer Infrastruktur gearbeitet hat. Der Doktrinbaum hat 10 % gesetzt;
  ob das bleibt, entscheiden Sie.
- **Frankreich**, **Kanada** und der **europäische Pfeiler** liegen unverändert da, wo Sie
  sie in Zug 2 hinterlassen haben.
- Das **amerikanische Angebot** ist befristet.

---

## 4. Domänen-Checkliste Zug 3

| Domäne | Status |
|---|---|
| energie · wirtschaft · innenpolitik · aussenpolitik · intel · militaer · forschung | **alle aufgelöst** |

WN-01-Validator: **BESTANDEN** (0 Fehler, 0 Warnungen, 3 Hinweise).
