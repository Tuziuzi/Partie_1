#!/usr/bin/env python3
"""Pruefung W-1: reproduziert die Konvergenzformel (Anhang B) den Tafelpfad (Anhang A)?
Alle Eingaben sind Kalibrierannahmen (Guete C), der Zweck ist die MECHANIK-Probe,
nicht die Zahl in der dritten Stelle."""
import math, json

# --- Tafelpfad (Anhang A, Zentralwerte %/a) --------------------------------
TAFEL = {  # Fenster: 2025-30, 30-40, 40-50, 50-60
    "USA":  [2.0, 1.7, 1.6, 1.5],
    "CHN":  [4.3, 3.0, 2.2, 1.6],
    "EU":   [1.2, 1.3, 1.2, 1.1],
    "IND":  [6.5, 5.4, 4.5, 3.6],
    "RUS":  [0.9, 1.0, 0.9, 0.8],   # enthaelt Krieg/Sanktionen (IWF-Ist)
    "REST": [3.2, 3.0, 2.7, 2.4],
}
FENSTER = [(2026, 2030), (2030, 2040), (2040, 2050), (2050, 2060)]

# --- Formelparameter (Anhang B) ---------------------------------------------
LAM, GF, BETA, KAP, MU, SF, DS_MAX = 1.6, 1.3, 1.0, 0.11, 0.022, 22.0, 15.0

# --- Startlage 2026 (KKP je Kopf USD, Guete C) ------------------------------
Y0   = {"USA": 89000, "CHN": 30000, "EU": 65000, "IND": 12500, "RUS": 49000, "REST": 17000}
I    = {"USA": 1.00,  "CHN": 0.75,  "EU": 0.40,  "IND": 0.85,  "RUS": 0.45,  "REST": 0.15}   # [K] kalibriert 02.09.2026
S0   = {"USA": 22,    "CHN": 41,    "EU": 22,    "IND": 31,    "RUS": 24,    "REST": 25}
A0   = {"USA": 1.5,   "CHN": 22,    "EU": 4,     "IND": 42,    "RUS": 6,     "REST": 30}
# Erwerbsbevoelkerung 15-64, %/a (WPP 2024 nach Anhang A; USA/RUS/REST Setzung)
def n_wa(f, t):
    if f == "USA":  return 0.15 if t < 2035 else 0.0
    if f == "CHN":  return -0.5 if t < 2035 else -1.5
    if f == "EU":   return -0.27
    if f == "IND":  return 0.76 if t < 2040 else 0.14
    if f == "RUS":  return -0.4
    if f == "REST": return 1.4 if t < 2040 else 1.0
# Gesamtbevoelkerung %/a (fuer y je Kopf)
def n_pop(f, t):
    return {"USA": 0.37, "CHN": (-0.2 if t < 2040 else -0.5), "EU": -0.1,
            "IND": (0.7 if t < 2045 else 0.4), "RUS": -0.23, "REST": 1.0}[f]
# Strukturwandel: Agraranteil sinkt; Investitionsquote Chinas normalisiert sich
def a_share(f, t):
    d = {"CHN": 0.7, "IND": 1.0, "REST": 0.5}.get(f, 0.0)
    return max(A0[f] - d * (t - 2026), 3.0)
def s_quote(f, t):
    if f == "CHN": return max(41 - 0.5 * (t - 2026), 30)
    return S0[f]

def g_formel(f, y, yF, t):
    lam = LAM * I[f] * math.log(yF / y) if I[f] >= 0.15 else 0.0
    dem = BETA * max(-1.0, min(1.0, n_wa(f, t)))
    akk = KAP * min(s_quote(f, t) - SF, DS_MAX)
    strk = min(MU * I[f] * max(a_share(f, t) - 5, 0), 1.5)
    return GF + lam + dem + akk + strk

def lauf():
    y = dict(Y0); out = {f: [] for f in Y0}
    for t in range(2026, 2061):
        yF = max(y.values())
        g = {f: g_formel(f, y[f], yF, t) for f in y}
        for f in y:
            out[f].append((t, g[f]))
            y[f] *= 1 + (g[f] - n_pop(f, t)) / 100      # je-Kopf-Fortschreibung
    return out

res = lauf()
print(f"{'Block':6} {'Fenster':10} {'Formel':>8} {'Tafel':>7} {'Diff':>6}")
maxabs = 0.0
for f in TAFEL:
    for (a, b), tafel in zip(FENSTER, TAFEL[f]):
        vals = [g for (t, g) in res[f] if a <= t < b]
        m = sum(vals) / len(vals)
        d = m - tafel; maxabs = max(maxabs, abs(d)) if f != "RUS" else maxabs
        print(f"{f:6} {a}-{b}  {m:8.2f} {tafel:7.2f} {d:+6.2f}")
print(f"\nGroesste Abweichung (ohne RUS, dessen Tafel Krieg/Sanktionen enthaelt): {maxabs:.2f} Pp")
# Welt 2026
w = {"USA": 0.15, "CHN": 0.19, "EU": 0.15, "IND": 0.08, "RUS": 0.03, "REST": 0.40}
g26 = {f: res[f][0][1] for f in res}
print("Welt 2026 (KKP-gewichtet):", round(sum(w[f] * g26[f] for f in w), 2), "%  | je Block:",
      {f: round(v, 2) for f, v in g26.items()})
