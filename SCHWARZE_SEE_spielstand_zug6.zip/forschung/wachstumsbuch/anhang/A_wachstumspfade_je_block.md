# Anhang A — Recherche »Wachstumspfade je Block« (Agent A, 02.09.2026)

*Rohbericht des Rechercheagenten, unverändert. Gütemarken: A belegt · B abgeleitet · C geschätzt.*

---

## 1. Ergebnistabelle: reales BIP-Wachstum, %/a (Zentralwert; Bandbreite)

| Block | 2025–2030 | 2030–2040 | 2040–2050 | 2050–2060 | 2060–2080 (Ausblick) |
|---|---|---|---|---|---|
| **USA** | **2,0** (1,7–2,3) [1,2,5] | **1,7** (1,3–2,1) [5,25,27] | **1,6** (1,2–2,0) [5,27] | **1,5** (1,0–1,9) [4,27] | 1,3 (0,8–1,8) [3,4] |
| **China** | **4,3** (4,0–5,0) [1,2] | **3,0** (2,0–3,7) [5,12,13,14] | **2,2** (1,3–3,0) [11,13,14] | **1,6** (0,9–2,5) [11] | 1,2 (0,5–2,0) [11,3] |
| **EU** | **1,2** (0,9–1,5) [1,15] | **1,3** (1,0–1,6) [15] | **1,2** (0,8–1,5) [15,5] | **1,1** (0,7–1,5) [15,4] | 1,0 (0,6–1,4) [15] |
| **Indien** | **6,5** (6,0–7,2) [1,2] | **5,4** (4,5–6,3) [5,12,14] | **4,5** (3,5–5,5) [5,11] | **3,6** (2,5–4,5) [11,3] | 2,8 (1,8–3,8) [3,11] |
| **Russland** | **0,9** (0,5–1,3) [1,2] | **1,0** (0,3–1,6) [5,16,17] | **0,9** (0,2–1,5) [5,18] | **0,8** (0,0–1,4) [18,20] | 0,7 (−0,2–1,3) [18] |
| **Rest der Welt** | **3,2** (2,9–3,6) [1,2,B] | **3,0** (2,5–3,5) [B,5] | **2,7** (2,2–3,3) [B,5] | **2,4** (1,8–3,0) [B,3] | 2,1 (1,5–2,7) [B,3] |
| *Welt (implizit, feste PPP-Gewichte 2025)* | *3,15* | *2,74* | *2,36* | *1,98* | *1,7* |
| *Welt (OECD-Referenz)* | *2,9* [3] | *2,7 (Anf. 2030er)* [3] | *2,1 (Anf. 2040er)* [3] | *≈1,3 (2. Jhd.-Hälfte)* [3] | *1,3* [3] |

**B** = eigene Ableitung (Gütemarke B), Gewichtung siehe §2.6. Die Welt-Zeile dient nur der Plausibilitätsprüfung; sie liegt konstruktionsbedingt über der OECD-Referenz, weil feste Gewichte den schrumpfenden Anteil der schnell wachsenden Blöcke nicht abbilden. **Für Spielzwecke gilt die Blockzeile, nicht die Weltzeile.**

---

## 2. Treiberanalyse je Block

### 2.1 USA
Die Erwerbsbevölkerung ist der bindende Faktor. Die Fed stellt fest, dass das US-Arbeitskräfteangebot bei niedriger Nettozuwanderung und Alterung auf **nahezu null Wachstum** zusteuert; jedes Potenzialwachstum müsste dann vollständig aus Produktivität kommen [26]. Die UN WPP 2024 erwartet 347 Mio (2025) → 381 Mio (2050), also +0,37 %/a Gesamtbevölkerung — ausschließlich zuwanderungsgetragen [22]. Alterung kostete 1980–2010 rund **0,3 pp/a** Pro-Kopf-Wachstum [27]. Fernald taxiert das langfristige US-Wachstum auf gut 1,5 %/a bei Pro-Kopf-Wachstum deutlich unter 1 % [25], Gordon auf 1,3 %/a Arbeitsproduktivität und 0,9 %/a Pro-Kopf-Output für 25–40 Jahre nach 2007 [28]. Kurzfristig liegt der IWF mit 2,1/2,3/2,1 % (2025/26/27) über diesem Trend [1]. Die USA sind der einzige alternde Block ohne strukturellen Erwerbsbevölkerungsschrumpf — der Zuwanderungshebel ist daher der entscheidende Szenarioparameter (±0,4 pp).

### 2.2 China
Doppelter Gegenwind. Die Erwerbsbevölkerung (15–64) fällt von 984 Mio (2024) auf 745 Mio (2050) [23] — eigene Umrechnung: **−0,5 %/a bis 2035, danach −1,5 %/a, im Schnitt −1,07 %/a**. Zweitens bricht die TFP weg: Brandt et al. führen die Verlangsamung nach 2007 auf gestoppte Reallokation, Kapitalfehlleitung in Infrastruktur/Wohnbau und sinkende Kapitalrenditen zurück [siehe 12-Kontext]. Die ADB projiziert Potenzialwachstum von 5,3 % (2020–2025) auf **2,0 % in 2036–2040** [13]; García-Herrero kommt auf **2,4 % bis 2035** [14]; Lee & Lee auf **0,9–2,5 % in 2051–2070** [11]. Goldman Sachs sieht China ab ca. 2035 als größte Volkswirtschaft [6], die OECD erst ab Mitte der 2060er von Indien überholt [3]. Kapitalvertiefung ist weitgehend ausgereizt (sinkende Grenzproduktivität), TFP-Konvergenz zur Frontier wird durch Exportkontrollen und Staatsanteil gebremst.

### 2.3 EU
Der EU-Ageing-Report 2024 ist hier die belastbarste Primärquelle: **reales BIP-Wachstum 1,3 %/a im Mittel 2022–2070**, Arbeitsproduktivität +1,4 %/a (davon TFP 0,9 pp, Kapitalvertiefung 0,5 pp), TFP konvergiert langfristig auf 0,8 % (Abwärtsrevision gegenüber 1,0 % im Report 2021) [15]. Die Erwerbsbevölkerung 20–64 sinkt um **12 % bzw. 25 Mio zwischen 2022 und 2070 ≈ −0,27 %/a** [15]; die Erwerbsquote 20–64 steigt kompensierend von 79,4 % auf 82,7 %, die der 55–64-Jährigen von 65,4 % auf 75,5 % [15]. Der IWF sieht die Eurozone 2025–2027 bei 1,4/1,1/1,2 % [1]. Die EU ist damit der Block mit der **flachsten** Kurve: kaum Konvergenzpotenzial (nahe Frontier), moderater Demografiedruck, aber auch wenig Absturzrisiko.

### 2.4 Indien
Erwerbsbevölkerung 990 Mio (2024) → 1.118 Mio (2040) → 1.134 Mio (2050) [23], eigene Umrechnung: **+0,76 %/a bis 2040, danach nur noch +0,14 %/a**. Das Dividendenfenster wird auf **2011–2041** datiert [30]; Mody & Aiyar schätzen den demografischen Beitrag auf **≈2 pp/a** Pro-Kopf-Wachstum über zwei Dekaden [29]. IWF/Weltbank sehen 6,5–7,7 % bis 2028 [1,2]. Nach 2040 kippt die Demografie von Rückenwind auf neutral — genau dort setzt die Regression zum Mittelwert an. Lee & Lee erwarten, dass Indien die USA bis 2050 im BIP (KKP) und potenziell China bis 2070 überholt [11]. Indien ist der Block mit der **größten Bandbreite**: die Differenz zwischen 4,5 % und 6,3 % in den 2030ern ist keine Messfrage, sondern eine Reform- und Industrialisierungsfrage.

### 2.5 Russland
Kriegs- und Sanktionswirtschaft. Der IWF sieht 2025/26/27 bei **1,0/1,1/1,1 %** [1], die Weltbank noch niedriger bei **1,0/0,8/0,7/0,7 %** (2025–2028) [2]. Für 2022–2026 kumuliert erwarten Vedev et al. ein BIP-Niveau von nur **+5,6 bis +7,8 % gegenüber 2021** — also ≈1,1–1,5 %/a im Fünfjahresmittel [16]. Pesotskiy bestätigt für 2025 eine deutliche Abbremsung nach drei resilienten Jahren [17]. Langfristig: Baqaee et al. beziffern den Sanktionseffekt auf dem Wachstumspfad mit **−8,5 % Langfristkonsum** in Russland (bei Handelselastizität 4), wobei Kapitalanpassung den Verlust *verstärkt* statt abmildert [18]. Demografie: 144 Mio (2025) → 136 Mio (2050) [22] = −0,23 %/a Gesamtbevölkerung; Aleksashenko sah die Erwerbsbevölkerung um 8–12 % (2015–2020) und weitere 10–20 % nach 2030 fallen, Abhängigenquotient von 2,5 auf ≈1,6 bis 2045 [19]. Hinzu kommen Braindrain und Kapitalabfluss [20]. PwC (2017, Vorkriegsstand) mit 1,9 %/a für 2016–2050 [5] markiert die **obere Grenze**, nicht den Zentralwert.

### 2.6 Rest der Welt (Aggregat)
Komponenten und Gewichte (KKP-Anteile innerhalb RoW, grob geschätzt, **Gütemarke C**): Japan+Korea 12 %, ASEAN 15 %, übriges Asien 10 %, Lateinamerika 20 %, Afrika 15 %, Nahost 18 %, Rest 10 %. Belegte Komponentenwerte: Japan 1,2/0,7/0,6 % (2025–27) [1], ASEAN-5 4,5/4,1/4,4 % [1] bzw. Ostasien-Pazifik 5,0/4,2/4,3/4,2 % [2], Subsahara-Afrika 4,5/4,3/4,4 % [1] bzw. 4,1/4,0/4,4/4,5 % [2], Lateinamerika 2,4/2,3/2,7 % [1] bzw. 2,3/2,2/2,5/2,6 % [2]. Gewichteter Mittelwert (eigene Rechnung, **B**): **3,17 / 3,03 / 2,74 / 2,40 %** für die vier Fenster. Warnung der Weltbank: EMDEs **ohne** China und Indien stehen vor „nearly a decade of lost convergence" [2] — der RoW-Pfad darf also nicht als automatische Aufholgeschichte modelliert werden.

---

## 3. Widersprüche und Bandbreiten

**(a) China 2040 — Goldman vs. OECD.** Goldman Sachs (Path to 2075) lässt China die USA bereits **um 2035** überholen [6]; die OECD 2025 sieht China bis **Mitte der 2060er** als größte Volkswirtschaft, dann von Indien abgelöst [3]. Eine Sekundärwiedergabe der GS-Dekadenwerte nennt für China „gut 4 %" (2024–29), **2,5 % in den 2030ern, unter 2 % in den 2040ern** [7] — das ist *pessimistischer* als der PwC-Durchschnitt von 3,0 % (2016–2050) [5] und liegt nahe der ADB (2,0 % in 2036–40) [13]. Achtung: dieselbe Sekundärquelle nennt globales Wachstum von 4,2 % für 2024–29, während GS selbst 2,8 % ausweist [6] — die Werte in [7] sind vermutlich teils nominal; deshalb Gütemarke C. **Belastbarer Korridor China 2040er: 1,3–3,0 %/a.**

**(b) Trendwachstumsniveau OECD vs. IWF.** Der IWF sieht die Welt 2026/27 bei 3,1/3,2 % [1], die Weltbank bei 2,5/2,8 % [2], die OECD das *Potenzial*wachstum bei 2,9 % [3]. Bis 0,6 pp Differenz allein im Basisjahr — für ein Spiel, das Schocks in Wachstumspunkten misst, ist das relevant.

**(c) Sind die SSP-Pfade zu optimistisch?** Dellink et al. und Leimbach et al. liefern den Standard-Korridor (globales Pro-Kopf-Wachstum 1,0 % SSP3 bis 2,8 % SSP5, 2010–2100) [8,9], aktualisiert von Koch & Leimbach [10]. Buhaug et al. kritisieren jedoch, dass das SSP-Portfolio **zu schmal** sei und Wachstumsunterbrechungen fehlen [31]. Burgess et al. kommen zu dem Schluss, SSP4 sei eher ein **Best-Case als ein Worst-Case** [32]; Moyer et al. projizieren mit International Futures systematisch **niedrigeres** Wachstum als die etablierten Forecasts [33]. Christensen/Gillingham/Nordhaus geben den ehrlichsten Unsicherheitsmaßstab: Median globales Pro-Kopf-Wachstum **2,1 %/a (2010–2100) bei SD 1,1 pp** [34] — das ist etwa das **Fünffache** der Spannweite, die institutionelle Baselines suggerieren.

**(d) Regression zum Mittelwert vs. „neue Konvergenz".** Pritchett & Summers: geringe Persistenz von Wachstumsraten ist der robusteste empirische Befund; Superwachstumsepisoden enden typisch in diskontinuierlichen Einbrüchen, und Chinas Merkmale (Staatskontrolle, Korruption, Autoritarismus) erhöhen diese Wahrscheinlichkeit zusätzlich [12]. Easterly et al. beziffern die Dekaden-Autokorrelation von Wachstumsraten auf **nur 0,1–0,3** [35]. Eichengreen/Park/Shin finden Verlangsamungen bei **zwei** Moden — 10.000–11.000 $ und 15.000–16.000 $ (2005er KKP) — Länder verlangsamen also in Stufen; China hat beide Schwellen bereits passiert [13]. Gegenposition: Patel/Sandefur/Subramanian zeigen seit Mitte der 1990er **unbedingte Konvergenz** und nennen die Middle-Income-Trap-Debatte „anachronistisch" [36]; Felipe et al. lehnen die Falle als generalisiertes Phänomen ab [37]. **Konsequenz für ERDE-01:** die Regression zum Mittelwert gehört als *stochastisches Element* ins Modell, nicht als deterministischer Abschlag.

**(e) Nicht belegt.** JCER-Asienprojektionen bis 2060, OECD-Länderwerte je Zeitfenster (Tabellen hinter robots.txt/Paywall), Goldman-Sachs-Originaltabelle je Dekade, CEPII-MaGE-Länderwerte für 2040/2050, sowie Erwerbsbevölkerungsraten (15–64, %/a) für USA und Russland aus WPP 2024 — **nicht belegt**.

---

## 4. Empfehlung für das Spiel

**Zentralpfad (Baseline).** Die Zentralwerte aus §1 verwenden. Sie sind so kalibriert, dass sie (i) im ersten Fenster mit IWF/Weltbank übereinstimmen [1,2], (ii) im Aggregat den OECD-Abflachungspfad reproduzieren [3,4] und (iii) je Block einen belegten Demografieanker haben [15,22,23,29,30].

**Mechanik statt Tabelle.** Wachstum pro Block als `g(t) = g_Demografie(t) + g_Produktivität(t)` führen, wobei `g_Demografie` fest exogen aus WPP 2024 kommt (China −0,5 → −1,5 %/a; Indien +0,76 → +0,14 %/a; EU −0,27 %/a; USA ≈0 ohne Zuwanderung; Russland negativ) und nur `g_Produktivität` durch Spielerhandlungen (Rüstungsquote, Sanktionen, Handelskrieg, Klima) modifiziert wird. Das verhindert, dass Spieler Demografie „wegspielen".

**Hochfall (P90).** Obere Bandgrenze plus 0,3 pp Frontier-TFP-Bonus ab 2035 (KI-/Automatisierungsschub, in [3] als Aufwärtsrisiko angelegt). USA 2,3 / China 3,7 / EU 1,6 / Indien 6,3 / Russland 1,6 / RoW 3,6 für 2030–2040.

**Tieffall (P10).** Untere Bandgrenze **plus** ein stochastischer Bruch: pro Block und Dekade 10–15 % Wahrscheinlichkeit einer „Diskontinuität" von −2 bis −4 pp für die Folgedekade, empirisch begründet durch Pritchett & Summers [12] und Easterly et al. [35]; für China nach Eichengreen/Park/Shin erhöht (Schwellen bereits überschritten) [13].

**Unsicherheitsband für Sensitivitätsläufe.** Als Streuungsmaß nicht die Institutionsspannen nehmen, sondern Christensen et al.: **SD 1,1 pp auf das Pro-Kopf-Wachstum** [34]. Wer nur mit ±0,3 pp spielt, unterschätzt die Ungewissheit um den Faktor 3–4.

**Konvergenzregel.** Alle Blöcke asymptotisch gegen ein Frontier-Produktivitätswachstum von 0,8–1,0 %/a laufen lassen (TFP-Annahme des Ageing Report 2024: 0,8 % [15]); Aufholbonus proportional zum Abstand zur US-Pro-Kopf-Frontier, mit Halbwertszeit ~30 Jahren.

---

## 5. Quellenregister

| # | Titel / Autoren / Jahr / Institution | URL / DOI | Güte |
|---|---|---|---|
| 1 | *World Economic Outlook, April 2026: Global Economy in the Shadow of War*, Tab. 1.1, IWF 2026 | https://www.imf.org/-/media/files/publications/weo/2026/april/english/text.pdf | **A** |
| 2 | *Global Economic Prospects, June 2026*, Ch. 1 Highlights, Weltbank 2026 | https://thedocs.worldbank.org/en/doc/2b672b3b0415d6b66c45b66579db4ef5-0050012026/related/GEP-Jun-2026-Chapter-1-Highlights.pdf | **A** |
| 3 | *OECD global long-run economic scenarios: 2025 update*, OECD Economic Policy Papers No. 36, 2025; Begleitblog Guillemette (ECOSCOPE, 08.09.2025) | https://www.oecd.org/en/publications/oecd-global-long-run-economic-scenarios_00353678-en.html · DOI 10.1787/00353678-en · https://oecdecoscope.blog/2025/09/08/new-oecd-long-run-scenarios-focus-on-the-trade-off-between-carbon-mitigation-and-climate-damage/ | **A** |
| 4 | Guillemette & Turner (2021), *The long game: Fiscal outlooks to 2060*, OECD EPP No. 29 | https://www.oecd.org/en/publications/the-long-game-fiscal-outlooks-to-2060-underline-need-for-structural-reform_a112307e-en.html · DOI 10.1787/a112307e-en | **A** |
| 5 | PwC (2017), *The World in 2050 – The Long View*, Tab. 3 | https://www.pwc.com/gx/en/world-2050/assets/pwc-the-world-in-2050-full-report-feb-2017.pdf | **B** |
| 6 | Daly & Gedminas (2022), *The Path to 2075*, Goldman Sachs Global Economics Paper; öffentl. Zusammenfassung | https://www.goldmansachs.com/insights/articles/the-global-economy-in-2075-growth-slows-as-asia-rises · https://cepr.org/voxeu/columns/path-2075-slower-global-growth-convergence-remains-intact | **B** |
| 7 | Andaman Partners (2025), *Pathways to 2050 and the New Global Markets That Matter* (Sekundärwiedergabe GS-Dekadenwerte; teils vermutlich nominal) | https://andamanpartners.com/2025/06/pathways-to-2050-and-new-global-markets-that-matter/ | **C** |
| 8 | [Long-term economic growth projections in the Shared Socioeconomic Pathways](https://consensus.app/papers/details/2cbbd539375b54c3bb4dfad622c56479/?utm_source=claude_desktop) (Dellink et al., 2015, Global Environmental Change) | DOI 10.1016/j.gloenvcha.2015.06.004 | **A** |
| 9 | [Future growth patterns of world regions – A GDP scenario approach](https://consensus.app/papers/details/b0e60e079cbc5609adb1a6ffc2a1b966/?utm_source=claude_desktop) (Leimbach et al., 2015, Global Environmental Change) | DOI 10.1016/j.gloenvcha.2015.02.005 | **A** |
| 10 | [SSP economic growth projections: Major changes of key drivers in integrated assessment modelling](https://consensus.app/papers/details/2377c02cda4b5a72994212b6e3249f49/?utm_source=claude_desktop) (Koch & Leimbach, 2023, Ecological Economics) | DOI 10.1016/j.ecolecon.2023.107751 | **A** |
| 11 | [Demographic Change and Long-Term Economic Growth Path in Asia](https://consensus.app/papers/details/e0ea1e7cc9fb57e2be7d7703b72464ec/?utm_source=claude_desktop) (Lee & Lee, 2025, Economic Modelling) | DOI 10.1016/j.econmod.2025.107043 | **A** |
| 12 | [Asiaphoria Meets Regression to the Mean](https://consensus.app/papers/details/19c4f4ff86d7550782921a97a3e6c17b/?utm_source=claude_desktop) (Pritchett & Summers, 2014, NBER WP 20573) | DOI 10.3386/w20573 | **A** |
| 13 | [Growth Slowdowns Redux: New Evidence on the Middle-Income Trap](https://consensus.app/papers/details/2299d33040d75696afb9297338a94b60/?utm_source=claude_desktop) / [Growth slowdowns redux](https://consensus.app/papers/details/8aa8025dc6515c8db547bb41580c7292/?utm_source=claude_desktop) (Eichengreen, Park & Shin, 2013/2014) | DOI 10.3386/w18673 · 10.1016/j.japwor.2014.07.003 | **A** |
| 14 | [Reforms to Boost Long-Term Growth in the People's Republic of China](https://consensus.app/papers/details/1c91d5b48ec554da84498cd55b41bc08/?utm_source=claude_desktop) (ADB, 2023) | DOI 10.22617/brf230062-2 | **A** |
| 15 | Europäische Kommission (2024), *2024 Ageing Report 2022–2070* (Spiegel-PDF) | https://www.sozialministerium.gv.at/dam/jcr:00454d29-843a-4427-ade9-132b07e22aae/The%202024%20Ageing%20Report%202022-2070.pdf | **A** |
| 16 | [High risks and weak pace of economic growth: Russia macroeconomic forecast](https://consensus.app/papers/details/7b747f2958175644aab1a6027fe368c1/?utm_source=claude_desktop) (Vedev et al., 2024, Voprosy Ekonomiki) | DOI 10.32609/0042-8736-2024-2-5-22 | **A** |
| 17 | [The pressure of sanctions on the Russian economy and its regions. A view from 2026](https://consensus.app/papers/details/a67d4c5eea465198b55a068ffaa37c51/?utm_source=claude_desktop) (Pesotskiy, 2026, KANT) | DOI 10.24923/2222-243x.2026-58.38 | **B** |
| 18 | [Long-Run Consequences of Sanctions on Russia](https://consensus.app/papers/details/0109848ca3fc5063b960abd57efeeba1/?utm_source=claude_desktop) (Baqaee et al., 2025, NBER 33506) | DOI 10.3386/w33506 | **A** |
| 19 | Aleksashenko (2015), *The Russian economy in 2050: Heading for labor-based stagnation*, Brookings | https://www.brookings.edu/articles/the-russian-economy-in-2050-heading-for-labor-based-stagnation/ | **C** |
| 20 | [Long-term business implications of Russia's war in Ukraine](https://consensus.app/papers/details/36edf8db8fe95728a99e40a351441ded/?utm_source=claude_desktop) (Markus, 2022, Asian Business & Management) | DOI 10.1057/s41291-022-00181-7 | **A** |
| 21 | UN DESA (2024), *World Population Prospects 2024: Summary of Results* | https://population.un.org/wpp/assets/Files/WPP2024_Summary-of-Results.pdf | **A** |
| 22 | INED (2024), *Projections by countries* (nach UN WPP 2024) | https://www.ined.fr/en/everything_about_population/data/world-projections/projections-by-countries | **A** |
| 23 | Visual Capitalist (2025), *India vs. China Working Age Populations 2024–2050* (UN-Daten via OPEC WOO 2025); %/a-Umrechnung eigene Rechnung | https://www.visualcapitalist.com/charted-india-vs-china-working-age-populations-2024-2050/ | **C** (Raten: **B**) |
| 24 | Capital Economics (2023), *What will the global economy look like in 2050?* | https://www.capitaleconomics.com/what-will-global-economy-look-2050 | **C** |
| 25 | [Reassessing Longer-Run U.S. Growth: How Low?](https://consensus.app/papers/details/52706059198f5a1da21c3ba43d09148e/?utm_source=claude_desktop) (Fernald, 2016, FRBSF WP) | DOI 10.24148/wp2016-18 | **A** |
| 26 | [Labor force growth, breakeven employment, and potential GDP growth](https://consensus.app/papers/details/3ebe59893c805ebd8dd707b432304bf7/?utm_source=claude_desktop) (Murray et al., 2026, FEDS Notes) | DOI 10.17016/2380-7172.4045 | **A** |
| 27 | [The Effect of Population Aging on Economic Growth, the Labor Force, and Productivity](https://consensus.app/papers/details/f30fd7630ca152da8442d62b2fab25cb/?utm_source=claude_desktop) (Maestas, Mullen & Powell, 2016, AEJ: Macro) | DOI 10.3386/w22452 | **A** |
| 28 | [The Demise of U.S. Economic Growth](https://consensus.app/papers/details/1dd412adda2d5f7ca012d6b27f31e4db/?utm_source=claude_desktop) (Gordon, 2014, NBER 19895) | DOI 10.3386/w19895 | **A** |
| 29 | [The Demographic Dividend: Evidence from the Indian States](https://consensus.app/papers/details/5ad67379bbaf5ccfb66ae067ec24d994/?utm_source=claude_desktop) (Aiyar & Mody, 2011, IMF/SSRN) | DOI 10.5089/9781455217885.001.a001 | **A** |
| 30 | [Potential demographic dividend for India, 2001 to 2061](https://consensus.app/papers/details/06666238e5695b899904b9602a97b2fe/?utm_source=claude_desktop) (Jain & Goli, 2021/22, SN Social Sciences) | DOI 10.1007/s43545-022-00462-0 | **A** |
| 31 | [On Growth Projections in the Shared Socioeconomic Pathways](https://consensus.app/papers/details/819345e5250a59e4b10f24b27b0524eb/?utm_source=claude_desktop) (Buhaug et al., 2019, Global Environmental Politics) | DOI 10.1162/glep_a_00525 | **A** |
| 32 | [Multidecadal dynamics project slow 21st-century economic growth and income convergence](https://consensus.app/papers/details/f3c11459c76457348ca5dae312e71ffc/?utm_source=claude_desktop) (Burgess et al., 2023, Commun. Earth Environ.) | DOI 10.1038/s43247-023-00874-7 | **A** |
| 33 | [Broadly quantifying SSP elements for 188 countries to 2150 in International Futures](https://consensus.app/papers/details/827fa652579850a6aaeb312a5b6c463d/?utm_source=claude_desktop) (Moyer et al., 2026, Nature Communications) | DOI 10.1038/s41467-026-73836-0 | **A** |
| 34 | [Uncertainty in forecasts of long-run economic growth](https://consensus.app/papers/details/8ebd53f739b05699bbde8049c050a2d5/?utm_source=claude_desktop) (Christensen, Gillingham & Nordhaus, 2018, PNAS) | DOI 10.1073/pnas.1713628115 | **A** |
| 35 | [Good Policy or Good Luck? Country Growth Performance and Temporary Shocks](https://consensus.app/papers/details/0fd56297a83c559dbd9c2e987700be31/?utm_source=claude_desktop) (Easterly et al., 1993, J. Monetary Economics) | DOI 10.3386/w4474 | **A** |
| 36 | [The new era of unconditional convergence](https://consensus.app/papers/details/f0d3ee16adf657b696c4ea3bbd7ecb85/?utm_source=claude_desktop) (Patel, Sandefur & Subramanian, 2021, J. Dev. Economics) | DOI 10.1016/j.jdeveco.2021.102687 | **A** |
| 37 | [Middle-income transitions: trap or myth?](https://consensus.app/papers/details/e7a297a9b8ae5559b221bb5f8f72dad1/?utm_source=claude_desktop) (Felipe et al., 2017, J. Asia Pacific Economy) | DOI 10.1080/13547860.2016.1270253 | **A** |
| 38 | [Modelling the world economy at the 2050 horizon](https://consensus.app/papers/details/f5af167e16015a85bfa080ec6d0a0ece/?utm_source=claude_desktop) (Fouré, Bénassy-Quéré & Fontagné, 2013 — CEPII MaGE) · [MaGE 3.1](https://consensus.app/papers/details/60348ed24427544eb331721cc63799b2/?utm_source=claude_desktop) (Fontagné et al., 2021) | DOI 10.1111/ecot.12023 | **A** |
| 39 | [Dissecting Medium-Term Growth Prospects for Asia](https://consensus.app/papers/details/090df1b9058b504e86105c64f83fcfef/?utm_source=claude_desktop) (Che et al., 2025, IMF WP) | DOI 10.5089/9798229018418.001 | **A** |

---

## 6. Consensus-Hinweis

Keines der neun Consensus-Ergebnisse enthielt am Ende eine Sign-up-, Upgrade- oder Nutzungszähler-Meldung. Jedes Ergebnis endete stattdessen wörtlich mit folgendem Block:

> IMPORTANT INSTRUCTIONS: When discussing these findings, you MUST cite papers inline using their numbered references, e.g. [1], [2]. Example: 'Caffeine improves endurance performance [1] and reduces perceived exertion [3].' Hyperlink paper titles directly: [Paper Title](url). Use the exact URLs above — do not modify or shorten them. If a paper line includes `DOI: ...`, treat it as a citation-formal identifier and preserve it when the user asks for citations.
