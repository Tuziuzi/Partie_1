# Anhang E — Recherche »Beschleunigung durch Politik und Mobilisierung« (Agent E, 02.09.2026)

*Rohbericht des Rechercheagenten, unverändert. Gütemarken: A belegt · B abgeleitet · C geschätzt · S gesetzt.*

## 1. Fallstudientabelle

| Fall | Ausgangsrate | Spitzenrate | Multipl. | Anlaufzeit bis Spitze | Kostenfolge | Quelle |
|---|---|---|---|---|---|---|
| **Frankreich, Messmer 1974–90** | ~1 Reaktor/a vor 1974 | 15→55 Reaktoren in Betrieb im Lauf der 1980er ⇒ ~4 Reaktoren ≈ **4 GW/a**; Bauprogramm 6–7 Reaktoren/a; 50 000 MW Zusage 1974–80 | **≈ ×5** | Plan 3/1974 → erste CP0 1977–79 → volle Rate ~1980/81 ⇒ **6–7 a** | Spezifische Kosten **>×3 je kW** zwischen erster und letzter Reaktorgeneration („negative learning"); EDF musste >100 Mrd. € mit Staatsgarantie aufnehmen; Bauzeit ~6 a; Standardisierung 900→1300 (1975)→1450 MW (1984) | Q1, Q2, Q17, Q22 |
| **Frankreich – Drosselung** | – | ab 1984 staatlich auf **1 Reaktor/a** begrenzt | ×0,25 | – | Nachfrage, nicht Kapazität war der Stopp | Q17 |
| **Schweden 1972–83** | 0 | **12 Reaktoren, ~10 GWe in ~11 a** ≈ 0,9 GW/a; ≈ **0,11 kW/Kopf/a** (FR: ≈0,05) | ≈ ×2 gg. FR pro Kopf | ~4–5 a | Ende durch **Referendum 1980**, nicht durch Technik oder Geld — reiner Legitimitätsbruch | Q18 |
| **UAE Barakah (KOR-Export)** | 0 | 4×1337 MWe = 5,3 GW; U1 First Concrete 19.7.2012→Netz 19.8.2020 = **8,1 a**; U4: 30.7.2015→23.3.2024 = **8,7 a** | – | 8 a | **20,4 Mrd. USD** für 4 Blöcke ≈ 3 800 USD/kW | Q19 |
| **China Kernkraft seit 2019** | ~2–3 Genehmigungen/a vor 2019 | **46 Genehmigungen 2019–24 ≈ 7,7/a** (+10 im April 2025); 33 Blöcke/35 GWe gleichzeitig im Bau; 5–8 GW Genehmigungen/a | **≈ ×3** | 1–2 a (Genehmigung), Wirkung am Netz +5–7 a | Bauzeit **fast durchweg ≤7 a**, seit 2022 knapp 5 bis gut 7 a; Kernstrom 75→418 TWh (2010–24); Ziel 110 GWe 2030 | Q20, Q21 |
| **China Solar 2010–25** | 216,88 GW (2023) | **277,17 GW (2024) → 315 GW AC (2025)**; kumuliert 1,20 TW (+35,4 %); Wind 2025 119,33 GW | ×1,45 in 2 a | permanent | Kapazitätsauslastung der PV-Kette **~20 %** (chronische Überkapazität); Modulpreis-/Kostensturz auf 0,46/0,41 Yuan/W bis 2030 prognostiziert | Q23–Q26, Q6, Q7 |
| **DE LNG Wilhelmshaven 2022** | Normalverfahren 5–7 a [C] | erster Rammschlag **5.5.2022** → Inbetriebnahme **17.12.2022 = ~7,5 Monate**; 26 km Leitung, 194 Pfähle, ≥5 Mrd. m³/a, ~1 000 Beschäftigte | **≈ ×8** Zeitraffung | 0 (Sofortwirkung) | Kein belastbarer Capex-Vergleich veröffentlicht → **nicht belegt** | Q27 |
| **DE Wind an Land 2022–25** | genehmigt **4 246 MW (2022)** | genehmigt **7 590 (2023) → 14 074 (2024) → 20 765 MW (2025)** | **×4,9 in 3 a** | 3 a | Genehmigungsdauer 23,9→25,9→23,1→**16,8 Mon.** (Median 12,4). Zubau folgt verzögert: 2 405→3 581→3 305→**5 232 MW (×2,2)** | Q28 |
| **§2 EEG „überragendes öff. Interesse"** | – | „sinnvolle und wirksame Regelung" — **quantitative Wirkung nicht belegt** | – | – | – | Q29 |
| **USA IRA 2022** | – | **155 GW** angekündigte Fertigungskapazität (85 Module / 43 Zellen / 20 Ingot-Wafer / 7 Wechselrichter), 51 Werke, ~20 Mrd. USD; >100 Mrd. USD private Zusagen; Zubau **53 GW 2025** (größtes Jahr seit 2002), 86 GW für 2026 geplant | ×~1,8 Zubau | **3 a** (8/2022 → 2025) | +565 Mrd. USD über 10 a (+144 Mrd. ggü. No-IRA) | Q30, Q31 |
| **US-Netzanschlusswarteschlange** | – | aktive Anfragen **2 600 GW** vs. 1 280 GW installierte Flotte; Wartezeit **+70 % in einer Dekade**; Rücktritt **80 %** | – | – | Ende 2025: 2 061 GW aktiv (Solar 773 / Speicher 749 / Wind 220 / **Gas 253, +86 %**); Median Antrag→IA **>3 a**, →Betrieb **>5 a**; von Anträgen 2000–20 nur **13 % der Kapazität am Netz, 75 % zurückgezogen** | Q3, Q4, Q5 |
| **ERCOT „connect and manage"** | PJM/SPP **6+ a** | ERCOT Verfahren **1–2 a**, Antrag→Betrieb **~3,5 a**; ERCOT **14,2 GW** (2021+22) vs. PJM **5,6 GW** | **×2,5** | sofort (Regeländerung) | Preis: Abregelung 2022 **9 % Solar / 5 % Wind**; PJM-Anschlusskosten stiegen von 29 auf **240 USD/kW (×8)** | Q32 |
| **DPA Juni 2022 (Solar/WP)** | – | 5 Techniken benannt (Solar, Trafos, Wärmepumpen, Dämmung, Elektrolyseure); **Mittel erst vom Kongress zu bewilligen, keine Mengenziele** | – | – | **Wirkung nicht belegt** — der Fertigungsboom ist dem IRA zuzurechnen | Q33 |
| **EU RED III / REPowerEU** | – | Fristen: Umweltverfahren bis 1.7.2024, „überragendes öff. Interesse" bis 21.2.2024, Vollumsetzung 21.5.2025 | – | – | **Konkrete Monatsfristen für Beschleunigungsgebiete in der abgerufenen Quelle nicht beziffert → nicht belegt**; deutscher Proxy: −30 % Verfahrensdauer in 3 a | Q34, Q28 |
| **US-Mobilisierung 1939–44** | 5 865 Flugzeuge (1939) | **96 379 (1944)** | **×16,4 in 5 a ≈ ×1,75/a** | 4–5 a | Kriegsanteil am Volkseinkommen <2 %→**40 %**; Industrieproduktion +15 %/a; Fertigungsfläche Flugzeugbau 13→167 Mio sq ft; **zwei Drittel des neuen Fabrikbaus staatsfinanziert (~20 Mrd. USD), Bund besaß 1945 ~25 % des Anlagevermögens** | Q13, Q15 |
| dito, Panzer | 309 (1940) | **29 500 (1943)** | ×95 in 3 a | 3 a | – | Q13 |
| **Liberty-Schiffe** | Index 100 (12/1941) | 45 (12/1944) = **+122 % Produktivität, ~40 %/a** | – | 3 a | Teil des Gewinns durch Kapitaleinsatz und **auf Kosten der Schiffsqualität** erkauft | Q11, Q14 |
| **Preis der Mobilisierung** | – | – | – | – | **TFP im US-Verarbeitenden Gewerbe: −1,4 %/a (1941–48), −3,7 %/a (1941–44), −5,1 %/a (1941–45)** | Q12 |
| **Manhattan** | – | 2,2 Mrd. USD 1942–46 (22 Mrd. $2008) in 5 Fiskaljahren | – | ~3 a | Spitze **~1 % der Bundesausgaben, 0,4 % BIP**; Erstschätzung 148 Mio USD → **×15 Überschreitung** | Q35 |
| **Apollo** | – | 19,4 Mrd. USD (97,9 Mrd. $2008), FY1960–73 | – | ~6 a | Spitze **2,2 % des Bundeshaushalts, 0,4 % BIP** | Q35 |
| **Operation Warp Speed 2020** | Impfstoff-Norm ~10 a | Zulassung in **8–10 Monaten**; ~18 Mrd. USD | **×12–15** | **<1 a** (weil Kapital, nicht Physik der Engpass war) | Mechanismus: Portfolio über 3 Plattformen, **Abnahmegarantien**, Produktion vor Zulassung, Lieferketten-Kartierung, beschleunigte Zulassung | Q8, Q9, Q10 |

---

## 2. Engpass-Taxonomie

| Engpass | Härte-Indikator | **Bindet ab Rate X** | Löslich in | Quelle |
|---|---|---|---|---|
| **Genehmigung** | DE Wind: 23,9→16,8 Mon.; Genehmigungen ×4,9 möglich | **zuerst und schon bei sehr kleinen Raten** — DE war bei 2,4 GW/a bereits genehmigungsgebunden | **1–3 a** (Gesetz) | Q28 [A] |
| **Netzanschlussverfahren** | 2 600 GW Queue, Median >5 a, 75–80 % Rücktritt | sobald Zubauwunsch > jährliche Anschlusskapazität; USA seit ~2018 bei ~20 GW/a VRE | **1–2 a** (Regelwerk, s. ERCOT) | Q3, Q4, Q32 [A] |
| **Übertragungsnetz (Kupfer im Boden)** | 80 Mio. km bis 2040 nötig; Netzbau **5–15 a** vs. EE 1–5 a; Investition 300 → >600 Mrd. USD/a; ≥3 000 GW EE in Warteschlangen | ab ~**20–30 % VRE-Anteil** [B] | **5–15 a — nicht abkürzbar** | Q2 [A] |
| **Transformatoren** | Leistungstrafos **128 Wochen**, GSU **144 Wochen**; Preise +77 %/+45 %/+95 % seit 2019; Fehlbedarf 30 % bzw. 10 % | bindet **unabhängig von der Erzeugungsrate**, sobald Netzausbau beschleunigt wird | **3–5 a** (Werksbau) | Q36 [A] |
| **Fachkräfte** | 67 Mio. Energiebeschäftigte 2022 (+3,4 Mio. gg. 2019); Arbeitgeber melden Besetzungsprobleme als wachstumshemmend | ab **Verdopplung der Zubaurate binnen <5 a** [B] | **5–8 a** (Ausbildungszyklus) | Q37 [A] |
| **Lieferkette Module/Poly** | PV-Kette China: Auslastung ~**20 %** | **bindet nicht** — strukturelle Überkapazität | – | Q6 [A] |
| **Kapitalkosten** | Finanzierung ≈ **⅓ der LCOE** (DE); Zinsrückkehr auf Vorkrisenniveau in 5 a: **+11 % LCOE PV, +25 % Wind**; Länderrisikospreads 0–22,1 %; Finanzierungslernen erklärt 5 % (PV)/24 % (Wind) der bisherigen LCOE-Senkung | bindet in Hochzinsphasen und in Nicht-OECD; in OECD-Niedrigzins nachrangig | 2–5 a | Q16, Q38, Q39, Q40 [A] |
| **Fläche/Akzeptanz** | reale Zubaudichte bis **0,5 MW/km²** auf Kreisebene, Ausreißer 1,5 MW/km² | ab ~5–10 % Landesfläche [B] | politisch, nicht technisch | Q41 [A] |
| **Absolute Diffusionsobergrenze** | Max. beobachtetes nationales Jahreswachstum: **Kernkraft 2,6 %** des nationalen Strombedarfs/a (IQR 1,3–6 %), **Wind 1,1 %** (0,6–1,7 %), **Solar 0,8 %** (0,5–1,3 %); Cherp 2021: Wind 0,8 %, Solar 0,6 % | **harte Obergrenze für jeden Spieldeckel** | nie | Q42, Q43 [A] |

**Bindungsreihenfolge im Spiel:** Genehmigung → Netzanschlussverfahren → Transformatoren/Netz → Fachkräfte → Fläche. Kapital bindet nur bei hohem WACC. Module binden nie.

---

## 3. Elastizität Geld → Zubau (Kurzbefund)

- **Direkte Preiselastizität**: +0,1 Yuan/kWh Einspeisevergütung ⇒ **+~18 GW/a** nationale PV-Installation in China; ohne Subvention „would virtually disappear" (Q7) **[A]**.
- **Verzug**: IRA 8/2022 → Rekordzubau 2025 = **3 a**; DE-Genehmigungsrecht 2022 → Zubauverdopplung 2025 = **3 a**; Netz/Trafos = **5+ a**. ⇒ Spielregel: Geld wirkt mit **2–3 Jahren** auf Erzeugung, **5+ Jahren** auf Netz **[B]**.
- **Preis der Hast**: Frankreich **>×3** je kW trotz bestmöglicher Standardisierung (Q1); Flyvbjerg: Schiene +45 %, Tunnel/Brücken +34 %, Straßen +20 % mittlere Überschreitung, **seit 70 Jahren keine Besserung** (Q44); FOAK-Kernkraft Medianüberschreitung ~130 %, letzte Anlage im Orderbuch −30 % (Q45); Beschleunigung durch Überstunden: **+6,7 bis +26,8 % Lohnkosten** je Vorgang (Q46).
- **Verdrängung**: US-Mobilisierung erreichte ×16 Menge bei **fallender** Gesamtproduktivität (−3,7 %/a 1941–44) — der Mengenrekord wurde durch Ressourcenumleitung, nicht durch Effizienz erkauft (Q12) **[A]**.

---

## 4. Beschleunigungsleiter (Vorschlag EH-01)

| Stufe | Deckel-Multiplikator | Anlaufzeit | Capex-Multiplikator | Politik-/Legitimitätskosten | löst | löst **nicht** |
|---|---|---|---|---|---|---|
| **Normal** | ×1,0 **[S]** | – | ×1,0 **[S]** | 0 | – | – |
| **Priorität** (Gesetzespaket, „überragendes öffentliches Interesse", Flächenziele, Auktionsvolumen hoch) | Genehmigung **×4** **[A: DE 4,2→20,8 GW/a]**, wirksamer Zubaudeckel **×1,5–2,2** **[A: DE-Zubau ×2,2]** | **3 a** **[A]** | **×1,05–1,15** **[C]** | gering; Klagerisiko, Naturschutzkonflikte **[C]** | Genehmigung, Fläche, Investorvertrauen | Netz, Trafos, Fachkräfte |
| **Notstand** (LNGG-Analogie, connect-and-manage, Abnahmegarantien, Staatsbürgschaften, Vorabbeschaffung) | Einzelprojekte **×8 Zeitraffung** **[A: WHV 7,5 Mon.]**; Systemdeckel **×2,5** **[B]**; Netzanschluss **×2,5** **[A: ERCOT/PJM 14,2 vs. 5,6 GW]** | **3–5 a** **[B]** | **×1,3–1,8** **[B: Frankreich >×3 über 15 a; Flyvbjerg +20–45 %]** | mittel–hoch: Abregelung 5–9 %, Umweltrechtsabbau, Klagewellen **[A/C]** | Netzanschluss, Kapitalkosten, Lieferverträge | Trafo-Lieferzeit <3 a, Fachkräfte <5 a, Übertragungstrassen |
| **Kriegswirtschaft** (Zwangsallokation, Staatsfabriken, Ausbildungspflicht, Rationierung) | Erzeugung **×4** über max. **5–6 a** **[B: US-Luftfahrt ×16 in 5 a = ×1,75/a, jedoch aus Depressionsbasis]**; Netz **×2** **[S]**; harte Kappe: **Kernkraft 2,6 %/a, Wind 1,1 %/a, Solar 0,8 %/a des Strombedarfs** **[A]** | **4–6 a** **[A: US 1939–44]** | **×2–3** plus **−1,5 bis −4 %/a Produktivität** **[A: Field]** | sehr hoch: Verdrängung ziviler Investitionen (Kriegsanteil <2 %→40 % des Volkseinkommens), Qualitätsverlust (Liberty), Legitimitätsbruch wie Schweden 1980 **[A]** | Fachkräfte (Zwangsausbildung), Trafos (Staatswerke), Fläche (Enteignung) | **physische Diffusionsobergrenze; Bauzeit einer Kernkraftanlage (5–9 a); Trassenbau (5–15 a)** |

**Zwei Sonderregeln für den Spielleiter:**
1. **Notstand/Kriegswirtschaft wirken nicht sofort.** Der Multiplikator ist erst nach der Anlaufzeit voll; im ersten Jahr ×1,0–1,2, dann linear.
2. **Die Kappe ist unumgehbar.** Kein Staat hat je mehr als 2,6 %/a (Kernkraft) bzw. 1,1 %/a (Wind) des nationalen Strombedarfs zugebaut. Kriegswirtschaft verlängert die Zeit an der Obergrenze, sie hebt sie nicht **[A/S]**.

*(Anmerkung der Synthese: Die Solar-Kappe 0,8 %/a ist durch China 2024/25 überholt — siehe Anhang D §2 und Hauptbericht §5.)*

---

## 5. Quellenregister

| # | Titel · Autoren · Jahr · Journal/Institution | URL / DOI | Güte |
|---|---|---|---|
| Q1 | The costs of the French nuclear scale-up: A case of negative learning by doing · A. Grubler · 2010 · Energy Policy | https://consensus.app/papers/details/f7b24b8d16ba57f8be85c5ac2d406843/?utm_source=claude_desktop · 10.1016/j.enpol.2010.05.003 | A |
| Q2 | Electricity Grids and Secure Energy Transitions · IEA · 2023 | https://www.iea.org/reports/electricity-grids-and-secure-energy-transitions/executive-summary | A |
| Q3 | Grid connection barriers to renewable energy deployment in the United States · Gorman et al. · 2024 · Joule | https://consensus.app/papers/details/0c880101debb5d7fa2044f33283b466d/?utm_source=claude_desktop · 10.1016/j.joule.2024.11.008 | A |
| Q4 | Queued Up: 2024 Edition · Rand et al. · 2024 · LBNL | https://consensus.app/papers/details/99229310da0a5100a11ad4881f49ccd6/?utm_source=claude_desktop · 10.2172/2335720 | A |
| Q5 | Backlog of power plants seeking transmission grid connection eased somewhat in 2025 · LBNL EMP · 2026 | https://emp.lbl.gov/news/backlog-power-plants-seeking-transmission-grid-connection-eased-somewhat-2025-amidst | A |
| Q6 | The Impact of Policy Intensity on Overcapacity in Low-Carbon Energy Industry · Hu et al. · 2020 · Front. Energy Res. | https://consensus.app/papers/details/52559c7158f05a26b0dc9ce3e1e3f471/?utm_source=claude_desktop · 10.3389/fenrg.2020.577515 | A |
| Q7 | Rushing for subsidies: The impact of feed-in tariffs on solar PV capacity development in China · Dong et al. · 2020 · Applied Energy | https://consensus.app/papers/details/1ecf90cd1fc152c4980ccf9f1c4626a9/?utm_source=claude_desktop · 10.1016/j.apenergy.2020.116007 | A |
| Q8 | Can Operation Warp Speed Serve as a Model…? · D'Souza et al. · 2024 · NBER/SSRN | https://consensus.app/papers/details/fdd56fcde8635100b47acdb8bfb44532/?utm_source=claude_desktop · 10.3386/w32831 | A |
| Q9 | Operation warp speed: Harbinger of American industrial innovation policies · Bonvillian · 2024 · Science and Public Policy | https://consensus.app/papers/details/4fcb2407b9c45c4594dcec78996f064b/?utm_source=claude_desktop · 10.1093/scipol/scae020 | A |
| Q10 | Operation Warp Speed: implications for global vaccine security · Kim et al. · 2021 · Lancet Global Health | https://consensus.app/papers/details/cc675a69b19659a48896d212e493c292/?utm_source=claude_desktop · 10.1016/s2214-109x(21)00140-6 | A |
| Q11 | Learning and World War II Production Functions · Rapping · 1965 · Rev. Econ. Stat. | https://consensus.app/papers/details/6a4f312c3ae55121afc784f71211c396/?utm_source=claude_desktop · 10.2307/1924126 | A |
| Q12 | The decline of US manufacturing productivity between 1941 and 1948 · Field · 2023 · Econ. History Review | https://consensus.app/papers/details/e135de712ac95d748540fc5a674891b6/?utm_source=claude_desktop · 10.1111/ehr.13239 | A |
| Q13 | U.S. Production in World War II · Gropman · 1996 | https://consensus.app/papers/details/c947308f80d850ab9c54e61bf1981abc/?utm_source=claude_desktop | A |
| Q14 | How Much Did the Liberty Shipbuilders Learn? · Thompson · 2001 · JPE | https://consensus.app/papers/details/988223acc7455b07a9c4978fadadb654/?utm_source=claude_desktop · 10.1086/318605 | A |
| Q15 | Destructive Creation: American Business and the Winning of WWII (Rez. Breen) · 2017 · J. Am. History | https://consensus.app/papers/details/03474df3b06a529baec1b0202a9b317f/?utm_source=claude_desktop · 10.1093/jahist/jax258 | A |
| Q16 | A dynamic analysis of financing conditions for renewable energy technologies · Egli, Steffen & Schmidt · 2018 · Nature Energy | https://consensus.app/papers/details/b0db4c0f551a52e4818a735c7872dea1/?utm_source=claude_desktop · 10.1038/s41560-018-0277-y | A |
| Q17 | How France achieved the world's fastest nuclear buildout · Works in Progress | https://worksinprogress.co/issue/liberte-egalite-radioactivite/ | B |
| Q18 | Nuclear Power in Sweden · World Nuclear Association | https://world-nuclear.org/information-library/country-profiles/countries-o-s/sweden | A |
| Q19 | Nuclear Power in the United Arab Emirates · WNA | https://world-nuclear.org/information-library/country-profiles/countries-t-z/united-arab-emirates | A |
| Q20 | China – World Nuclear Outlook Report · WNA | https://world-nuclear.org/our-association/publications/world-nuclear-outlook-report/china---world-nuclear-outlook-report | A |
| Q21 | China's Impressive Rate of Nuclear Construction · The Breakthrough Institute | https://thebreakthrough.org/issues/energy/chinas-impressive-rate-of-nuclear-construction | B |
| Q22 | History of France's civil nuclear program · Wikipedia | https://en.wikipedia.org/wiki/History_of_France%27s_civil_nuclear_program | C |
| Q23 | China's new PV installations hit 216.88 GW in 2023 · pv magazine · 2024 | https://www.pv-magazine.com/2024/02/02/chinas-new-pv-installations-hit-216-88-gw-in-2023/ | A |
| Q24 | China hits 277.17 GW of new PV installations in 2024 · pv magazine · 2025 | https://www.pv-magazine.com/2025/01/21/china-hits-277-17-gw-of-new-pv-installations-in-2024/ | A |
| Q25 | China adds 315 GW of solar in 2025 · pv magazine · 2026 | https://www.pv-magazine.com/2026/01/28/china-adds-315-gw-of-solar-in-2025/ | A |
| Q26 | China's solar capacity installations grew rapidly in 2024 · US EIA | https://www.eia.gov/todayinenergy/detail.php?id=65064 | A |
| Q27 | First German LNG Terminal to Open in Wilhelmshaven · Uniper | https://www.uniper.energy/news/first-german-lng-terminal-to-open-in-wilhelmshaven-german | A |
| Q28 | Status des Windenergieausbaus an Land in Deutschland – Jahr 2025 · FA Wind/BWE · 2026 | https://www.wind-energie.de/fileadmin/redaktion/dokumente/publikationen-oeffentlich/themen/06-zahlen-und-fakten/20260115_Status_des_Windenergieausbaus_an_Land_Jahr_2025.pdf | A |
| Q29 | Gut ein Jahr „überragendes öffentliches Interesse" in §2 EEG 2023 · Stiftung Umweltenergierecht | https://stiftung-umweltenergierecht.de/gut-ein-jahr-ueberragendes-oeffentliches-interesse-in-%C2%A7-2-eeg-2023-wie-wirkt-die-gesetzgeberische-wertungsentscheidung-zur-beschleunigung-des-ausbaus/ | B |
| Q30 | Impact of the Inflation Reduction Act · SEIA | https://seia.org/research-resources/impact-inflation-reduction-act/ | B |
| Q31 | New U.S. electric generating capacity expected to reach a record high in 2026 · US EIA | https://www.eia.gov/todayinenergy/detail.php?id=67205 | A |
| Q32 | Can ERCOT show the way to faster and cheaper grid interconnection? · Utility Dive | https://www.utilitydive.com/news/connect-and-manage-grid-interconnection-ferc-ercot-transmission-planning/698949/ | B |
| Q33 | President Biden Invokes Defense Production Act… · US DOE · 2022 | https://www.energy.gov/articles/president-biden-invokes-defense-production-act-accelerate-domestic-manufacturing-clean | A |
| Q34 | EU's new RED III legislation… · Osborne Clarke | https://www.osborneclarke.com/insights/eus-new-red-iii-legislation-significantly-raises-renewable-energy-targets-2030 | B |
| Q35 | The Manhattan Project, the Apollo Program, and Federal Energy Technology R&D Programs · CRS RL34645 · 2009 | https://www.everycrsreport.com/reports/RL34645.html | A |
| Q36 | Transformers in 2026: Shortage, Scramble, or Self-Inflicted Crisis? · POWER Magazine | https://www.powermag.com/transformers-in-2026-shortage-scramble-or-self-inflicted-crisis/ | B |
| Q37 | Analysing the global workforce dynamics of the energy transition (IEA WEE 2023) · Armiento et al. · 2025 | https://consensus.app/papers/details/509ae88db4ef5e7b87b048457e253915/?utm_source=claude_desktop · 10.1007/s43621-024-00773-7 | A |
| Q38 | Adverse effects of rising interest rates on sustainable energy transitions · Schmidt et al. · 2019 · Nature Sustainability | https://consensus.app/papers/details/a322c98e61325d72aa042a92ce79221b/?utm_source=claude_desktop · 10.1038/s41893-019-0375-2 | A |
| Q39 | Bias in energy system models with uniform cost of capital assumption · Egli et al. · 2019 · Nature Comms | https://consensus.app/papers/details/78105555256e56868c920025078af9f4/?utm_source=claude_desktop · 10.1038/s41467-019-12468-z | A |
| Q40 | Estimating the cost of capital for renewable energy projects · Steffen · 2020 · Energy Economics | https://consensus.app/papers/details/60f8758661745517bf96bff03b154fa4/?utm_source=claude_desktop · 10.2139/ssrn.3373905 | A |
| Q41 | Historical wind deployment and implications for energy system models · Hedenus et al. · 2022 · RSER | https://consensus.app/papers/details/8020a3db5f36563482f6c8374e46d70c/?utm_source=claude_desktop · 10.1016/j.rser.2022.112813 | A |
| Q42 | Historical diffusion of nuclear, wind and solar power in different national contexts · Vinichenko et al. · 2023 · ERL | https://consensus.app/papers/details/7ebd2569ad305cf69cd05addf3bff0ca/?utm_source=claude_desktop · 10.1088/1748-9326/acf47a | A |
| Q43 | National growth dynamics of wind and solar power… · Cherp et al. · 2021 · Nature Energy | https://consensus.app/papers/details/e78166846fa6504da4b7e4d9ee39a54b/?utm_source=claude_desktop · 10.1038/s41560-021-00863-0 | A |
| Q44 | How common and how large are cost overruns in transport infrastructure projects? · Flyvbjerg et al. · 2003 · Transport Reviews | https://consensus.app/papers/details/eaaa555696f7520e8170166b49c8800c/?utm_source=claude_desktop · 10.1080/01441640309904 | A |
| Q45 | A probabilistic evaluation of the evolution of capital costs… for new nuclear power plants · Hanna et al. · 2026 · Energy Conv. & Mgmt. | https://consensus.app/papers/details/be8044b55cb1500aad912a7ed92ac31a/?utm_source=claude_desktop · 10.1016/j.enconman.2026.121610 | B |
| Q46 | Analysis of Construction Time Acceleration Using the Crashing Method · Nasarudin et al. · 2025 · IJHET | https://consensus.app/papers/details/24aa1c073bc65644a8406eedb14ded3e/?utm_source=claude_desktop · 10.55227/ijhet.v4i4.447 | C |
| Q47 | Revisiting the Cost Escalation Curse of Nuclear Power · Rangel & Lévêque · 2013 (Gegenposition zu Q1) | https://consensus.app/papers/details/d3650950a1f850cbb0fa049dbdbfc834/?utm_source=claude_desktop · 10.5547/2160-5890.4.2.lran | A |

**Nicht belegt:** Wirkung des DPA-Einsatzes 2022 auf Solar-/Wärmepumpenfertigung; Capex-Vergleich Wilhelmshaven gegen Normalverfahren; konkrete Monatsfristen der RED-III-Beschleunigungsgebiete; quantifizierte Wirkung von §2 EEG 2023; jahresgenaue französische GW-Netzanschlüsse (nur Reaktorzahlen belegt).

---

## 6. Consensus-Hinweis

**In keinem der elf Consensus-Suchergebnisse war eine Sign-up-, Upgrade- oder Nutzungs-/Zähler-Meldung enthalten.** Jedes Ergebnis endete ausschließlich mit dem folgenden Zitierhinweis, hier wörtlich wiedergegeben:

> „IMPORTANT INSTRUCTIONS: When discussing these findings, you MUST cite papers inline using their numbered references, e.g. [1], [2]. Example: 'Caffeine improves endurance performance [1] and reduces perceived exertion [3].' Hyperlink paper titles directly: [Paper Title](url). Use the exact URLs above — do not modify or shorten them. If a paper line includes `DOI: ...`, treat it as a citation-formal identifier and preserve it when the user asks for citations."
