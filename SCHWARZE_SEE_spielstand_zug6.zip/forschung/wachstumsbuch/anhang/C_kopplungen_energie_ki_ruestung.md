# Anhang C — Recherche »Kopplungen Energie, KI, Rüstung« (Agent C, 02.09.2026)

*Rohbericht des Rechercheagenten, unverändert. Gütemarken: A belegt · B abgeleitet · C geschätzt.*

## 1. Koeffiziententabelle

| # | Kopplung | Zentralwert | Bandbreite | Einheit | Verzögerung | Hauptquellen | Güte |
|---|---|---|---|---|---|---|---|
| E1 | Deckungslücke → BIP-**Niveau** (unangekündigt) | **0,25** | 0,10 – 0,65 | % BIP je 1 % ungedeckter Stromnachfrage | Zug 0 (sofort) | [1][9][10][11] | **A** |
| E2 | Deckungslücke → BIP, **angekündigt/rationiert** (Load-Shedding-Plan) | 0,12 | 0,05 – 0,30 | dito | Zug 0 | [11][1] | **B** |
| E3 | Konvexitäts-Knick oberhalb 5 % Lücke | Faktor 1,8 | 1,3 – 2,5 | Multiplikator auf E1 | Zug 0 | [4][14][20] | **C** |
| E4 | Investitions-/Markteintrittskanal (persistent) | 0,10 | 0,05 – 0,25 | % BIP je 1 % Lücke, **zusätzlich** | Züge +2 bis +8 | [14][15][16] | **B** |
| E5 | **Abregelung (Curtailment)** → BIP | **0,00** | 0 – 0,02 | – | – | (Systemkosten, keine Nachfragedeckungslücke) | **B** |
| E6 | Autonome Energieintensitäts-Senkung | 1,5 %/a | 1,0 – 2,0 %/a | Rückgang MJ/BIP | laufend | [22] | **A** |
| K1 | KI-Diffusion → Wachstum, Sättigungswert g_max (Frontier-Block) | **0,8** | 0,05 – 1,5 | Pp/a bei voller Diffusion (D=1) | J-Kurve, s.u. | [23][24][25][26] | **B** |
| K2 | Untergrenze (Hulten/Task-Ansatz) | 0,07 | 0,05 – 0,07 | Pp/a TFP | 10 J. | [23] | **A** |
| K3 | Obergrenze (Bank-/IWF-Optimistik) | 1,5 | 1,2 – 1,5 | Pp/a Arbeitsproduktivität | 10 J. | [25][26] | **B** |
| K4 | J-Kurven-Verzögerung nach Diffusionssprung | 4 Jahre | 3 – 7 | Züge mit ≈0 oder negativem Effekt | – | [27][28][35] | **A** |
| K5 | Realisierungsgrad heute (Adoption ≠ Wirkung) | 1,4 % | 0 – 3 % | eingesparte Arbeitszeit, kumuliert | – | [29][30] | **A** |
| R1 | Rüstungsquote → Wachstum, **kurzfristig, Vollauslastung** | **−0,5** | −0,6 … −0,4 | Pp je Pp ΔQuote, Jahr 1 | Zug 0–2 | [31][32] | **A** |
| R2 | dito, **bei Nachfragelücke** | **+0,0** | −0,2 … +0,5 | dito | Zug 0–2 | [32][33][34] | **A** |
| R3 | Langfrist-TFP über F&E-Kanal | **+0,28** | +0,20 … +0,30 | % TFP je transitorisch 1 % BIP | Züge +5 bis +15 | [17][32] | **A** |
| R4 | Dauerhaft hohe Last (Niveauwirkung) | **−0,15** | 0,0 … −0,40 | Pp/a je Pp oberhalb ~4 % BIP | laufend | [2][3][5][6] | **B** |
| R5 | Importanteil-Dämpfung | ×(1−Importquote) | – | Skalierung auf R1/R2/R3 | – | [32] | **B** |
| R6 | »SAEED 1,10« | **verwerfen** | – | – | – | [7] vs. [2][3][4] | **C** |

---

## 2. Kopplung Energie → Wachstum

**Evidenzlage.** Der belastbarste Mikro-Anker ist Allcott, Collard-Wexler & O'Connell 2016 [1]: Indien, Wasserkraft-IV, Deckungslücke ≈ 10 % der Nachfrage. Für den Durchschnittsbetrieb sinken Produzentenrente um 9,5 %, Umsatz um 5,6 %, **Produktivität aber nur um 1,5 %** — also ≈ 0,15 Prozentpunkte TFP je Prozentpunkt Lücke. Der Grund ist zentral für das Spiel: Vorleistungen lassen sich lagern, Fehlzeit wird nachgeholt; der Verlust ist überwiegend Kapazitäts-, nicht Effizienzverlust. Fisher-Vanden, Mansur & Wang 2015 [9] bestätigen das für China 1999–2004: Firmen substituieren »make« durch »buy«, Stückkosten +8 %, Produktivitätsverlust vergleichsweise klein.

Makro-Anker: Die SARB-Notiz OBEN/23/01 [10] rechnet für Südafrika 2022 drei Modelle: −0,7 Pp (Morema u. a.), −1,6 bis −1,8 Pp (OLS) und −3,2 Pp (Mpini/Walter/Makrelov); Marktschätzungen streuen −0,4 bis −4,2 Pp. Der brauchbarste Struktur-Koeffizient der Notiz: **1 % Rückgang der Stromverfügbarkeit ≈ 0,16 % BIP je Quartal** (Absa) und 0,0003–0,0008 Pp Quartalswachstum je zusätzlicher GWh Abschaltung. Bei ≈ 5 % Deckungslücke 2022 impliziert der SARB-Korridor 0,14 bis 0,64 % BIP je Prozentpunkt.

**Widersprüche.** (a) Andersen & Dalgaard 2013 [12] finden mit Blitzdichte-IV für Subsahara-Afrika einen Koeffizienten von −0,018 und **−2 Pp Jahreswachstum je ein Log-Punkt mehr Ausfälle pro Monat**. Das ist eine andere Einheit (Ausfallhäufigkeit, nicht ungedeckte Nachfrage) und nicht direkt in die EH-01-Größe übersetzbar — nicht übernehmen. (b) Chen u. a. 2023 [13] behaupten +2,16 % Wachstum je 1 % SAIDI-Senkung für 152 Länder; das ist implausibel groß und sollte als Ausreißer behandelt werden. (c) Cole, Elliott, Occhiali & Strobl 2018 [4] finden +85,1 % Umsatz (ohne Generator +117,4 %), wenn SSA-Ausfälle auf südafrikanisches Niveau fielen — ein Hinweis auf starke Konvexität bei sehr großen Lücken, kein linearer Koeffizient. (d) Grainger & Zhang 2019 [11]: In Pakistan senkt **eine zusätzliche Stunde unerwarteter** Knappheit pro Tag den Umsatz um ~10 % und die Wertschöpfung um ~20 %, planmäßiges Load-Shedding dagegen deutlich weniger. Vorhersehbarkeit halbiert die Kosten — das ist die wichtigste Regelunterscheidung. (e) Fried & Lagakos 2021 [14]: kurzfristig klein, langfristig im allgemeinen Gleichgewicht (Leerkapazität, unterbliebener Markteintritt) deutlich größer.

**Empfohlener Regelwert und Funktionsform.**
> ΔBIP_Niveau = −c · L · κ · f(L), mit c = 0,25 %/Pp, L = Deckungslücke in %, κ = 1,0 (unangekündigt) / 0,5 (angekündigt, EH-01-Rationierungsplan), f(L) = 1 für L ≤ 5 %, sonst 1 + 0,8·(L−5)/10 (**Schwelle + konvexer Ast**).

Zusätzlich ein persistenter Kanal E4: 0,10 %/Pp, verteilt auf die Züge +2 bis +8 (Investitionsausfall). **Abregelung (Curtailment) darf im BIP-Kanal nicht auftauchen** — abgeregelter Strom ist ungenutzte Erzeugung bei gedeckter Nachfrage. Sie gehört in die Systemkosten (entwertetes Anlagekapital, höhere LCOE), nicht in die Wachstumsgleichung. Wer sie doppelt bucht, bestraft Blöcke mit hohem EE-Anteil zweifach.

Für den Basispfad: Stern 2011 [21] ist die richtige Rahmung — Energie bindet **stark, solange sie knapp ist, und kaum, wenn sie reichlich ist**. Genau das leistet der Schwellenwert. Ayres & Warr [18][19] und Kümmel [20] rechtfertigen, dass die Output-Elastizität der Energie weit über ihrem Kostenanteil (≈ 5–8 %) liegt; als Spielgröße ist das aber schon im Koeffizienten c enthalten. Energieintensität: IEA [22] — 2010–2019 ≈ 2 %/a, 2019–2024 nur 1,3 %/a, 2024 ≈ 1 %, 2025 ≈ 1,8 %. **1,5 %/a als Basiswert ist gut belegt**; 4 %/a wäre das COP28-Ziel und taugt als Politik-Option, nicht als Basis.

---

## 3. Kopplung KI/Compute → Wachstum

**Evidenzlage.** Die Spannweite ist eine Größenordnung, und sie ist systematisch:

- **Untergrenze:** Acemoğlu 2024 [23] — Hultens Theorem auf Task-Ebene: **TFP +0,66 % über 10 Jahre (≈ 0,07 Pp/a)**, in der verschärften Fassung < 0,53 %. Begründung: die betroffenen Tasks sind ein kleiner Anteil der Wertschöpfung, und frühe Evidenz stammt aus leicht erlernbaren Aufgaben.
- **Mitte:** OECD/Schief 2024 [24] — Mikro-zu-Makro mit Input-Output-Verflechtung: **TFP +0,25 bis 0,6 Pp/a, Arbeitsproduktivität +0,4 bis 0,9 Pp/a** über 10 Jahre. Das ist der methodisch sauberste Zentralwert.
- **Obergrenze:** Goldman Sachs (Briggs/Kodnani/Hatzius/Pierdomenico 2023) [25] — **+7 % globales BIP und +1,5 Pp/a Produktivität über 10 Jahre**, zwei Drittel der US-Berufe exponiert, 300 Mio. VZÄ betroffen. Der IWF [26] kalibriert sein optimistisches Szenario ebenfalls auf **≈ +1,5 Pp/a Arbeitsproduktivität in den ersten 10 Jahren** (Output +16 % zwischen Steady States, TFP +4 %); Exposition: 40 % global, **60 % fortgeschrittene Volkswirtschaften**, 40 % Schwellenländer, 26 % Niedrigeinkommensländer.
- **Realitätscheck:** Bick, Blandin & Deming 2024 [29] — Ende 2024 nutzen 45 % der US-Bevölkerung 18–64 GenAI, 27 % der Beschäftigten in der Vorwoche beruflich; **1–7 % der Arbeitsstunden werden assistiert, die berichtete Zeitersparnis entspricht 1,4 % der Gesamtarbeitszeit**. Humlum & Vestergaard 2025 [30] finden in Dänemark (≈ 25 000 Beschäftigte, ~7 000 Betriebe) **»no significant impact on earnings or recorded hours in any occupation«**. Parteka & Kordalska 2023 [36] finden für OECD-Länder eine vernachlässigbare Rolle von KI-Patenten in der gemessenen Produktivität.
- **Mikro-RCTs** (warum die Erwartungen hoch sind): Noy & Zhang 2023 [37] −40 % Zeit / +18 % Qualität; Brynjolfsson, Li & Raymond 2023 [38] +15 % (Novizen +30 %); Cui u. a. [39] +26,1 % erledigte Aufgaben bei 4 867 Entwicklern. Die Lücke zwischen 15–60 % Task-Gewinn und 0,1–0,6 Pp Makro-Wirkung **ist** das Ergebnis, kein Messfehler.
- **Verzögerung:** Brynjolfsson, Rock & Syverson 2021 [27] — Produktivitäts-J-Kurve: TFP wird in der Aufbauphase unter-, in der Erntephase überschätzt (US-TFP-Niveau intangibel-bereinigt +15,9 % bis Ende 2017). Venturini 2022 [28] misst die Elastizität der Aggregatproduktivität zum Wissensbestand »intelligenter Technologien« mit **0,01–0,06** und findet ebenfalls ein J-Kurven-Muster.
- **Oberer Schwanz:** Aghion, Jones & Jones 2019 [34] — Baumols Kostenkrankheit: das Wachstum wird von den **nicht** automatisierten Tasks begrenzt. Erdil & Besiroglu 2023 [35] definieren »explosiv« als > 30 % Weltwirtschaftswachstum p. a. und geben, **bedingt** auf breit automatisierungsfähige KI bis 2100, etwa 50:50; die Bottleneck-Schwelle liegt bei Skalenerträgen akkumulierbarer Inputs > ≈ 0,68. Korinek & Suh 2024 [33] liefern das Szenarien-Gerüst.

**Empfohlener Regelwert und Funktionsform.** Compute ist ein **Input**, Diffusion ist die bindende Restriktion (Bick u. a.: 27 % Adoption, 1,4 % Zeitgewinn). Deshalb nicht linear an Z-Stufen koppeln, sondern:

> Aufschlag_t = g_max · D_t^2 / (D_t^2 + k^2) · J(t), mit D = Diffusionsgrad (0–1), k = 0,45, g_max = 0,8 Pp/a (Frontier), 0,5 (Verfolger), 0,3 (Nachzügler); J(t) = 0 in den ersten 2 Zügen nach einem Diffusionssprung, 0,5 in Zug 3–4, 1,0 ab Zug 5.

Sättigend, nicht linear; mit Verzögerung; g_max blockspezifisch nach Expositionsanteil [26]. Die Z-Stufen werden zu Diffusionsgraden (Z-1 = 0,10 … Z-5 = 0,90).

**Urteil zur bestehenden DW-01-Regel.** *USA +1,5 Pp/a bei Z-5* ist **nicht der Zentralwert, sondern die Obergrenze der Literatur** (Goldman Sachs, IWF-Optimalszenario) — rund das 20-Fache von Acemoğlu und das 2,5- bis 6-Fache des OECD-Bandes, und ohne J-Kurve sofort wirksam. *China +0,6 Pp/a bei Z-2* ist bei nur 20 % Diffusion inkonsistent: Es liegt am oberen Rand des OECD-Bandes für **volle** Diffusion. Empfehlung: Z-5 → **+0,8 Pp/a** (Bandbreite 0,3–1,5 für Szenarienwürfe), Z-2 → **+0,25 Pp/a**, jeweils mit vierjähriger J-Kurve. Das Szenario »+1,5 Pp/a ohne Verzögerung« als bezahlbare *Optionskarte* behalten, nicht als Basispfad.

---

## 4. Kopplung Rüstung → Wachstum, und Urteil zu SAEED 1,10

**Quellenidentifikation.** »Saeed« ist **Luqman Saeed (Ulster University), 2023, Defence and Peace Economics, DOI 10.1080/10242694.2023.2259651** [7]. 133 Länder, 1960–2012, IV mit (i) Rüstungsimportwert in Friedenszeiten und (ii) Zahl der Nachbarstaaten mit zwischenstaatlicher Gewalt. Ergebnis wörtlich: »an increase in military expenditure/GDP of 1 percentage point reduces economic growth by 1.10 percentage points«, robust über 2SLS, LIML, GMM. Kein Pakistan-Paper, aber ein Panel mit starkem Entwicklungsländer-Schwerpunkt.

**Der Gegenpol ist ebenfalls identifiziert:** »Faini 0,013« ist Faini, Annez & Taylor 1984 (EDCC) [8]: 69 Länder, 1952–70, **+10 Pp Rüstungsquote → −0,13 % Jahreswachstum**, also exakt 0,013 Pp/Pp.

**Warum 1,10 nicht trägt.**
1. **Alle drei Meta-Analysen widersprechen.** Alptekin & Levine 2012 [2] (32 Studien, 169 Schätzungen): Nettoeffekt **positiv und sehr klein**. Yeşilyurt & Elhorst 2019 [3] (größere Stichprobe, JPR): »the average effect across all studies is close to zero«, keine starke Publikationsverzerrung. Awaworyi Churchill & Yew 2018 [5] (272 Meta-Beobachtungen, 48 Studien): im Mittel wachstumsdämpfend — **aber »positive effects of military expenditure on growth are more pronounced for developed countries than less developed countries«**. Das trifft die Übertragungsfrage direkt: die Richtung, in die SAEED extrapoliert werden müsste, ist die, in der die Literatur den Effekt *weniger* negativ findet.
2. **IV-Inflation ist ein bekanntes Muster, kein Beleg.** d'Agostino, Dunne & Pieroni 2019 [6] zeigen selbst, dass IV-Schätzer »a larger significant negative effect … than OLS« liefern. Ein LATE, identifiziert über waffenimportierende Länder in gewalttätigen Nachbarschaften, misst zu einem großen Teil Konflikt, nicht Rüstungsausgaben.
3. **Größenordnungsprüfung.** 1,10 Pp/Pp hieße: die NATO-Anhebung von 2 % auf 3,5 % BIP kostete 1,65 Pp Wachstum pro Jahr — dauerhaft. Ilzetzki 2025 [32] rechnet für dieselbe Anhebung **+0,9 % bis +1,5 % europäisches BIP-Niveau**, also das entgegengesetzte Vorzeichen.
4. **Der Multiplikator setzt die kurzfristige Untergrenze.** Barro & Redlick 2011 [31]: Verteidigungsmultiplikator 0,4–0,5 kontemporär, 0,6–0,7 über zwei Jahre, +0,1–0,2 wenn permanent; **alle signifikant < 1**, also Verdrängung — aber der Wachstumsverlust ist dann höchstens (1 − m) ≈ 0,5 Pp/Pp, nicht 1,10. Sheremirov & Spirovska 2019 [34]: 0,75–0,85 im ersten Jahr, größer in Rezessionen, geschlossenen Volkswirtschaften, bei fixem Wechselkurs. Olejnik u. a. 2025 [40]: EU-NATO-Multiplikator 0,68 (Impakt) / 0,79 (Maximum) gegen 1,34 für sonstige Staatsausgaben.
5. **Langfristig kehrt sich das Vorzeichen um.** Antolín-Díaz & Surico 2025 (AER) [17]: Militärausgaben wirken persistent positiv auf Output, **weil sie die Ausgabenstruktur zu F&E verschieben**; Innovation und private Investitionen steigen mittelfristig, Produktivität und BIP langfristig. Ilzetzki [32] beziffert: transitorisch +1 % BIP Militärausgaben → **+0,25 bis +0,3 % Langfristproduktivität**; 10 % mehr staatliche Militär-F&E ziehen > 4 % private F&E nach.
6. **Zusammensetzung schlägt Niveau.** Becker & Dunne 2021 [41]: die negative Korrelation wird **überwiegend von Personalausgaben getrieben**. Dunne, Smith & Willenbockel 2019 [42]: über den Investitionskanal »the data do not suggest any strong relations«.

**Urteil: ERSETZEN, nicht nur senken.** Auch 0,393 ist unbrauchbar — es mischt zwei inkompatible Designs (LATE-IV eines Entwicklungsländerpanels mit einer Querschnittsregression von 1952–70) und erzeugt einen Wert, den keine Studie schätzt. Ein einziger Koeffizient kann diese Kopplung nicht abbilden, weil sie **das Vorzeichen wechselt**. Ersatzregel für C-3:

> **Kurzfristig (Zug 0–2):** ΔWachstum = (m − 1) · ΔRüstungsquote · Inlandsanteil, mit m = 0,45 bei Vollauslastung, 0,80 bei Nachfragelücke (Output-Gap < −1 %), 1,20 bei Gap < −3 % und fixem Wechselkurs. Steuerfinanziert: m um 0,3 reduzieren [31][32].
> **Langfristig (Zug +5 bis +15):** +0,28 % TFP je transitorisch 1 % BIP, **multipliziert mit dem F&E-/Beschaffungsanteil**; Personalanteil trägt 0 [17][32][41].
> **Dauerlast:** −0,15 Pp/a je Pp Rüstungsquote oberhalb 4 % BIP (Schwellen-/Nichtlinearitätsliteratur) [2][3][5][6].
> **Importdämpfung:** Ilzetzki [32] — ~80 % der europäischen Beschaffung ist Nicht-EU-Import; Multiplikator und Spillover entsprechend skalieren.

Falls das Regelwerk zwingend **einen** Skalar braucht: **0,15 Pp/Pp (Bandbreite 0,00–0,40), und 0 bei Nachfragelücke.** 1,10 ist als Extremkarte (»Rüstung in einem waffenimportierenden Konfliktnachbarn«) darstellbar, nicht als USA/EU/China-Regel.

---

## 5. Kriegswirtschaft (kurz)

Zwischen 1939 und 1944 stieg das reale US-BSP prozentual stärker, als es 1929–33 gefallen war — die »production miracle« der Zeitgenossen [43]; reale Produktion +65 %, Industrieproduktion +90 % 1940–44 [44]. Der gemessene Anstieg ist aber zu einem großen Teil ein **Mess- und Kompositionsartefakt**: Higgs 1992 [45] zeigt, dass die USA 1942–46 eine Kommandowirtschaft mit administrierten Preisen führten, weshalb einige Kennzahlen statistisch unzutreffend und andere konzeptionell unangemessen sind; die Konsumentenlage verschlechterte sich, »echte« Prosperität kehrte erst nach dem Krieg zurück. Field [46][47] misst für das verarbeitende Gewerbe **TFP-Rückgänge von −1,4 %/a (1941–48), −3,7 %/a (1941–44) und −5,1 %/a (1941–45)**: der abrupte, temporäre Produktmixwechsel zerstörte mehr Produktivität, als Learning-by-doing schuf; die Nettowirkung auf das Potenzialoutput war »almost certainly negative«. Brunet 2024 [48] schätzt aus Bundesstaatsvariation Multiplikatoren des persönlichen Einkommens von **0,34 über zwei und 0,49 über drei Jahre** — mit **negativen Skaleneffekten**: je größer der Ausgabenschock, desto kleiner der Multiplikator. Für ERDE-01 heißt das: Mobilisierung hebt das *gemessene* BIP stark, drückt gleichzeitig Konsum, Wohlfahrt und TFP, und erzwingt nach Kriegsende eine Niveaukorrektur nach unten plus mehrjährige Rekonversion — nicht einen Wachstumssprung.

---

## 6. Quellenregister

**A = belegt (Primärschätzung mit Zahl) · B = abgeleitet · C = geschätzt/unsicher**

1. [How Do Electricity Shortages Affect Industry? Evidence from India](https://consensus.app/papers/details/504b40b044f656b79374e114d4138664/?utm_source=claude_desktop) — Allcott, Collard-Wexler & O'Connell, 2016, *American Economic Review*, DOI: 10.1257/aer.20140389 — **A**. Ergänzend: https://cepr.org/voxeu/columns/electricity-shortages-and-industry-evidence-india
2. [Military expenditure and economic growth: A meta-analysis](https://consensus.app/papers/details/f7e355d892e9518db1ae469d10363493/?utm_source=claude_desktop) — Alptekin & Levine, 2012, *European Journal of Political Economy*, DOI: 10.1016/j.ejpoleco.2012.07.002 — **A**
3. [Meta-analysis, military expenditures and growth](https://consensus.app/papers/details/ab64c452bb545ad0a270dcbf51806157/?utm_source=claude_desktop) — Yeşilyurt & Elhorst, 2019, *Journal of Peace Research*, DOI: 10.1177/0022343318808841 — **A**
4. [Power outages and firm performance in Sub-Saharan Africa](https://consensus.app/papers/details/854b31d58aed5c1db5a12a8ba8033924/?utm_source=claude_desktop) — Cole, Elliott, Occhiali & Strobl, 2018, *Journal of Development Economics*, DOI: 10.1016/j.jdeveco.2018.05.003 — **A**
5. [The effect of military expenditure on growth: an empirical synthesis](https://consensus.app/papers/details/26a471bdb7eb5921b68075968228f290/?utm_source=claude_desktop) — Awaworyi Churchill & Yew, 2018, *Empirical Economics*, DOI: 10.1007/s00181-017-1300-z — **A**
6. [Military Expenditure, Endogeneity and Economic Growth](https://consensus.app/papers/details/122df5b66c205f62b12f1f8068508587/?utm_source=claude_desktop) — d'Agostino, Dunne & Pieroni, 2019, *Defence and Peace Economics*, DOI: 10.1080/10242694.2017.1422314 — **A**
7. [The Impact of Military Expenditures on Economic Growth: A New Instrumental Variables Approach](https://consensus.app/papers/details/14102b38bddd522984d1f6318c149e44/?utm_source=claude_desktop) — Luqman Saeed, 2023, *Defence and Peace Economics*, DOI: 10.1080/10242694.2023.2259651 — **A** (Schätzung), **C** (Übertragbarkeit). Volltext: https://www.tandfonline.com/doi/full/10.1080/10242694.2023.2259651
8. [Defense Spending, Economic Structure, and Growth: Evidence among Countries and over Time](https://consensus.app/papers/details/a6c22283c878548db4f257ae67076ad3/?utm_source=claude_desktop) — Faini, Annez & Taylor, 1984, *Economic Development and Cultural Change*, DOI: 10.1086/451402 — **A**
9. [Electricity shortages and firm productivity: Evidence from China's industrial firms](https://consensus.app/papers/details/a09529c2b0e75df59f73d3c268bc7cc0/?utm_source=claude_desktop) — Fisher-Vanden, Mansur & Wang, 2015, *Journal of Development Economics*, DOI: 10.1016/j.jdeveco.2015.01.002 — **A**
10. Reflections on load-shedding and potential GDP — SARB Occasional Bulletin of Economic Notes OBEN/23/01, 2023 — https://www.resbank.co.za/content/dam/sarb/publications/occasional-bulletin-of-economic-notes/2023/reflections-on-load-shedding-and-potential-gdp-june-2023.pdf — **A**
11. [Electricity shortages and manufacturing productivity in Pakistan](https://consensus.app/papers/details/8200aa008efd5fcc8c59ed2f9512c82f/?utm_source=claude_desktop) — Grainger & Zhang, 2019, *Energy Policy*, DOI: 10.1016/j.enpol.2019.05.040 — **A**
12. [Power outages and economic growth in Africa](https://consensus.app/papers/details/59d85a2af34950e09cf977f8b2d2e8c4/?utm_source=claude_desktop) — Andersen & Dalgaard, 2013, *Energy Economics*, DOI: 10.1016/j.eneco.2013.02.016 — **A** (Volltext: https://web.econ.ku.dk/dalgaard/Work/published/1-s2.0-S0140988313000406-main.pdf)
13. [How will power outages affect the national economic growth: Evidence from 152 countries](https://consensus.app/papers/details/d34fe92962095954bbfdfa0ecd494e30/?utm_source=claude_desktop) — Chen u. a., 2023, *Energy Economics*, DOI: 10.1016/j.eneco.2023.107055 — **C** (Ausreißer)
14. [Electricity and Firm Productivity: A General-Equilibrium Approach](https://consensus.app/papers/details/59861b966aab5fe6ab09e47e771f4058/?utm_source=claude_desktop) — Fried & Lagakos, 2020/2021, DOI: 10.3386/w27081 — **A**
15. [Productivity Losses and Firm Responses to Electricity Shortages: Evidence from Ghana](https://consensus.app/papers/details/069746a3232c538b8e3df6407e8e64d7/?utm_source=claude_desktop) — Abeberese, Ackah & Asuming, 2019, *World Bank Economic Review*, DOI: 10.1093/wber/lhz027 — **A**
16. [The Effect of Electricity Shortages on Firm Investment: Evidence from Ghana](https://consensus.app/papers/details/5060b4d77c285347b01a2b39cfb7614a/?utm_source=claude_desktop) — Abeberese, 2019, *Journal of African Economies*, DOI: 10.1093/jae/ejz013 — **A**
17. [The Long-Run Effects of Government Spending](https://consensus.app/papers/details/df2a0fe927ac529eb39cf4780faca399/?utm_source=claude_desktop) — Antolín-Díaz & Surico, 2025, *American Economic Review*, DOI: 10.1257/aer.20231278 — **A**
18. [Accounting for growth: the role of physical work](https://consensus.app/papers/details/45b6b4ded7f1537db3d713d96b6cb6c3/?utm_source=claude_desktop) — Ayres & Warr, 2005, *Structural Change and Economic Dynamics*, DOI: 10.1016/j.struceco.2003.10.003 — **A**
19. [Useful work and information as drivers of economic growth](https://consensus.app/papers/details/15a397264bd25cc2867f525f0b9ddff5/?utm_source=claude_desktop) — Warr & Ayres, 2012, *Ecological Economics*, DOI: 10.1016/j.ecolecon.2011.09.006 — **A**
20. [Energy in Growth Accounting and the Aggregation of Capital and Output](https://consensus.app/papers/details/ccf915bb021251acafcac5dca78e4c06/?utm_source=claude_desktop) — Kümmel & Lindenberger, 2020, *Biophysical Economics and Sustainability*, DOI: 10.1007/s41247-020-00068-1 — **B**
21. [The role of energy in economic growth](https://consensus.app/papers/details/5eeb2644880f56b290b3827520aa190e/?utm_source=claude_desktop) — Stern, 2011, *Annals of the NY Academy of Sciences*, DOI: 10.1111/j.1749-6632.2010.05921.x — **A**
22. Energy Efficiency 2025, Executive Summary — IEA, 2025 — https://www.iea.org/reports/energy-efficiency-2025/executive-summary — **A**
23. [The Simple Macroeconomics of AI](https://consensus.app/papers/details/cf03b6f445eb50c187c52e56f1d6f264/?utm_source=claude_desktop) — Acemoğlu, 2024, NBER w32487, DOI: 10.3386/w32487 — **A**
24. [Miracle or Myth? Assessing the macroeconomic productivity gains from Artificial Intelligence](https://consensus.app/papers/details/96dc059f3258573499c84a649c703cd8/?utm_source=claude_desktop) — Schief, 2024, *OECD Artificial Intelligence Papers*, DOI: 10.1787/b524a072-en — **A**
25. The Potentially Large Effects of Artificial Intelligence on Economic Growth — Briggs, Kodnani, Hatzius & Pierdomenico, Goldman Sachs, 2023 — https://www.gspublishing.com/content/research/en/reports/2023/03/27/d64e052b-0f6e-45d7-967b-d7be35fabd16.pdf ; Zusammenfassung: https://www.goldmansachs.com/insights/articles/generative-ai-could-raise-global-gdp-by-7-percent — **B** (Bankstudie, nicht begutachtet)
26. Gen-AI: Artificial Intelligence and the Future of Work — IMF Staff Discussion Note SDN/2024/001, 2024 — https://www.imf.org/-/media/files/publications/sdn/2024/english/sdnea2024001.pdf — **A**
27. [The Productivity J-Curve: How Intangibles Complement General Purpose Technologies](https://consensus.app/papers/details/548d788828575a679c070a0965269aac/?utm_source=claude_desktop) — Brynjolfsson, Rock & Syverson, 2021, *AEJ: Macroeconomics*, DOI: 10.1257/mac.20180386 — **A**
28. [Intelligent technologies and productivity spillovers: Evidence from the Fourth Industrial Revolution](https://consensus.app/papers/details/2633fe2f0f3d58cd8b2fc7d86376367c/?utm_source=claude_desktop) — Venturini, 2022, *JEBO*, DOI: 10.1016/j.jebo.2021.12.018 — **A**
29. [The Rapid Adoption of Generative AI](https://consensus.app/papers/details/a5c94865f04e57b995c4aad5b2d16a9c/?utm_source=claude_desktop) — Bick, Blandin & Deming, 2024, DOI: 10.20955/wp.2024.027 — **A**
30. Large Language Models, Small Labor Market Effects — Humlum & Vestergaard, 2025, BFI WP 2025-56 — https://bfi.uchicago.edu/wp-content/uploads/2025/04/BFI_WP_2025-56-3.pdf — **A**
31. [Macroeconomic Effects From Government Purchases and Taxes](https://consensus.app/papers/details/a4cf1888630c5789be48e4b78fd98c4d/?utm_source=claude_desktop) — Barro & Redlick, 2011, *Quarterly Journal of Economics*, DOI: 10.1093/qje/qjq002 — **A**
32. Guns and Growth: The Economic Consequences of Defense Buildups — Ilzetzki, Kiel Report No. 2, Februar 2025 — https://www.kielinstitut.de/fileadmin/Dateiverwaltung/IfW-Publications/fis-import/7afb0d80-68d0-49ae-8cae-1decc74fd972-Kiel_Report_Ethan.pdf — **A**
33. Scenarios for the Transition to AGI — Korinek & Suh, 2024, NBER w32255 — https://www.nber.org/system/files/working_papers/w32255/w32255.pdf — **B**
34. [Fiscal Multipliers in Advanced and Developing Countries: Evidence from Military Spending](https://consensus.app/papers/details/571ab833448e5a3a9a92797fd34ba937/?utm_source=claude_desktop) — Sheremirov & Spirovska, 2019, FRB Boston WP, DOI: 10.29412/res.wp.2019.03 — **A**
35. Explosive Growth from AI Automation: A Review of the Arguments — Erdil & Besiroglu, 2023, arXiv:2309.11690 — https://arxiv.org/pdf/2309.11690 — **B**
36. [Artificial intelligence and productivity: global evidence from AI patent and bibliometric data](https://consensus.app/papers/details/c989df0b2d1452b0be6e2da367ba7816/?utm_source=claude_desktop) — Parteka & Kordalska, 2023, *Technovation*, DOI: 10.1016/j.technovation.2023.102764 — **A**
37. [Experimental evidence on the productivity effects of generative artificial intelligence](https://consensus.app/papers/details/2a2b31c4730c5bb784416a81dabd4d84/?utm_source=claude_desktop) — Noy & Zhang, 2023, *Science*, DOI: 10.1126/science.adh2586 — **A**
38. [Generative AI at Work](https://consensus.app/papers/details/828f9c8033095d109f72e71f2c6f9955/?utm_source=claude_desktop) — Brynjolfsson, Li & Raymond, 2023, DOI: 10.3386/w31161 — **A**
39. [The Effects of Generative AI on High-Skilled Work: Evidence from Three Field Experiments with Software Developers](https://consensus.app/papers/details/ace1b73bbf0157bc8c3e59da5c6e1c94/?utm_source=claude_desktop) — Cui, Demirer, Jaffe, Musolff, Peng & Salz, 2026, *Management Science*, DOI: 10.1287/mnsc.2025.00535 — **A**
40. [Military expenditures as a part of endogenous fiscal policy in 21 EU-NATO countries](https://consensus.app/papers/details/ed4cdb3793bc58dc817ad17a325fa248/?utm_source=claude_desktop) — Olejnik u. a., 2025, *Defence and Peace Economics*, DOI: 10.1080/10242694.2025.2553245 — **A**
41. [Military Spending Composition and Economic Growth](https://consensus.app/papers/details/f80ed2bb5ebc553487e7f3fc43229982/?utm_source=claude_desktop) — Becker & Dunne, 2021, *Defence and Peace Economics*, DOI: 10.1080/10242694.2021.2003530 — **A**
42. [Military Expenditure, Investment and Growth](https://consensus.app/papers/details/21e23b39bf9e5ef5b76bc483822fd29f/?utm_source=claude_desktop) — Dunne, Smith & Willenbockel, 2019, *Defence and Peace Economics*, DOI: 10.1080/10242694.2019.1636182 — **A**
43. [The economics of World War II: The United States: from ploughshares to swords](https://consensus.app/papers/details/bd57ecf864dd57e5ba86d4329e458759/?utm_source=claude_desktop) — Rockoff, 1998, DOI: 10.1017/cbo9780511523632.004 — **A**
44. [Surveillance Capitalism: Monopoly-Finance Capital, the Military-Industrial Complex, and the Digital Age](https://consensus.app/papers/details/d35929a49d0b5a2c85a4ab05078af9f4/?utm_source=claude_desktop) — Foster & McChesney, 2014, *Monthly Review*, DOI: 10.14452/mr-066-03-2014-07_1 — **B** (Sekundärzahl: +65 % Output, +90 % Industrieproduktion 1940–44)
45. [Wartime Prosperity? A Reassessment of the U.S. Economy in the 1940s](https://consensus.app/papers/details/2ce50c55a7d25e1788bacb45257cf269/?utm_source=claude_desktop) — Higgs, 1992, *Journal of Economic History*, DOI: 10.1017/s0022050700010251 — **A**
46. [The decline of US manufacturing productivity between 1941 and 1948](https://consensus.app/papers/details/e135de712ac95d748540fc5a674891b6/?utm_source=claude_desktop) — Field, 2023, *Economic History Review*, DOI: 10.1111/ehr.13239 — **A**
47. [The Productivity Impact of World War II Mobilization in the United States](https://consensus.app/papers/details/40819f1a074c5957a8ab49895ce03936/?utm_source=claude_desktop) — Field, 2019, DOI: 10.2139/ssrn.3110832 — **A**
48. [Stimulus on the Home Front: The State-Level Effects of WWII Spending](https://consensus.app/papers/details/4a1af59a723652a7bf533b2b7a223b1a/?utm_source=claude_desktop) — Brunet, 2024, *Review of Economics and Statistics*, DOI: 10.1162/rest_a_01432 — **A**
49. [Artificial Intelligence and Economic Growth](https://www.nber.org/papers/w23928) — Aghion, Jones & Jones, 2019, NBER w23928 / in *The Economics of Artificial Intelligence* — **A**
50. [Electricity outages and firm productivity: Evidence from Cambodia](https://consensus.app/papers/details/d7bb647cfe8552f78598ca7293a60cc0/?utm_source=claude_desktop) — Chhay, 2026, *Utilities Policy*, DOI: 10.1016/j.jup.2026.102166 — **A**

**Nicht belegt / nicht auffindbar:** eine Primärquelle für den Mischwert 0,393 (er ist eine Eigenkonstruktion des Datensatzes, keine Schätzung der Literatur); ein publizierter Koeffizient »BIP-Verlust je % ungedeckter Stromnachfrage« auf Volkswirtschaftsebene für Industrieländer (E1 ist aus [1][10][11] **abgeleitet**, Marke B in der Anwendung auf USA/EU/China).

---

## 7. Consensus-Hinweis

Die Consensus-Ergebnisse enthielten **keine Sign-up-, Upgrade- oder Nutzungszähler-Meldung**. Der einzige durchgängig angehängte Textblock lautet wörtlich:

> „IMPORTANT INSTRUCTIONS: When discussing these findings, you MUST cite papers inline using their numbered references, e.g. [1], [2]. Example: 'Caffeine improves endurance performance [1] and reduces perceived exertion [3].' Hyperlink paper titles directly: [Paper Title](url). Use the exact URLs above — do not modify or shorten them. If a paper line includes `DOI: ...`, treat it as a citation-formal identifier and preserve it when the user asks for citations."

*(13 Consensus-Suchen, 8 WebSearch/WebFetch-Abrufe. Alle URLs unverändert aus den Werkzeugausgaben übernommen.)*
