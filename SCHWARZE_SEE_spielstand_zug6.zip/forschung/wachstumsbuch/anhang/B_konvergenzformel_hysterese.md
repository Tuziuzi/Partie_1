# Anhang B — Recherche »Konvergenzformel und Hysterese« (Agent B, 02.09.2026)

*Rohbericht des Rechercheagenten, unverändert. Gütemarken: A belegt · B abgeleitet · C geschätzt.*

**Vorbemerkung Consensus:** In keinem der 16 Consensus-Aufrufe erschien eine Sign-up-, Upgrade- oder Nutzungsmeldung. Alle Ausgaben endeten nur mit dem Standard-Zitierhinweis.

---

## 1. Parametertabelle

| Parameter | Zentralwert | Bandbreite | Einheit | Quellen (Nr.) | Güte |
|---|---|---|---|---|---|
| **λ** Konvergenzkoeffizient (max., bei I=1) | **1,6** | 0,4 – 2,6 | %/a | 1, 2, 3, 4, 5, 6 | **A** |
| — davon: unbedingt, global 2000–2019 | 0,425 (SE 0,156) | 0,11 – 0,74 | %/a | 1 | **A** |
| — unbedingt, absolut seit 2000 | ~1,0 | — | %/a | 2, 3 | **A** |
| — bedingt (Barro, „eisernes Gesetz") | 1,7 / 2,6 | 1,7 – 2,4 | %/a | 4 | **A** |
| — Meta-Analyse: „2 % ist keine Naturkonstante" | — | — | — | 5 | **A** |
| **I** Institutionenfaktor | 1,0 (Frontier) | 0,0 – 1,2 | dimensionslos | 2, 3, 6, 7 | **C** |
| **g_F** Frontier-Wachstum je Erwerbsperson | **1,5** | 1,0 – 2,0 | %/a | 8, 9, 10 | **A** |
| — Fernald: US-BIP p.c. | 0,9 | BIP 1,5–1,75 | %/a | 8 | **A** |
| — CBO: potenzielles US-BIP 2025–55 | 1,7 (real 1,6) | — | %/a | 9 | **A** |
| — OECD/Cette: TFP-Szenarien US | 0,6 / 1,4 | BIP 1,5 – 3,0 | %/a | 10 | **A** |
| **β** Demografie-Elastizität (Erwerbsalter) | **1,0** | 0,5 – 1,5 | pp/pp | 11, 12, 13, 14 | **A/B** |
| — Kotschy/Bloom: Einkommen p.c. je Erwerbsanteil | 0,8 – 1,0 | — | Elastizität | 11 | **A** |
| — Kotschy/Bloom: OECD-Bremse 2020–50 | −0,8 / −0,4 | — | pp/a | 11 | **A** |
| — Maestas et al.: +10 % Anteil 60+ | −5,5 % Niveau; −0,3 pp/a | — | — | 12 | **A** |
| — Acemoglu/Restrepo: Alterung → Wachstum | +0,77 (SE 0,32) / +1,70 (SE 0,41) IV | — | — | 13 | **A** |
| — Aksoy et al. (ABSG): UK-Altersstruktur 1970 | +0,68 | — | pp/a | 14 | **A** |
| **κ** Akkumulationsterm (Investitionsquote) | **0,11** | 0,07 – 0,15 | pp je pp (s−s_F) | 15, 16 (Herleitung α/(K/Y)) | **B** |
| **s_F** Frontier-Investitionsquote | 22 | 20 – 24 | % BIP | — | **C** |
| **μ** Strukturwandelbonus (Agraranteil) | **0,022** | 0,01 – 0,035 | pp je pp Agraranteil | 15, 17 | **C** |
| **TFP-Konvergenz in SSP-Modellen** | 1 – 5 | offenheitsabhängig | %/a | 15 | **A** |
| Kapitalabschreibung δ (ENV-Growth) | 5 | — | %/a | 15 | **A** |
| SSP-Weltwachstum p.c. 2010–2100 | 1,0 (SSP3) – 2,8 (SSP5) | — | %/a | 16 | **A** |
| **φ** Permanenzanteil von Rezessionen | **0,65** | 0,3 – 0,9 | Anteil | 18, 19, 20 | **A/B** |
| — BCS: kein bleibender Effekt / Niveauverlust / Ratenverlust | 31 % / 36 % / 33 % | — | Anteil | 20 | **A** |
| — Cerra/Saxena: kumulierter Verlust Bankenkrise | 11,7 / 12,7 | Bürgerkrieg 15,4–17,4 | % BIP | 18 | **A** |
| Erholungs-Halbwertszeit (transitorischer Teil) | **3** | 2 – 5 | Jahre | 18, 19 | **B** |
| **Phönix-Prämie** nach Kriegsende | **+2,0** | +1,0 – +3,0 | pp/a | 21, 22, 23, 24, 25 | **A/B** |
| — Chen/Loayza/Reynal-Querol: nach vs. vor Krieg | +2,4 | Gipfel Jahr 4–5 | pp/a | 23 | **A** |
| — Koubi: +10 % Kriegsdauer | +2,1 | — | % Wachstumsrate | 25 | **A** |
| Zeit bis Vorkriegs-*Trend* | **15 – 20** | Entwicklungsabhängig | Jahre | 21, 22, 24 | **A** |
| Kriegsniveauverlust am Kriegsort | −10 (Durchschnittsintensität) | −20 bei h=8 (WP) | % BIP | 26 | **A** |
| Klimaschaden: Niveaumodelle | 1 – 3 | Wachstumsmodelle: −84 % … +359 % | % BIP 2100 | 27 | **A** |

---

## 2. Vorgeschlagene Formel

Ausgabegröße: **reales BIP-Wachstum des Blocks i im Zug t** (nicht pro Kopf). Alle Niveaugrößen in **KKP**.

```
g_i(t) = g_F(t)                                    [Frontier]
       + λ · I_i(t) · ln( y_F(t) / y_i(t) )        [Konvergenz]
       + β · n_i(t)                                [Demografie]
       + κ · min( s_i(t) − s_F , Δs_max )          [Akkumulation]
       + μ · I_i(t) · max( a_i(t) − 5 , 0 )        [Strukturwandel]
       + Σ Schocks(t)                              [Ereignisse]
```

**Definitionen und Deckel**

- `g_F(t)` = 1,5 %/a, Wachstum des Frontier-Outputs **je Person im Erwerbsalter**. Erst ab 2060 auf 1,2 %/a absenken (Gordon-Pessimismus), es sei denn, ein Technologie-Modul liefert einen Schub (Cette-Szenario: bis 1,4 % TFP → ~3 % BIP).
- `y_i` = BIP je Kopf in KKP. `y_F` = USA (oder das jeweilige Maximum, falls die USA überholt werden).
- `I_i ∈ [0; 1,2]` = Institutionenfaktor aus dem Spielstand (Rechtssicherheit, Humankapital, Offenheit, Finanzsystem). **Sperre:** Bei `I_i < 0,15` (Staatszerfall, Totalembargo) wird der λ-Term auf 0 gesetzt — kein Aufholen ohne funktionierende Institutionen. Das ist die empirisch gedeckte Lesart von Kremer et al. (Institutionen-Homogenisierung trieb die Konvergenz) und der Gegenrede von Acemoglu/Molina (ohne Länder-Fixeffekte verschwindet der Befund).
- `n_i` = Wachstum der Bevölkerung im Erwerbsalter (15–64), **gedeckelt auf ±1,0 pp**. Grund: Maestas et al. implizieren eine stärkere, Acemoglu/Restrepo eine gar nicht negative Wirkung. Der Deckel schneidet beide Extreme ab. `β = 1,0` ist die reine Faktoreinsatz-Buchhaltung und damit die verantwortbarste Wahl; Kotschy/Bloom messen 0,8–1,0.
- `s_i` = Bruttoinvestitionsquote, `s_F = 22 %`, `Δs_max = 15 pp`. Der Deckel bildet fallende Kapitaleffizienz bei Übersteuerung ab (China: ICOR). Herleitung von κ: `κ = α/(K/Y)` mit α = 0,35 und K/Y = 3 → 0,117.
- `a_i` = Beschäftigungsanteil Landwirtschaft in %, Bonus **auf 1,5 pp gedeckelt**, mit `I_i` gewichtet (Strukturwandel ohne Institutionen verpufft).
- **Gesamtdeckel:** `g_i ∈ [−12 %; +12 %]` pro Zug; ohne Schocks `g_i ≤ 9 %`.

---

## 3. Probe-Rechnung 2026

KKP-Werte je Kopf (Näherung, **Güte C** — vor Spielbeginn durch aktuelle IMF-WEO-Werte ersetzen): USA 89 000, China 30 000, EU 65 000, Indien 12 500, Russland 49 000, Rest 17 000.

| Block | ln(y_F/y_i) | I | λ-Term | n | β-Term | s | κ-Term | a | μ-Term | **g** | Ziel |
|---|---|---|---|---|---|---|---|---|---|---|---|
| USA | 0,000 | 1,00 | 0,00 | +0,15 | +0,15 | 22 | 0,00 | 1,5 | 0,00 | **1,65** | ~2,0 |
| China | 1,088 | 0,85 | 1,48 | −0,90 | −0,90 | 41 | 1,65 | 22 | 0,32 | **4,05** | ~4,0 |
| EU | 0,314 | 1,00 | 0,50 | −0,60 | −0,60 | 22 | 0,00 | 4 | 0,00 | **1,40** | ~1,3 |
| Indien | 1,963 | 0,78 | 2,45 | +0,90 | +0,90 | 31 | 0,99 | 42 | 0,64 | **6,48** | ~6,5 |
| Russland | 0,597 | 0,45 | 0,43 | −0,40 | −0,40 | 24 | 0,22 | 6 | 0,01 | **1,76** | — |
| Rest | 1,655 | 0,35 | 0,93 | +1,40 | +1,40 | 25 | 0,33 | 30 | 0,19 | **4,35** | — |

KKP-gewichtetes Weltwachstum ≈ **3,6 %** (IMF-Referenz ~3,1–3,2 %).

**Befund und nötige Korrekturen:**

1. **Der reine λ-Term reicht nicht.** Mit λ = 1,6 %/a erzeugt der Log-Abstand für Indien nur +2,45 pp — um allein damit auf 6,5 % zu kommen, bräuchte man λ·I ≈ 3 %/a, weit außerhalb jeder Evidenz (Patel et al.: 0,43 %/a). Genau deshalb hat das Modul **den Akkumulations- und den Strukturwandelterm** bekommen. Das ist keine Bastelei, sondern die Bauweise der SSP-Modelle: Dellink et al. konvergieren TFP *und* Humankapital *und* Kapital getrennt.
2. **USA landen bei 1,65 % statt 2,0 %.** Das ist die CBO-Zahl (1,6–1,7 %) und damit korrekt, nicht zu niedrig. Wer 2,0 % will, muss `g_F` auf 1,8 % heben — dann steigt aber jeder Block um 0,3 pp und das Weltwachstum auf 3,9 %. **Empfehlung: 1,65 % stehen lassen**, den Rest über ein KI-/Technologie-Modul als expliziten positiven Schock buchen.
3. **Weltwachstum 0,4 pp zu hoch.** Korrektur nach Wahl: `g_F` auf 1,3 % senken (−0,2 pp überall), oder `I_Rest` von 0,35 auf 0,25 (−0,27 pp im größten Block).
4. **Russland 1,76 % ist der schockfreie Pfad** — Krieg und Sanktionen gehören in den Schockterm, nicht ins Basisniveau.

---

## 4. Hysterese- und Erholungsregel

**Grundregel: Schocks werden ausschließlich als NIVEAU-Schocks auf `y_i` und `K_i` gebucht, nie als Änderung von `g_i`.** Wachstumsraten sind in diesem Modul immer eine abgeleitete Größe. Das ist die zentrale Design-Lehre aus Cerra/Fatás/Saxena: Niveaus hängen von der Schockgeschichte ab, Raten nicht.

**Buchung eines Schocks der Größe L (in % des BIP):**
- Permanenter Anteil φ = 0,65 → `y_i ← y_i · (1 − 0,65·L)` dauerhaft.
- Transitorischer Anteil (1−φ) = 0,35 → in ein Erholungskonto, das mit **Halbwertszeit 3 Jahre** abgebaut wird: `R(t+1) = 0,79 · R(t)`, Zuschlag auf `g_i`.
- Kalibrierung von φ: Blanchard/Cerutti/Summers finden 31 % folgenlos, 36 % Niveauverlust, 33 % Ratenverlust → rund zwei Drittel bleibend. Cerra/Saxena finden gar keine Rückkehr zum Trend. φ = 0,65 liegt bewusst konservativ dazwischen; Mueller (2012) hat den Cerra/Saxena-Befund methodisch relativiert.
- Typische L-Werte: Finanzkrise 12 %, Bürgerkrieg 16 %, gewöhnliche Rezession 4–6 %.

**„Ratenhysterese" nur über Zustandsvariablen.** Wenn ein Schock dauerhaft wachstumsmindernd wirken soll, senkt man `I_i` (Institutionen), `s_i` (Investitionsquote) oder `n_i` — nie `g_F` und nie `g_i` direkt. So bleibt jede dauerhafte Wachstumsänderung im Spiel nachvollziehbar und rückholbar.

**Phönix-Effekt: nicht als Bonus, sondern als Mechanismus.** Der eleganteste Befund dieser Recherche: **die Konvergenzformel erzeugt den Phönix-Effekt bereits von selbst.** Verliert ein Block 30 % des BIP, wächst `ln(y_F/y_i)` um `ln(1/0,7) = 0,357`; bei λ·I = 1,6 sind das automatisch **+0,57 pp/a** zusätzlich. Der Rest kommt aus dem Wiederaufbau:

- **Wiederaufbau-Investition:** `s_i ← s_i + Δs_rec`, mit `Δs_rec = 15 pp` im ersten Nachkriegsjahr, Halbwertszeit 5 Jahre, Laufzeit 15 Jahre. Über κ = 0,11 gibt das **+1,65 pp/a** im ersten Jahr.
- **Summe:** +1,2 bis +2,2 pp/a über Trend — deckt sich mit Chen/Loayza/Reynal-Querol (+2,4 pp) und Koubi (+2,1 %).
- **Entwicklungsschranke (Kugler et al. 2013):** `Δs_rec` wird mit `I_i` skaliert. Bei `I_i ≥ 0,7` voller Wiederaufbau (Deutschland/Japan-Fall, volle Erholung); bei `0,35 ≤ I_i < 0,7` halber (Teilerholung); bei `I_i < 0,35` **kein** Wiederaufbauterm — Armutsfalle. Das bildet Kuglers dreigeteilten Befund direkt ab.
- **Konsistenzprobe:** Bei 30 % Verlust und ~2 pp Wachstumsprämie über einem 2-%-Basispfad wird das **Vorkriegsniveau nach ~9 Jahren**, der **Vorkriegstrend nach ~18 Jahren** wieder erreicht. Genau Organski/Kuglers 15–20 Jahre. Die Regel muss dafür nichts extra tun.
- **Warnung:** Federle et al. (AER 2026) finden am Kriegsort keinen Phönix — bei h = 8 noch −20 %, nach 16 Jahren unvollständig. Der Phönix ist ein Befund über *Großmächte nach Weltkriegen*, nicht über beliebige Kriege. Deshalb die Institutionenschranke.

**SSP-Warnung fürs Spiel:** Buhaug/Vestby zeigen, dass die SSP-Pfade genau deshalb zu optimistisch sind, weil sie Wachstumsunterbrechungen unterstellen — und keine enthalten. ERDE-01 sollte den Basispfad daher zusätzlich mit einer stochastischen Krisenrate belegen (Vorschlag: 4–6 % Wahrscheinlichkeit pro Block und Zug für eine Rezession mit L = 4–6 %).

---

## 5. Klimaschaden — Bestätigung der Niveau-Entscheidung

**Der Entscheid für Niveaueffekte trägt weiterhin, und zwar deutlich.** Newell, Prest & Sexton schätzen 800 Spezifikationen und zeigen: Wachstumsmodelle liefern ein 95-%-Intervall von **−84 % bis +359 % BIP**, Niveaumodelle ein enges Band von **1–3 % Verlust**, konsistent mit den großen IAM-Schadensfunktionen — und Spezifikationen mit verzögerten Temperaturtermen sprechen für Niveau-, nicht Wachstumseffekte. Nath, Ramey & Klenow bestätigen unabhängig: Temperatureffekte sind *persistent, aber nicht permanent* (3–5× größer als reine Niveaueffekte, 2–4× kleiner als permanente Ratenmodelle).

**Bilal & Känzig (QJE 2026) kippen den Entscheid nicht — sie verschieben nur die Größenordnung.** Ihr Befund (1 °C → >20 % Welt-BIP langfristig, SCC >1 200 $/t) ist ebenfalls in einem neoklassischen Wachstumsmodell als **Niveau**-Schadensfunktion formuliert. Die Streitfrage ist der Koeffizient, nicht die Funktionsform.

**Empfehlung:** Nordhaus' 1,2 %·ΔT² beibehalten (bei ΔT = 3 → 10,8 %; Waidelich et al. finden bei +3 °C ~10 % — gute Übereinstimmung). Zwei Zusätze:
1. **Einschwingzeit** statt Sofortwirkung: Niveauschaden über 20 Jahre linear hochfahren (Nath et al.).
2. **Hochschaden-Variante** als Szenarioschalter: Faktor 3–5 auf den Nordhaus-Koeffizienten (Bilal/Känzig-Ast) für Kampagnen, die Klimarisiko explizit spielen wollen.

---

## 6. Quellenregister

1. **The new era of unconditional convergence** — Patel, Sandefur, Subramanian, 2021, *Journal of Development Economics*. https://consensus.app/papers/details/f0d3ee16adf657b696c4ea3bbd7ecb85/?utm_source=claude_desktop · DOI 10.1016/j.jdeveco.2021.102687 · Volltext: https://www.cgdev.org/sites/default/files/new-era-unconditional-convergence.pdf — **A**
2. **Converging to Convergence** — Kremer, Willis, You, 2021, *NBER Macroeconomics Annual*. https://consensus.app/papers/details/eba19cd45d7e520ca03d69b975e61719/?utm_source=claude_desktop · DOI 10.1086/718672 — **A**
3. **Comment (zu Kremer et al.)** — Pande, Enevoldsen, 2022, *NBER Macroeconomics Annual*. https://consensus.app/papers/details/8e93694dba1e571584ea8ac50006f73e/?utm_source=claude_desktop · DOI 10.1086/718673 — **A**
4. **Convergence and Modernisation** — Barro, 2015, *The Economic Journal*. https://consensus.app/papers/details/6e2b5ac2f0b753eda4f8e3ae957204d0/?utm_source=claude_desktop · DOI 10.1111/ecoj.12247 — **A**
5. **A Meta-Analysis of β-Convergence: the Legendary 2 %** — de Groot et al., 2005, *Journal of Economic Surveys*. https://consensus.app/papers/details/dea4b80b28005340a3089351f28e81dc/?utm_source=claude_desktop · DOI 10.1111/j.0950-0804.2005.00253.x — **A**
6. **Converging to Converge? A Comment** — Acemoglu, Molina, 2021, *SSRN/NBER*. https://consensus.app/papers/details/9c9d61b9bd025371953e33a0158fd311/?utm_source=claude_desktop · DOI 10.3386/w28992 — **A** (Gegenrede: ohne Länder-Fixeffekte verzerrt)
7. **What Remains of Cross-Country Convergence?** — Johnson, Papageorgiou, *Journal of Economic Literature* (Consensus listet 2018). https://consensus.app/papers/details/f3f117325dd353fdb4a2e7c4e6ed4b3e/?utm_source=claude_desktop · DOI 10.1257/jel.20181207 — **A**
8. **Reassessing Longer-Run U.S. Growth: How Low?** — Fernald, 2016, FRBSF WP 2016-18. https://www.frbsf.org/wp-content/uploads/wp2016-18.pdf — **A**
9. **The Long-Term Budget Outlook: 2025 to 2055** — CBO, 2025. https://www.cbo.gov/publication/61270 — **A**
10. **Long-term growth and productivity projections in advanced countries** — Cette, Devillard, Spiezia, 2017, *OECD Journal: Economic Studies*. https://consensus.app/papers/details/d3c6dcac40d1507a90b394af3e35e5b0/?utm_source=claude_desktop · DOI 10.1787/eco_studies-2016-5jg1g6g5hwzs — **A**
11. **Population Aging and Economic Growth: From Demographic Dividend to Demographic Drag?** — Kotschy, Bloom, 2023, IZA DP 16377 / NBER w31585. https://consensus.app/papers/details/c816f9af294a5e84b130a9171c7b039a/?utm_source=claude_desktop · DOI 10.2139/ssrn.4546458 · https://docs.iza.org/dp16377.pdf — **A**
12. **The Effect of Population Aging on Economic Growth, the Labor Force and Productivity** — Maestas, Mullen, Powell, *AEJ: Macroeconomics* (Consensus/NBER-Fassung 2016). https://consensus.app/papers/details/f30fd7630ca152da8442d62b2fab25cb/?utm_source=claude_desktop · DOI 10.3386/w22452 — **A**
13. **Secular Stagnation? The Effect of Aging on Economic Growth in the Age of Automation** — Acemoglu, Restrepo, 2017, *AER P&P*. https://consensus.app/papers/details/2088171403da55999ccc54987c1b76de/?utm_source=claude_desktop · https://economics.mit.edu/sites/default/files/publications/Secular%20Stagnation%20-%20%20The%20Effect%20of%20Aging%20on%20Econo.pdf — **A**
14. **Demographic Structure and Macroeconomic Trends** — Aksoy, Basso, Smith, Grasl, 2019, *AEJ: Macroeconomics*. https://consensus.app/papers/details/bed4083f510b533c8fa084d96d127115/?utm_source=claude_desktop · DOI 10.2139/ssrn.2669321 — **A**
15. **Long-term economic growth projections in the Shared Socioeconomic Pathways** — Dellink, Chateau, Lanzi, Magné, *Global Environmental Change* (Consensus listet 2015). https://consensus.app/papers/details/2cbbd539375b54c3bb4dfad622c56479/?utm_source=claude_desktop · DOI 10.1016/j.gloenvcha.2015.06.004 · Methodendokument: https://ageconsearch.umn.edu/record/330258/files/6444_Dellink.pdf — **A**
16. **Future growth patterns of world regions – A GDP scenario approach** — Leimbach, Kriegler, Roming, Schwanitz, *Global Environmental Change* (Consensus listet 2015). https://consensus.app/papers/details/b0e60e079cbc5609adb1a6ffc2a1b966/?utm_source=claude_desktop · DOI 10.1016/j.gloenvcha.2015.02.005 — **A**
17. **An Econometric Model of International Growth Dynamics for Long-Horizon Forecasting** — Müller, Stock, Watson, 2020, *REStat*. https://consensus.app/papers/details/ffabc16fbb6a531b9409f5d0a2d579de/?utm_source=claude_desktop · DOI 10.1162/rest_a_00997 — **A** (heterogene Konvergenzraten, Unsicherheitsbänder)
18. **Growth Dynamics: The Myth of Economic Recovery** — Cerra, Saxena, 2008, *AER 98(1)*. https://consensus.app/papers/details/a7ce8ba5dc095853b3c7a8466eafe43d/?utm_source=claude_desktop · DOI 10.2139/ssrn.1013572 · BIS WP 226: https://www.bis.org/publ/work226.pdf — **A**
19. **Hysteresis and Business Cycles** — Cerra, Fatás, Saxena, 2020/2023, IMF WP 20/73 → *JEL*. https://consensus.app/papers/details/067191ddf637538cbb68018414ca0058/?utm_source=claude_desktop · DOI 10.5089/9781513536996.001 — **A**
20. **Inflation and Activity – Two Explorations and their Monetary Policy Implications** — Blanchard, Cerutti, Summers, 2015. https://consensus.app/papers/details/be9a68dd39985e2dbeffcd38af6d7a3d/?utm_source=claude_desktop · DOI 10.2139/ssrn.2689049 · https://www.nber.org/system/files/working_papers/w21726/w21726.pdf — **A**
21. **The Costs of Major Wars: The Phoenix Factor** — Organski, Kugler, 1977, *APSR*. https://consensus.app/papers/details/bd86b825d967522cb2bdec292d589d02/?utm_source=claude_desktop · DOI 10.2307/1961484 — **A**
22. **The War Ledger** — Organski, Kugler, 1980, Univ. of Chicago Press. https://consensus.app/papers/details/989c28811ed65c27b25447b2a72fc4ef/?utm_source=claude_desktop · DOI 10.7208/chicago/9780226351841.001.0001 — **A**
23. **The Aftermath of Civil War** — Chen, Loayza, Reynal-Querol, 2008, *World Bank Economic Review*. https://consensus.app/papers/details/9f45c75380315b878b03bd65a4b3a349/?utm_source=claude_desktop · DOI 10.1093/wber/lhn001 · https://econ-papers.upf.edu/papers/1043.pdf — **A**
24. **Demographic and Economic Consequences of Conflict** — Kugler, Kang, Organski, Bueno de Mesquita, Fisunoglu, 2013, *International Studies Quarterly*. https://consensus.app/papers/details/9b00a91b9d7d5edbb5b85b1dc7207310/?utm_source=claude_desktop · DOI 10.1111/isqu.12002 — **A**
25. **War and Economic Performance** — Koubi, 2005, *Journal of Peace Research*. https://consensus.app/papers/details/98192d49391a587f8cdb07aa6f0ac609/?utm_source=claude_desktop · DOI 10.1177/0022343305049667 — **A**
26. **The Price of War** — Federle, Meier, Müller, Mutschler, Schularick, 2026, *American Economic Review*. https://consensus.app/papers/details/c627eb2a8a0b5b8aabf661ecb657c33f/?utm_source=claude_desktop · DOI 10.1257/aer.20241355 · Kiel WP 2262: https://www.kielinstitut.de/fileadmin/Dateiverwaltung/IfW-Publications/fis-import/d0eb758e-36d1-41d3-b642-317c195334d1-KWP2262_The_Price_of_War.pdf — **A**
27. **The GDP-Temperature relationship: Implications for climate change damages** — Newell, Prest, Sexton, 2021, *JEEM*. https://consensus.app/papers/details/ee3e08cf3d4657039accfe74adcd2bfa/?utm_source=claude_desktop · DOI 10.1016/j.jeem.2021.102445 — **A**
28. **The Macroeconomic Impact of Climate Change: Global Versus Local Temperature** — Bilal, Känzig, 2026, *Quarterly Journal of Economics*. https://consensus.app/papers/details/8838409acf705cc385a063612e4203c9/?utm_source=claude_desktop · DOI 10.1093/qje/qjag011 (NBER-Fassung 2024: DOI 10.3386/w32450) — **A**
29. **How Much Will Global Warming Cool Global Growth?** — Nath, Ramey, Klenow, 2024, NBER w32761. https://consensus.app/papers/details/bbe242dfec3d504db4de4c05c9447cb8/?utm_source=claude_desktop · DOI 10.3386/w32761 — **A**
30. **Climate damage projections beyond annual temperature** — Waidelich et al., 2024, *Nature Climate Change*. https://consensus.app/papers/details/2cc10219758a5c7992f52c745b5814b0/?utm_source=claude_desktop · DOI 10.1038/s41558-024-01990-8 — **A**
31. **On Growth Projections in the Shared Socioeconomic Pathways** — Buhaug, Vestby, 2019, *Global Environmental Politics*. https://consensus.app/papers/details/819345e5250a59e4b10f24b27b0524eb/?utm_source=claude_desktop · DOI 10.1162/glep_a_00525 — **A**
32. **Growth Dynamics: The Myth of Economic Recovery: Comment** — Mueller, 2012, *AER 102(7)*. https://www.aeaweb.org/articles?id=10.1257%2Faer.102.7.3774 · DOI 10.1257/aer.102.7.3774 — **A**

**Nicht belegt:** Crespo Cuaresma (2017) konnte über keines der Werkzeuge direkt aufgefunden werden; die SSP-Funktionsform stützt sich daher auf Dellink et al. (15) und Leimbach et al. (16). Die KKP-Ausgangswerte und die Institutionenfaktoren `I_i` sind Kalibrierannahmen (**C**) und vor Kampagnenstart durch aktuelle IMF-WEO-Werte bzw. den Spielstand zu ersetzen.
