# Anhang D — Recherche »Energieausbau: empirische Höchstraten« (Agent D, 02.09.2026)

*Rohbericht des Rechercheagenten, unverändert. Gütemarken: A belegt · B abgeleitet · C geschätzt.*

**Kernbefund vorweg:** Die EH‑01‑Deckel sind nicht durchgängig zu niedrig — sie sind *falsch verteilt*. Solar und Wind sind zu niedrig gedeckelt, Kohle und Batterie deutlich zu niedrig, Gas etwa richtig aber falsch begrenzt (Fertigung statt Geld), und SMR/Thorium/Fusion/Tiefengeothermie/Gezeiten/H2 sind um ein bis zwei Größenordnungen **zu hoch**. Der Gesamtengpass von 650 GW/a liegt unter dem heutigen Ist‑Zubau. Und die Form ist falsch: fester Exponentialdeckel mit hartem ×6‑Anschlag statt S‑Kurve.

---

### 1. Ist‑Zubau 2019–2025 (GW/a, sofern nicht anders vermerkt)

| Träger | 2019 | 2020 | 2021 | 2022 | 2023 | 2024 | 2025 | Quelle |
|---|---|---|---|---|---|---|---|---|
| **Solar global (DC)** | n.b. | 139,4 | ≥175 | ≥240 | 446 | 554–602 | 605 | [18–22, 17] |
| Solar global (AC/IRENA) | – | – | – | – | – | 452 | 511 | [23, 24] |
| Solar global (Ember) | – | – | – | – | – | 582 | **647** | [28, 31] |
| **Solar China** | n.b. | 48,2 | 54,9 | 105,5 | 235 (bis 277) | 277–278 (bis 357 DC) | **315,1 AC / ~370 DC** | [22, 21, 20, 19, 24, 32, 17] |
| **Wind global** | n.b. | n.b. | n.b. | n.b. | 116,6 | 117 (109 on/8 off) | **165 (155,3 on/9,3 off)** | [26, 27, 25] |
| Wind global (IRENA/IEA) | – | – | – | – | – | 113 | 159 / ~160 | [24, 23, 17] |
| **Wind China** | n.b. | n.b. | n.b. | n.b. | n.b. | 79,8 | **120,5** (NEA: 119,3) | [27, 25, 32] |
| **Batterien global** | – | – | – | – | – | ~76 GW / ~207 GWh | **112 GW / 307 GWh** | [33]; Netzspeicher: ~171→250 GWh [28] |
| **Kernkraft** | – | – | – | – | – | 6 Reaktoren netzgekoppelt; 9 Baustarts (6 CN) | Bestand 408 Rkt/368,7 GW; **63 Rkt/60 GW im Bau** | [34] |
| Kernkraft China | – | – | – | ≥10 Genehm. | ≥10 | ≥10 | **10 Genehm.**; 30 Rkt/34,4 GW im Bau | [35] |
| **Kohle China** | – | – | – | – | – | 98 GW Baustart | **78 GW ans Netz**, 83 GW Baustart, 45 GW Genehm., 161 GW neu vorgeschlagen (Rekord) | [36, 37] |
| **Gas (Fertigung)** | – | – | – | – | – | ~80 GW Bestellungen | **~30 GW/a Fertigungskapazität der 3 OEM**; Slots bis 2030 | [38, 39] |
| **Wasserkraft** | – | – | – | – | – | 15,0 (IHA inkl. PSW: 24,6) | **18,4** | [24, 23, 42] |
| **Bioenergie** | – | – | – | – | – | 4,6 | 3,4 | [24, 23] |
| **Geothermie** | – | – | – | – | – | 0,4 | 0,3 | [24, 23] |

*Warnung zur Einheit:* IRENA zählt netzangeschlossene AC‑Leistung, IEA‑PVPS/IEA zählen DC‑Modulleistung. Der Unterschied beträgt 15–25 % (2025: 511 vs. 605–647 GW). **EH‑01 muss sich auf eine Konvention festlegen** — sonst ist der Deckel um bis zu ein Viertel falsch.

Nicht belegt: Solar 2019, Wind 2019–2022 (in dieser Sitzung nicht aus Primärquellen bestätigt); historischer Kernkraft‑Spitzenwert 1984/85 (~33 GW/a) — **nicht belegt**, weder WNISR‑HTML noch IAEA‑RDS‑2 lieferten die Jahreszahl.

---

### 2. Empirische Höchstraten (%/a der nationalen Stromversorgung)

| Träger | Cherp 2021 [1] | Vinichenko 2023 [2] | Beobachtetes Maximum 2025 (abgeleitet) |
|---|---|---|---|
| Solar | **0,6 %** (IQR 0,4–0,9) | **0,8 %** (IQR 0,5–1,3) | **China ~3,9–4,6 %/a** — 3–5× über dem Q3 |
| Wind onshore | **0,8 %** (IQR 0,6–1,1) | **1,1 %** (IQR 0,6–1,7) | **China ~2,4–3,0 %/a**; EU ~1,7 % (genau am Q3) |
| Kernkraft | – | **2,6 %** (IQR 1,3–**6,0**) | Westeuropa 1980er; heute weltweit ≈0,03 %/a |

**Das ist der wichtigste Befund des Berichts.** Die Cherp/Vinichenko‑Verteilungen stammen aus Stichproben, die *vor* dem chinesischen Solarsprung enden. China hat 2024/25 das obere Quartil der Solar‑Verteilung um Faktor 3–5 gebrochen. Wer die Literaturmediane als Deckel nimmt, baut ein Modell, das die reale Welt von 2025 verbietet. Umgekehrt: Summiert man die Q3‑Raten über alle Blöcke, ergibt sich für Solar nur ~294 GW/a — die Welt hat 2025 aber 605–647 GW gebaut.

Weiteres aus der Literatur:
- **PROLONG** [3] beschreibt Wachstum als lange „Reisegeschwindigkeit"‑Phasen, **unterbrochen von Wachstumspulsen**, meist durch Politikwechsel ausgelöst; modelliert mit bilogistischen Funktionen, 13 000 Monte‑Carlo‑Läufen und Quantile‑Random‑Forests. Zentralprojektion 2050: Wind **25,6 %** (IQR 20,5–33,7) Anteil an der Weltstromversorgung, Solar **20,8 %** (14,5–29). Das COP28‑Verdreifachungsziel liegt am 95. Perzentil.
- **Wilson et al. 2013** [5]: robuste **Extent–Duration‑Beziehung** — wie viel eine Technologie wächst, hängt konsistent damit zusammen, wie lange sie wächst; Szenarien sind gegenüber der Historie eher *konservativ*.
- **Grubler/Wilson/Nemet 2016** [4]: Der „Apples‑and‑Oranges"‑Punkt — globale Systemtransitionen (Jahrzehnte bis Jahrhunderte) und einzelne Technologiediffusionen (Jahre bis Jahrzehnte) dürfen nicht in derselben Metrik verglichen werden. **Für EH‑01 heißt das: globale Deckel sind das falsche Konstrukt; Deckel gehören auf Blockebene.**
- **Wilson et al. 2020, Science** [6]: Granulare Technologien (klein, billig, viele, verteilt) diffundieren schneller, lernen schneller, haben geringeres Investitionsrisiko. Rangordnung der Ausbaugeschwindigkeit folgt der Granularität — Solar/Batterie ≫ Wind ≫ Gas ≫ Kernkraft.
- **Way et al. 2022, Joule** [7]: Wenn Solar, Wind, Batterien und Elektrolyseure ihre **derzeitigen exponentiellen Trends noch ein Jahrzehnt** halten, ist ein Nahe‑Netto‑Null‑System in 25 Jahren erreichbar — und **billiger** als Weiterso. Ein kernkraftgetriebener Übergang ist „far more expensive".
- **Nemet 2023 (HAT‑Datensatz)** [10]: 100 Jahre Technologiediffusion, logistische Wachstumsrate **1,1–14,3 %/a, Median 6,2 %/a**. Das ist die beste verfügbare Prior‑Verteilung für einen *Deckel­wachstums*parameter.
- **Bento & Wilson 2016** [9]: Formativphasen dauern im Mittel **22 Jahre** — vor der Wachstumsphase. Relevant für Fusion/Thorium/SMR im Spiel.
- **Powell et al. 2015** [15]: kapitalbegrenzte nachhaltige Wachstumsrate der PV‑Fertigung ≈ **19 %/a**; historisch realisiert ~50 %/a. **Haegel et al. 2023** [14]: 25 %/a PV‑Wachstum ist im kommenden Jahrzehnt möglich.

---

### 3. Stromerzeugung je Block 2025 und abgeleitete Deckel

**Belegte Erzeugung 2025 (TWh):** Welt **31 747** · China **10 580** · USA **4 520** · Indien **2 082** · Russland **1 193** · Japan 1 030 [41, 29]. **EU‑27 ≈ 2 840** (abgeleitet: Ember nennt 369 TWh Solar = 13 % der EU‑Erzeugung [30]). **Rest = 31 747 − 21 215 = 10 535 TWh.**

**Rechenweg:** `Deckel [GW/a] = (r × E) / (8,76 × CF)`, r = Höchstrate in %/a, E = Blockerzeugung in TWh, CF = blockspezifischer Kapazitätsfaktor. (1 GW liefert 8,76 × CF TWh/a.)

*Beispiel China Solar:* 10 580 TWh × 4,0 % = 423,2 TWh; CF 0,15 → 8,76 × 0,15 = 1,314 TWh/GW; 423,2 / 1,314 = **322 GW/a**. Ist 2025: 315 GW — Modell trifft.

| Block | E (TWh) | **Solar** CF / Median 0,8 % / Q3 1,3 % / **Max 4,0 %** | **Wind** CF / Median 1,1 % / Q3 1,7 % / **Max 2,5 %** | **Kern** CF 0,85 / Median 2,6 % / Q3 6,0 % |
|---|---|---|---|---|
| USA | 4 520 | 0,21 · 20 / 32 / **98** | 0,35 · 16 / 25 / **37** | 16 / 36 |
| China | 10 580 | 0,15 · 64 / 105 / **322** | 0,24 · 55 / 86 / **126** | 37 / 85 |
| EU | 2 840 | 0,12 · 22 / 35 / **108** | 0,26 · 14 / 21 / **31** | 10 / 23 |
| Indien | 2 082 | 0,19 · 10 / 16 / **50** | 0,24 · 11 / 17 / **25** | 7 / 17 |
| Russland | 1 193 | 0,13 · 8 / 14 / **42** | 0,30 · 5 / 8 / **11** | 4 / 10 |
| Rest | 10 535 | 0,17 · 57 / 92 / **283** | 0,28 · 47 / 73 / **107** | 37 / 85 |
| **Summe** | 31 750 | **181 / 294 / 903** | **148 / 229 / 337** | **111 / 256** |

Kontrollen: Wind‑Summe Median 148 / Q3 229 klammert den Ist‑Wert 165 GW korrekt ein. Solar‑Q3‑Summe 294 GW liegt um Faktor 2,1 **unter** dem Ist‑Wert — Beweis, dass die Solar‑Literaturverteilung veraltet ist. Kernkraft‑Summe 111 GW/a liegt um Faktor **15–20 über** der Realität (5–7 GW/a Netzanschlüsse): Die %‑Metrik überschätzt Kernkraft massiv, weil deren Engpass Schmiedekapazität, Genehmigung und Bauzeit ist, nicht die Aufnahmefähigkeit des Netzes.

---

### 4. Urteil je EH‑01‑Parameter

| Parameter | Ist EH‑01 | Empirie 2025 | Urteil |
|---|---|---|---|
| Solar 550 GW/a, +6 %/a, ×6 | 550 | **605–647** | **Ändern:** Basis 650 GW/a. Deckelwachstum +6 % ist zu träge gegenüber +25–30 %/a 2020–24, aber die Verlangsamung 2024→25 (+11 % Ember, +12 % IEA) ist real. **Form ändern** (s.u.), Startwachstum +12 %/a, mit Anteil abklingend. ×6 = 3 900 GW/a bleibt als Fernanschlag plausibel. |
| Wind 120 GW/a, +4 %/a | 120 | **165** | **Ändern auf 175 GW/a**, Wachstum +5 %/a. GWEC erwartet 2026–30 im Mittel 194 GW/a (CAGR 5,2 %) [25] — Deckel muss darüber liegen. |
| Kernspaltung 15 GW/a, +0 %/a | 15 | 5–7 (Netz); 60 GW im Bau ≈ 8–10 GW/a Pipeline | **Basis halten (15)**, aber **+0 %/a ändern auf +3 %/a**. Schmiedekapazität ist ausbaufähig; Vinichenko‑Q3 (6 %/a der Versorgung) beweist historisch weit höhere Raten. Zusätzlich **Bauzeit‑Sperre** (7–10 Jahre Vorlauf) statt reinem Jahresdeckel. |
| SMR 8 GW/a | 8 | **~0** kommerziell | **Ändern auf 0,3 GW/a**, +20 %/a ab Techgate. Formativphase im Mittel 22 Jahre [9]. |
| Thorium 5 / Fusion 5 | 10 | **0** | **Ändern auf 0** bis Techgate; danach 0,5 GW/a. |
| Tiefengeothermie 10 GW/a, +10 % | 10 | Geothermie gesamt **0,3** | **Ändern auf 0,3 GW/a**, +15 %/a. |
| Gas 60 GW/a | 60 | **~30 GW/a westliche OEM‑Fertigung**, ~80 GW Bestellungen 2024, Slots bis 2030 | **Form ändern:** 60 GW/a global ist plausibel (China/Russland/Indien bauen eigene), aber **Sub‑Deckel 30 GW/a für alle Blöcke, die vom GE‑Vernova/Siemens/Mitsubishi‑Trio abhängen**, bis 2029; Lieferzeit 5–8 Jahre als Spielregel. Das ist die interessanteste neue Spielgröße. |
| Kohle 40 GW/a | 40 | **China allein 78 GW ans Netz 2025** | **Ändern auf 100 GW/a** global, davon China‑Sub‑Deckel 90. Genehmigung→Netz‑Verzug ~3 Jahre einbauen (2025: 161 GW vorgeschlagen, 83 GW Baustart, 78 GW ans Netz). |
| Öl 10 GW/a | 10 | vernachlässigbar | **Ändern auf 3 GW/a.** |
| Wasser 20 GW/a | 20 | 15,0 (2024) / 18,4 (2025) | **Halten.** Optional +10 GW/a Pumpspeicher separat. |
| Bio 10 GW/a | 10 | 3,4–4,6 | **Ändern auf 5 GW/a.** |
| Geothermie 1 GW/a | 1 | 0,3–0,4 | **Ändern auf 0,5 GW/a.** |
| Gezeiten 2 GW/a | 2 | ≈0,01–0,05 | **Ändern auf 0,05 GW/a.** |
| H2‑Backup 30 GW/a | 30 | ≈0 (H2‑Turbinen), Elektrolyse 1–2 GW/a | **Ändern auf 1 GW/a**, +25 %/a. Odenweller 2022 [11]: selbst bei Wind/Solar‑Tempo bleibt grüner H2 bis 2030/35 unter 1 % des Endenergieverbrauchs. |
| Batterie +10 %/a, ×10, nicht kaufbar | +10 % | **+48 % (GW) / +46 % (GWh) 2025**; 112 GW / 307 GWh | **Ändern:** +30 %/a abklingend, Deckel ×20, **und kaufbar machen.** Batterie ist die granularste Technologie im Baum [6] — sie darf nicht als Naturkonstante laufen. |
| Gesamtengpass 650 GW/a (2045–55) | 650 | 2025 bereits **>950 GW/a** aller Träger | **Ändern auf ≥1 600 GW/a**, wachsend. Der jetzige Wert verbietet 2045 die Realität von 2025. |
| Kapital 2,8 Bio $/a, „bindet fast nie" | – | – | **Teilweise falsch.** Bei heutigem Zubau bindet Geld tatsächlich nicht (~0,7 Bio $/a für VRE+Speicher, **C — geschätzt**). Am ×6‑Anschlag (3 900 GW/a Solar) würde Solar allein ~2,3 Bio $/a binden. **Empfehlung: Kapitalschranke aktiv lassen, aber erst oberhalb ~3× des heutigen Zubaus greifen.** Powell 2015 [15] gibt zusätzlich eine *kapitalbegrenzte Fertigungswachstumsrate* von ~19 %/a — das ist der eigentliche Geldkanal. |

---

### 5. Empfehlung: Deckelform und Modul‑„Leihe"

**Form.** Ersetze `Deckel(t) = Basis · (1+g)^t`, gekappt bei ×6, durch eine logistische Ableitung **je Block und Träger**:

```
Deckel(Block, Träger, t) = 4 · G_max · E(Block,t) / (8,76·CF) · s·(1 − s/s_sat) · P(t)
```

mit `s` = aktueller Anteil des Trägers an der Blockstromversorgung, `s_sat` ≈ 0,45 (Solar), 0,35 (Wind), 0,75 (Kern), `G_max` aus Tabelle 3. Das erzeugt genau das, was die S‑Kurven‑Literatur zeigt [1, 2, 5]: **niedrige Rate am Anfang (Formativphase), Maximum bei mittlerem Anteil, Abflachen bei hohem Anteil** — statt eines Deckels, der bis zum Anschlag exponentiell wächst und dann hart abschneidet.

`P(t)` ist der **Pulsfaktor nach PROLONG** [3]: mit p ≈ 12 %/Jahrzug tritt ein Block in einen Puls ein (P = 1,5–3,0 für 3–7 Züge), ausgelöst durch Politikwechsel, Preisschock oder Versorgungskrise — genau der Mechanismus, der Frankreichs Kernkraft nach 1973 und die EU nach 2022 erklärt [2]. Umgekehrt gibt es Anti‑Pulse (P = 0,4) nach Unfällen, Netzengpässen, Genehmigungsstopps. Das ist die spielmechanisch fruchtbarste Übernahme aus der Literatur: **Ausbau kommt in Schüben, nicht als Rampe.**

**Ist „Leihen" möglich?** Ja — und es sollte die zentrale Handelsgröße sein. China hält **über 80 % aller fünf PV‑Fertigungsstufen** (Polysilizium, Ingot, Wafer, Zelle, Modul), bei Polysilizium/Ingot/Wafer künftig **~95 %**; ein einziges Werk fertigt jedes siebte Modul weltweit; Xinjiang allein 40 % des Polysiliziums [40]. Cui et al. 2025 [13] zeigen, dass China selbst unter ambitionierten EU‑Lokalisierungszielen bis 2030 dominant bleibt. Helveston et al. 2022 [12] beziffern die Kosten der Entkopplung: Modulpreise **20–25 % höher bis 2030** ohne globale Lieferkette.

Spielregel‑Vorschlag:
1. Jeder Block hat einen **Eigenfertigungsdeckel** (China ~450 GW/a Solar; EU/USA/Indien je 25–60 GW/a) und einen **Importdeckel**, der die Differenz zum Blockdeckel aus Tabelle 3 füllt.
2. Import kostet +0 % Aufschlag, erzeugt aber **Handelsabhängigkeit D** (Anteil importierter Module). Bei D > 0,5 kann der Lieferblock in einer Krise **die Lieferung drosseln**: Zubaudeckel des Käufers fällt in einem Zug auf den Eigenfertigungsdeckel.
3. Eigenfertigungsaufbau kostet Kapital und **19 %/a maximale Wachstumsrate** der Fabrikkapazität [15] — also 4 Züge Vorlauf, bevor eine Substitution greift.
4. Analog für Gasturbinen (Trio ~30 GW/a, Slots bis 2030 [38, 39]) und Kernkraft‑Schmiedeteile.

---

### 6. Consensus‑Hinweis

**Keine der elf Consensus‑Abfragen enthielt eine Sign‑up‑, Upgrade‑ oder Nutzungszähler‑Meldung.** Zurückgegeben wurde ausschließlich der Zitierhinweis („IMPORTANT INSTRUCTIONS: When discussing these findings, you MUST cite papers inline…"). Es gibt daher nichts wörtlich wiederzugeben.

---

### 7. Quellenregister

**Peer Review (alle über Consensus, URLs exakt übernommen):**

[1] [National growth dynamics of wind and solar power compared to the growth required for global climate targets](https://consensus.app/papers/details/e78166846fa6504da4b7e4d9ee39a54b/?utm_source=claude_desktop) — Cherp et al., 2021, Nature Energy, DOI 10.1038/s41560-021-00863-0 — **A**
[2] [Historical diffusion of nuclear, wind and solar power in different national contexts](https://consensus.app/papers/details/7ebd2569ad305cf69cd05addf3bff0ca/?utm_source=claude_desktop) — Vinichenko et al., 2023, Environmental Research Letters, DOI 10.1088/1748-9326/acf47a — **A**
[3] [Probabilistic projections of global wind and solar power growth based on historical national experience](https://consensus.app/papers/details/dc39dff889765d24a18b631288be4c9b/?utm_source=claude_desktop) — Jakhmola et al., 2026, Nature Energy, DOI 10.1038/s41560-026-02021-w — **A**
[4] [Apples, oranges, and consistent comparisons of the temporal dynamics of energy transitions](https://consensus.app/papers/details/b20af0f0833c528bb5f5393cd9213eb5/?utm_source=claude_desktop) — Grubler, Wilson, Nemet, 2016, Energy Research & Social Science, DOI 10.1016/j.erss.2016.08.015 — **A**
[5] [Future capacity growth of energy technologies: are scenarios consistent with historical evidence?](https://consensus.app/papers/details/01a4bc27e73a56c1acbd087c51bd40bf/?utm_source=claude_desktop) — Wilson et al., 2013, Climatic Change, DOI 10.1007/s10584-012-0618-y — **A**
[6] [Granular technologies to accelerate decarbonization](https://consensus.app/papers/details/1078204c565057d3b6b9a41cb629354b/?utm_source=claude_desktop) — Wilson et al., 2020, Science, DOI 10.1126/science.aaz8060 — **A**
[7] [Empirically grounded technology forecasts and the energy transition](https://consensus.app/papers/details/d6b7d68598e651e7815e8b6e4dcc5d0d/?utm_source=claude_desktop) — Way, Ives, Mealy, Farmer, 2022, Joule, DOI 10.1016/j.joule.2022.08.009 — **A**
[8] [Beyond the learning curve: factors influencing cost reductions in photovoltaics](https://consensus.app/papers/details/cd1a6148b5fa55a380873ee6e32c3035/?utm_source=claude_desktop) — Nemet, 2006, Energy Policy, DOI 10.1016/j.enpol.2005.06.020 — **A**; Buch 2019 nur als [Rezension](https://consensus.app/papers/details/7c92f48e514f5ba68a2923a42a5604fe/?utm_source=claude_desktop), DOI 10.1111/ecaf.12365 — **B**
[9] [Measuring the duration of formative phases for energy technologies](https://consensus.app/papers/details/d7eeeb71c87a5900be50696306ca8854/?utm_source=claude_desktop) — Bento & Wilson, 2016, EIST, DOI 10.1016/j.eist.2016.04.004 — **A**
[10] [Dataset on the adoption of historical technologies informs the scale-up of emerging carbon dioxide removal measures](https://consensus.app/papers/details/659f49d8a92c5ea7a0a4eb6422236277/?utm_source=claude_desktop) — Nemet et al., 2023, Communications Earth & Environment, DOI 10.1038/s43247-023-01056-1 — **A**
[11] [Probabilistic feasibility space of scaling up green hydrogen supply](https://consensus.app/papers/details/dae71d46c7e857a2827b807f80555e74/?utm_source=claude_desktop) — Odenweller et al., 2022, Nature Energy, DOI 10.1038/s41560-022-01097-4 — **A**
[12] [Quantifying the cost savings of global solar photovoltaic supply chains](https://consensus.app/papers/details/dad359b7be2052bcbb386586af969119/?utm_source=claude_desktop) — Helveston et al., 2022, Nature, DOI 10.1038/s41586-022-05316-6 — **A**
[13] [Policy-driven transformation of global solar PV supply chains and resulting impacts](https://consensus.app/papers/details/5304781cbb8b5531a962e8b069e17c39/?utm_source=claude_desktop) — Cui et al., 2025, Nature Communications, DOI 10.1038/s41467-025-61979-5 — **A**
[14] [Photovoltaics at multi-terawatt scale: Waiting is not an option](https://consensus.app/papers/details/5b5fbfd733185d5980e31c8b08144a8b/?utm_source=claude_desktop) — Haegel et al., 2023, Science, DOI 10.1126/science.adf6957 — **A**
[15] [The capital intensity of photovoltaics manufacturing](https://consensus.app/papers/details/303deab4a4d25955b88c062dcf6fc7cc/?utm_source=claude_desktop) — Powell et al., 2015, Energy & Environmental Science, DOI 10.1039/c5ee01509j — **A**
[16] [Feasibility trade-offs in decarbonising the power sector with high coal dependence: Korea](https://consensus.app/papers/details/fb788964419c54a596b7cc50dee8dc77/?utm_source=claude_desktop) — Hyun et al., 2023, RSET, DOI 10.1016/j.rset.2023.100050 — **A**

**Institutionell:**

[17] IEA, *Global Energy Review 2026 — Solar PV and wind*, https://www.iea.org/reports/global-energy-review-2026/technology-solar-pv-and-wind — **A**
[18] IEA‑PVPS, *Snapshot of Global PV Markets 2025*, https://iea-pvps.org/wp-content/uploads/2025/04/Snapshot-of-Global-PV-Markets_2025.pdf — **A**
[19] IEA‑PVPS, *Snapshot 2024*, https://iea-pvps.org/wp-content/uploads/2024/04/Snapshot-of-Global-PV-Markets-1.pdf — **A**
[20] IEA‑PVPS, *Snapshot 2023*, https://iea-pvps.org/wp-content/uploads/2023/04/IEA_PVPS_Snapshot_2023.pdf — **A**
[21] IEA‑PVPS, *Snapshot 2022*, https://iea-pvps.org/wp-content/uploads/2022/04/IEA_PVPS_Snapshot_2022-vF.pdf — **A**
[22] IEA‑PVPS, *Snapshot 2021*, https://iea-pvps.org/wp-content/uploads/2021/04/IEA_PVPS_Snapshot_2021-V3.pdf — **A**
[23] IRENA, *Renewable Capacity Highlights, 31 March 2026*, https://www.irena.org/-/media/Files/IRENA/Agency/Publication/2026/Mar/IRENA_DAT_RE_capacity_highlights_2026.pdf — **A**
[24] IRENA, *Renewable Capacity Highlights, 26 March 2025*, https://www.irena.org/-/media/Files/IRENA/Agency/Publication/2025/Mar/IRENA_DAT_RE_Capacity_Highlights_2025.pdf — **A**
[25] GWEC, *Global Wind Report 2026* (PM), https://www.gwec.net/news/global-wind-installations-rise-record-40-as-industry-charts-way-out-of-energy-crisis — **A**
[26] GWEC, *Global Wind Report 2025*, https://26973329.fs1.hubspotusercontent-eu1.net/hubfs/26973329/2.%20Reports/Global%20Wind%20Report/GWEC%20Global%20Wind%20Report%202025.pdf — **A**
[27] GWEC, PM 2024‑Rekord, https://www.gwec.net/news/wind-industry-installs-record-capacity-in-2024-despite-policy-instability — **A**
[28] Ember, *Global Electricity Review 2026*, https://ember-energy.org/latest-insights/global-electricity-review-2026/ — **A**
[29] Ember, GER 2026 — Demand & supply trends, https://ember-energy.org/latest-insights/global-electricity-review-2026/electricity-demand-and-supply-trends/ — **A**
[30] Ember, *European Electricity Review 2026*, https://ember-energy.org/latest-insights/european-electricity-review-2026/ — **A**
[31] TaiyangNews zu Ember GER 2026 (647/582 GW), https://taiyangnews.info/markets/ember-global-electricity-review-2026 — **B**
[32] pv magazine / China NEA, *China adds 315 GW of solar in 2025*, https://www.pv-magazine.com/2026/01/28/china-adds-315-gw-of-solar-in-2025/ — **A**
[33] BloombergNEF via ESS‑News, https://www.ess-news.com/2026/05/11/bloombergnef-confirms-energy-storage-has-reached-the-100-gw-era/ — **B**
[34] *World Nuclear Industry Status Report 2025*, https://www.worldnuclearreport.org/World-Nuclear-Industry-Status-Report-2025-HTML-version — **A**
[35] World Nuclear News, *Ten new reactors approved in China*, https://www.world-nuclear-news.org/articles/ten-new-reactors-approved-in-china — **A**
[36] CREA/GEM, *China Coal Power H2 2025*, https://energyandcleanair.org/wp/wp-content/uploads/2026/02/CREA_GEM_China_Coal-power_H2-2025.pdf — **A**
[37] Carbon Brief, *'Rush' for new coal in China hits record high in 2025*, https://www.carbonbrief.org/rush-for-new-coal-in-china-hits-record-high-in-2025-as-climate-deadline-looms — **A**
[38] IEEFA, *Global gas turbine shortages* (Okt. 2025), https://ieefa.org/sites/default/files/2025-10/IEEFA%20Report_Global%20gas%20turbine%20shortages%20add%20to%20LNG%20challenges%20in%20Vietnam%20and%20the%20Philippines_October2025.pdf — **A**
[39] Orban Labs, *Gas Turbine Supply Crunch*, https://orbanlabs.com/journal/005-gas-turbine-supply-crunch — **B**
[40] IEA, *Solar PV Global Supply Chains — Executive Summary*, https://www.iea.org/reports/solar-pv-global-supply-chains/executive-summary — **A**
[41] Wikipedia (Datenbasis Ember 2025), *List of countries by electricity production*, https://en.wikipedia.org/wiki/List_of_countries_by_electricity_production — **B**
[42] IHA, *2025 World Hydropower Outlook*, https://www.hydropower.org/publications/2025-world-hydropower-outlook — **B**

**Nicht belegt:** Solar‑Weltzubau 2019; Wind‑Weltzubau 2019–2022; historischer Kernkraft‑Spitzenzubau 1984/85 in GW/a; EU‑27‑Gesamterzeugung 2025 als publizierte Zahl (nur abgeleitet, **B**); globale Gasturbinen‑Inbetriebnahmen in GW/a (nur Fertigungs‑ und Bestellkapazität belegt); Gezeiten‑ und H2‑Turbinen‑Jahreszubau.
