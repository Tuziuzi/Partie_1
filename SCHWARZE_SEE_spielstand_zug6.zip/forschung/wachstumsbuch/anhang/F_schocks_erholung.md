# Anhang F — Recherche »Schocks: Krieg, Sanktionen, Handelskrieg, Fragmentierung, Erholung« (Agent F, 02.09.2026)

*Rohbericht des Rechercheagenten, unverändert. Gütemarken: A belegt · B abgeleitet · C geschätzt.*

## 1. Schocktabelle

**Konvention:** „Pp/a" = Abzug von der Wachstumsrate im Zug; „% Niveau" = einmaliger Abzug vom BIP-Niveau gegenüber Basispfad. Der wichtigste Befund vorweg: **die meiste belastbare Evidenz ist Niveau-Evidenz, nicht Wachstumsraten-Evidenz.** Die bestehenden Spielregeln lesen Niveaueffekte als Dauer-Wachstumsabzüge und überzeichnen dadurch systematisch.

| # | Schocktyp | Verlust | Dauer | Dauerhafter Anteil P | Halbwertszeit H | Quellen | Güte |
|---|---|---|---|---|---|---|---|
| S1 | Krieg auf eigenem Territorium (zwischenstaatlich, hohe Intensität) | −30 % Niveau | 5 Züge Aufbau | 0,45 | 8 | [1] | **A** |
| S2 | Krieg mittlerer Intensität | −10 % Niveau, Preise +20 % | 5 Züge | 0,30 | 6 | [2] | **A** |
| S3 | Nachbar eines Kriegsortes (< ~5.000 km) | −10 % Niveau, Inflation +5 Pp | 5 Züge | 0,15 | 3 | [1][3] | **A** |
| S4 | Entfernte Dritte (> 5.000 km, geringe Handelsverflechtung) | 0 bis leicht positiv | – | 0 | – | [1][3] | **A** |
| S5 | Bürgerkrieg | −17,5 % Niveau/Kriegsjahr (lokal); −18 % Output kumuliert | Kriegsdauer | 0,50 | 6 | [4][5] | **A** |
| S6 | Konflikt, 10-Jahres-Horizont | BIP p.c. −28 %, Exporte −58 %, Importe −34 % | 10 Züge | 0,40 | 7 | [6] | **A** |
| S7 | Sanktionen UN umfassend | −5,0 Pp im 1. Zug, danach ×0,70/Zug; Deckel −18 % Niveau | ~8 Züge | 0,25 | 3 | [7][8][9] | **B** |
| S8 | Sanktionen UN allgemein | −2,9 Pp im 1. Zug, ×0,75/Zug; Deckel −10 % | ~7 Züge | 0,20 | 3 | [7] | **A** |
| S9 | Sanktionen US unilateral / Finanzsanktionen | −0,5…−0,9 Pp/a | 7 Züge | 0,10 | 2 | [7][10] | **A** |
| S10 | Zollrunde (Größenordnung 2018) | −0,04 % Niveau netto (−0,27 % vor Zollertrag) | 1–2 Züge | 0,30 | 3 | [11][12] | **A** |
| S11 | Zollrunde (Größenordnung 2025, effektiv ~15 %) | −0,5 Pp (2025), −0,4 Pp (2026), −0,3 % Niveau dauerhaft | 2 Züge | 0,60 | 4 | [13] | **A** |
| S12 | Bilaterale Entkopplung, Ziel = mittelgroßer offener Block (EU/DE ggü. China) | −0,8 % Niveau langfristig; Spitzenwirkung Jahr 1 bis ~−3 % | 3–5 Züge Anpassung | 0,70 | 5 | [14][15][16] | **A** |
| S13 | Bilaterale Entkopplung, Angreifer | symmetrisch bis leicht höher; kleinerer Block verliert mehr | 3–5 Züge | 0,70 | 5 | [17][18] | **A** |
| S14 | Ost-West-Blockentkopplung, global | −1,9…−6,9 % Welt-BIP; bis −12 % bei voller Techentkopplung; bis −15 % in Einzelregionen | 5–10 Züge | 0,80 | 8 | [19][20][21] | **A** |
| S15 | Friendshoring | bis −4,7 % Niveau (Einzelländer); global −1,8 % | 5 Züge | 0,80 | 6 | [22][23] | **A** |
| S16 | Reshoring (erzwungen) | −4,5 % global; DE −9,7 % | 5 Züge | 0,90 | 8 | [14][23] | **A** |
| S17 | Systemische Bankenkrise | −9,5…−11,5 % Niveau Peak-to-Trough | 2–4 Züge | 0,55 | 7 | [24][25][26] | **A** |
| S18 | Staatsdefault (unbegleitet) | −2,8 % bei Impact, −4,8 % Peak | 3 Züge | 0,35 | 5 | [24] | **A** |
| S19 | Default **+** Bankenkrise | −9,5 % Peak | 3 Züge | 0,55 | 7 | [24] | **A** |
| S20 | Default, 10-Jahres-Sozialbilanz | −8,5 % nach 3 J, −20 % nach 10 J; Armut +10 Pp; Säuglingssterblichkeit +5/1.000 | 10 Züge | 0,55 | 7 | [27] | **A** |
| S21 | Kapitalmarktausschluss nach Default | partiell 5,7 J (Median 3,0), voll 8,4 J (Median 7,0) | – | – | – | [28][29] | **A** |
| S22 | Präferenzkaskade / Regimekrise, gewaltsam | −2,0 Pp | 2 Züge | 0,30 | 3 | [30][31] | **C** |
| S23 | Machtwechsel unblutig / „pro-business" | −0,5 Pp bzw. **+1,0 Pp** | 1 Zug | 0 | 1 | [32] | **B** |
| S24 | Extreme Wirtschaftskatastrophe (Referenzobergrenze) | >26 % Verlust in den ersten Jahren, >20 % noch nach 20 J | 20+ Züge | 0,60 | 15 | [33] | **A** |

---

## 2. Urteil je bestehender Spielregel

**C-4, UN umfassend −5,0 Pp/a über 10 Jahre → ÄNDERN.**
Neuenkirch & Neumeier [7] belegen wörtlich „*Comprehensive UN economic sanctions … trigger a reduction in GDP growth by more than 5 pp*" und „*adverse effects last for a period of 10 years*". Die Spielregel verkettet beides zu einem konstanten Abzug — das ist ein Lesefehler. Der Impulsantwort-Verlauf klingt ab; 5 Pp × 10 Züge ergäbe kumuliert >50 % Trendverlust. **Kein einziger dokumentierter Fall erreicht das:** Iran unter maximalem Druck −17 % (synthetische Kontrolle, [8]) bzw. maximal −19,1 % vier Jahre nach Beginn [9]; Russland 2022 im VAR-Modell −12 % für den Gesamtsanktionsschock [34]. **Neu: −5,0 Pp im ersten Zug, geometrischer Abbau ×0,70 je Zug, kumulativer Niveauverlust gedeckelt bei −18 %.**

**C-4, UN allgemein −2,3…−3,5 Pp/a → ÄNDERN (analog).** Punktschätzer korrekt zitiert (Güte A), Verkettung falsch. **Neu: −2,9 Pp im ersten Zug, ×0,75/Zug, Deckel −10 %.**

**C-4, US unilateral −0,5…−0,9 Pp über 7 Züge → HALTEN.** Exakt so in [7]. Gutmann/Neuenkirch/Neumeier [10] verschieben den Akzent: der Effekt wird *von Finanzsanktionen und US-unilateralen Sanktionen getrieben*. Optional Anhebung auf −0,7…−1,0 Pp, wenn das Sanktionspaket Finanzsanktionen enthält.

**C-4, p = 0,26 Verhaltensänderung → nicht belegt.** In keiner der ausgewerteten Quellen auffindbar. Güte C beibehalten oder aus Hufbauer et al. neu herleiten.

**C-4, Ersatzhandel ab Zug 4, −20 %/Zug, Boden 40 % → ÄNDERN, und zwar VERSCHÄRFEN.** Der Russland-Realfall ist der stärkste Einzelbefund der ganzen Recherche: 2022 −2,1 % (Rosstat, gegenüber Prognosen von −8 bis −10 % [35]), 2023 +4,1 % (aufwärts revidiert von +3,6 %), 2024 +4,3 % (aufwärts revidiert von +4,1 %), 2025 +1,0 % [36][37][38]. Ursachen laut Bruegel [35]: hohe Energiepreise und Rekord-Leistungsbilanzüberschuss; unvollständige Sanktionen (Seeöl-Embargo erst 12/2022, große Schwellenländer nicht beteiligt); Vorbereitung seit 2014 (eigenes Zahlungssystem, Importsubstitution, China-Handel); konservative Geld- und Fiskalpolitik. Hinzu kommt Kriegswirtschaft als Nachfragemotor. **Neu: Ersatzhandel beginnt in Zug 2, −25 %/Zug. Boden differenziert: 35 % Restwirkung für große, rohstoffreiche, blockfähige Ziele (RU, CN); 60 % für kleine oder isolierte Ziele (Iran, Venezuela, Nordkorea).** Gegenanker: Kohl [39] findet nach *Aufhebung* keinen Rebound — Handelsumlenkung ist teilweise irreversibel, was direkt in P einfließt.

**C-7 I1, Handelsabbruch −1,3 / −0,93 / −0,74 Pp Wachstum → ÄNDERN, Einheit falsch.** Die gesamte Decoupling-Literatur rechnet in **Wohlfahrts-/Niveaueffekten**, nicht in Wachstumsabzügen. ifo 2022 [14]: EU-China-Entkopplung kostet Deutschland **−0,8 % BIP als langfristiges Niveau**. Bundesbank Januar 2024 [16]: ein schwerer China-Abschwung kostet −0,7 % im ersten und ~−1 % im zweiten Jahr; für eine *abrupte* Entkopplung verweigert die Bundesbank ausdrücklich eine Zahl. Attinasi et al. [15] liefern das Zeitprofil: **kurzfristige Kosten etwa fünfmal so hoch wie langfristige** (Lohnrigidität, geringe Substituierbarkeit). **Neu: −1,0 % Dauerniveau für die EU als Ziel, mit Spitzenwirkung von bis zu −3 % im ersten Zug, Abbau über 3 Züge. Angreifer symmetrisch; wer der relativ kleinere Block ist, verliert mehr** [17]. Das ergibt im Spiel eine ähnliche Größenordnung wie bisher, aber mit korrektem Wiederanstieg statt permanenter Wachstumsdrossel. **Warnung:** Bonadio et al. [40] finden für die *tatsächliche* Blockbildung 2015–2023 Realeinkommensgewinne von +0,4…+0,6 % im Medianland — beobachtete Entkopplung war bisher nicht kostspielig. Setzt die Verluste nicht ohne Eskalationsschwelle an.

**C-7 I2, Bankenkrise −9,5 Pp über zwei Züge → HALTEN, aber als Niveau lesen.** Die Zahl ist erstaunlich gut getroffen: Kuvshinov & Zimmermann [24] finden für Default mit nachfolgender Bankenkrise einen Peak von **exakt −9,5 % BIP**; Reinhart & Rogoff [25] einen mittleren Peak-to-Trough von −11,5 % über 100 Episoden. **Neu: −9,5 % Niveau, aufgebaut über 2 Züge** (statt −9,5 Pp Wachstum, was kumuliert ~−18 % ergäbe). Güte A.

**C-7 I2, 10 Züge Kapitalmarktausschluss → ÄNDERN auf 3 + 4.** Richmond & Dias [28]: partieller Marktzugang nach 5,7 Jahren (Median 3,0), voller nach 8,4 (Median 7,0); Gelos et al. [29] dokumentieren einen Rückgang von 4 auf 2 Jahre. **Neu: 3 Züge Vollausschluss, danach 4 Züge Teilzugang mit Risikoaufschlag.** Verlängerung um +2 Züge bei hohem Haircut (Cruces & Trebesch [41]: höhere Haircuts → signifikant längerer Ausschluss und höhere Spreads).

**Präferenzkaskade −2,0 Pp → HALTEN für gewaltsame Regimekrise, Güte auf B heben, aber ausdifferenzieren.** Jong-A-Pin [30]: von vier Instabilitätsdimensionen ist **nur Regime-Instabilität robust negativ**. Aisen & Veiga [31]: Wirkung überwiegend über Produktivitätswachstum. Incerti & Lupu [32]: Rücktritte +4 % Marktrendite, Attentate −2 %, Coups −2 %, *pro-business* Coup **+10 %**. **Neu: −2,0 Pp gewaltsame Regimekrise; −0,5 Pp unblutiger Machtwechsel; +1,0 Pp marktfreundlicher Umsturz.**

---

## 3. Erholungsregel (Vorschlag)

**Prinzip:** Kein Schock erzeugt einen Wachstumsabzug „für immer". Jeder Schock erzeugt eine **Niveaulücke** G gegenüber dem Basispfad. Ein Anteil P dieser Lücke ist dauerhaft (Hysterese), der Rest schließt sich geometrisch. Das Schließen der Lücke erscheint im Spiel automatisch als Wachstum **über** Basistrend — der Phönix-Effekt entsteht mechanisch, ohne Sonderregel.

**Formel (je Schock separat mitführen, dann addieren):**

```
G_t = G_max · [ P + (1 − P) · 2^(−(t − T_ende)/H) ]

Δg_t = G_{t−1} − G_t          (Wachstumsaufschlag im Zug t, in Pp)
```

- `G_max` = maximale Niveaulücke des Schocks (Tabellenspalte 1)
- `T_ende` = Zug, in dem die Schockursache endet (Sanktionsaufhebung, Waffenstillstand, Bankenrekapitalisierung)
- `P` = dauerhafter Anteil, `H` = Halbwertszeit in Zügen

**Vier Zusatzregeln:**

1. **Asymmetrie.** Fernández-Villaverde et al. [42] zeigen: Fragmentierung schadet *sofort*, Entfragmentierung wirkt nur *allmählich*. Im Spiel: Schaden zu 100 % im Auslösezug, Erholung erst ab `T_ende` und nur mit H.
2. **Aufholdeckel.** `Δg_t ≤ 3,0 Pp/Zug`. Verhindert absurdes Rekonstruktionswachstum bei großem G_max.
3. **Phönix-Modifikator (Entwicklungsstand).** Kugler et al. [43]: hochentwickelte Kriegsteilnehmer erholen sich „wie ein Phönix" binnen einer Generation; weniger entwickelte nur teilweise; die ärmsten fallen in eine Armutsfalle. → **P für Kriegsschocks: 0,20 (hochentwickelt), 0,45 (mittel), 0,70 (arm/fragil).** Cook [44] misst nach WWII-Zerstörung Konvergenzraten von 4–6 %/a — das entspricht H ≈ 12–17 und rechtfertigt für den Kapitalstock-Anteil eine **Halbierung von H in den ersten 3 Nachkriegszügen** (Rekonstruktionsboom [45][46]).
4. **Friedensbedingung.** Chen, Loayza & Reynal-Querol [47]: Erholung tritt ein, *wenn das Kriegsende dauerhaften Frieden markiert*. Bricht der Krieg innerhalb von 3 Zügen wieder aus, wird die Erholung annulliert und G auf G_max zurückgesetzt.

**Parametertafel:**

| Schocktyp | P | H (Züge) | Beleg |
|---|---|---|---|
| Sanktionen, umfassend | 0,25 | 3 | [9][48] |
| Sanktionen, begrenzt/unilateral | 0,10 | 2 | [48] |
| Handelsumlenkung (Sonderposten) | 0,60 | 6 | [39] |
| Zölle/Handelskrieg | 0,50 | 4 | [13] |
| Bilaterale Entkopplung | 0,70 | 5 | [14][15][42] |
| Blockentkopplung global | 0,80 | 8 | [19][42] |
| Bankenkrise | 0,55 | 7 | [25][49][50] |
| Staatsdefault | 0,35–0,55 | 5–7 | [24][27] |
| Krieg, eigenes Territorium | 0,20/0,45/0,70 | 8 (erste 3 Züge: 4) | [1][43][44] |
| Krieg, Nachbar | 0,15 | 3 | [1][3] |
| Bürgerkrieg | 0,50 | 6 | [4][5] |
| Regimekrise | 0,30 | 3 | [30] |

**Kalibrierprobe:** Bankenkrise, G_max = 9,5 %, P = 0,55, H = 7. Nach 7 Zügen: G = 9,5·(0,55+0,225) = 7,4 %; das Vorkrisen-*Niveau* wird nie erreicht, aber der Vorkrisen-*Pfad* wird nach ~7–8 Zügen wieder parallel — deckungsgleich mit Reinhart & Rogoff (8 Jahre, Median 6,5) [25] und mit Cerra & Saxena (keine volle Erholung) [50]. Die Regel reproduziert beide scheinbar widersprüchlichen Befunde gleichzeitig.

---

## 4. Quellenregister

| # | Titel / Autoren / Jahr / Ort | URL / DOI | Güte |
|---|---|---|---|
| 1 | *The Price of War*. Federle, Meier, Müller, Mutschler, Schularick 2024, Kiel Working Paper 2262 | https://www.kielinstitut.de/fileadmin/Dateiverwaltung/IfW-Publications/fis-import/e9d6bb6c-ad4b-4aa0-954d-e0fc995cb0ee-KWP2262_The_Price_of_War.pdf | A |
| 2 | *The Price of War*. Federle et al. 2026, American Economic Review | https://consensus.app/papers/details/c627eb2a8a0b5b8aabf661ecb657c33f/?utm_source=claude_desktop · DOI 10.1257/aer.20241355 | A |
| 3 | *The External Costs of War*. Federle et al. 2023, SSRN | https://consensus.app/papers/details/fb2749eb50885cd599cc25bc096ca245/?utm_source=claude_desktop · DOI 10.2139/ssrn.4559293 | A |
| 4 | *The economic costs of civil war*. Costalli, Moretti, Pischedda 2017, J. Peace Research | https://consensus.app/papers/details/8ca1254127205abcb93831acf3e64718/?utm_source=claude_desktop · DOI 10.1177/0022343316675200 | A |
| 5 | *Growth Dynamics: The Myth of Economic Recovery: Comment*. Mueller 2012, AER | https://consensus.app/papers/details/eb3d2d81521d510591f0a6297bb28018/?utm_source=claude_desktop · DOI 10.1257/aer.102.7.3774 | A |
| 6 | *The macroeconomic costs of conflict*. Novta, Pugacheva 2020, J. Macroeconomics | https://consensus.app/papers/details/4c17e8e8447b5937b51776902e51f45a/?utm_source=claude_desktop · DOI 10.5089/9781513547756.001 | A |
| 7 | *The Impact of UN and US Economic Sanctions on GDP Growth*. Neuenkirch, Neumeier 2015, EJPE | https://consensus.app/papers/details/c4bc2f056eea558c88904cca270c8959/?utm_source=claude_desktop · DOI 10.1016/j.ejpoleco.2015.09.001 | A |
| 8 | *An estimation of the economic cost of recent sanctions on Iran…*. Gharehgozli 2017, Economics Letters | https://consensus.app/papers/details/73f685e98029514980a8e1e494dcbcca/?utm_source=claude_desktop · DOI 10.1016/j.econlet.2017.06.008 | A |
| 9 | *Who is afraid of sanctions?* Ghomi 2021, Economics & Politics | https://consensus.app/papers/details/9dad7e2b61db519a8fcc5d89bbf43cb1/?utm_source=claude_desktop · DOI 10.1111/ecpo.12203 | A |
| 10 | *The Economic Effects of International Sanctions: An Event Study*. Gutmann, Neuenkirch, Neumeier 2023, J. Comparative Economics | https://consensus.app/papers/details/e1a23dae309852c68bbc0f682338f18b/?utm_source=claude_desktop · DOI 10.2139/ssrn.3821520 | A (Punktschätzer nicht belegt) |
| 11 | *The Return to Protectionism*. Fajgelbaum, Goldberg, Kennedy, Khandelwal 2019/2020, QJE | https://consensus.app/papers/details/60a52c423b4b5283bbee7067ca5f0466/?utm_source=claude_desktop · DOI 10.1093/qje/qjz036 | A |
| 12 | *The Impact of the 2018 Tariffs on Prices and Welfare*. Amiti, Redding, Weinstein 2019, JEP | https://consensus.app/papers/details/d93adc13fe935be6a2775f1a49e47adc/?utm_source=claude_desktop · DOI 10.1257/jep.33.4.187 | A |
| 13 | *State of U.S. Tariffs: November 17, 2025*. Yale Budget Lab | https://budgetlab.yale.edu/research/state-us-tariffs-november-17-2025 | A |
| 14 | *Langfristige Effekte von Deglobalisierung und Handelskriegen auf die deutsche Wirtschaft*. Dorn, Flach, Fuest, Scheckenhofer 2022, ifo Schnelldienst 75(9) | https://www.ifo.de/DocDL/sd-2022-09-dorn-etal-effekte-deglobalisierung.pdf | A |
| 15 | *The Economic Costs of Supply Chain Decoupling*. Attinasi et al. 2024 | https://consensus.app/papers/details/edf363a305ee586a80e85dfbd859d2ce/?utm_source=claude_desktop · DOI 10.2139/ssrn.4532103 | A |
| 16 | *Risiken für Deutschland aus der wirtschaftlichen Verflechtung mit China*. Bundesbank, Monatsbericht Januar 2024 | https://publikationen.bundesbank.de/publikationen-de/berichte-studien/monatsberichte/monatsbericht-januar-2024-922000?article=risiken-fuer-deutschland-aus-der-wirtschaftlichen-verflechtung-mit-china-922002 | A |
| 17 | *Cutting through the value chain…*. Felbermayr, Mahlkow, Sandkamp 2023, Empirica | https://consensus.app/papers/details/5bd1f7bc75fb503b9b07f4949a4b0d14/?utm_source=claude_desktop · DOI 10.1007/s10663-022-09561-w | A |
| 18 | *Trade decoupling from Russia*. Borin et al. 2023, International Economics | https://consensus.app/papers/details/08eb434538775a4381c097d1bc55f174/?utm_source=claude_desktop · DOI 10.1016/j.inteco.2023.05.001 | A |
| 19 | *Geo-Economic Fragmentation and the Future of Multilateralism*. Aiyar et al. 2023, IMF SDN/2023/001 | https://www.imf.org/-/media/files/publications/sdn/2023/english/sdnea2023001.pdf | A |
| 20 | *The Impact of Geopolitical Conflicts on Trade, Growth, and Innovation*. Góes, Bekkers 2022, WTO WP | https://consensus.app/papers/details/38e2eb60a5b05d91a1a1b68abd7c3306/?utm_source=claude_desktop · DOI 10.30875/25189808-2022-9 | A |
| 21 | *Fragmentation in Global Trade: Accounting for Commodities*. Bolhuis, Chen, Kett 2023, IMF WP 2023/073 | https://www.imf.org/en/publications/wp/issues/2023/03/24/fragmentation-in-global-trade-accounting-for-commodities-531327 | A |
| 22 | *Economic Costs of Friend-Shoring*. Javorcik et al. 2024 | https://consensus.app/papers/details/708c5ed35005551dbe978146d1611448/?utm_source=claude_desktop · DOI 10.2139/ssrn.4696010 | A |
| 23 | *The Price of De-Risking: Reshoring, Friend-Shoring, and Quality Downgrading*. Cerdeiro 2024, IMF WP | https://consensus.app/papers/details/050d4c01ce9b57afb9222e18b495378f/?utm_source=claude_desktop · DOI 10.5089/9798400269646.001 | A |
| 24 | *Sovereigns going bust: Estimating the cost of default*. Kuvshinov, Zimmermann 2019, EER | https://consensus.app/papers/details/f1e15214f67a5980a6ac3274824dbd0c/?utm_source=claude_desktop · DOI 10.1016/j.euroecorev.2019.04.009 | A |
| 25 | *Recovery from Financial Crises: Evidence from 100 Episodes*. Reinhart, Rogoff 2014, NBER WP 19823 / AER P&P | https://www.nber.org/system/files/working_papers/w19823/w19823.pdf | A |
| 26 | *Systemic Banking Crises Database II*. Laeven, Valencia 2020, IMF Economic Review | https://consensus.app/papers/details/7af4e4b756ac5dbcb7a2a2a20c7c3fe8/?utm_source=claude_desktop · DOI 10.1057/s41308-020-00107-3 | A (23-%-Wert nicht belegt) |
| 27 | *The Social Costs of Sovereign Default*. Farah-Yacoub, Graf von Luckner, Reinhart 2022/2024, WB PRWP 10157 / NBER w32600 | https://www.nber.org/digest/202408/costs-sovereign-debt-crises · DOI 10.1596/1813-9450-10157 | A |
| 28 | *Duration of Capital Market Exclusion*. Richmond, Dias 2009 | https://consensus.app/papers/details/2b7c822b1506513cb0e7bf17ab7900e6/?utm_source=claude_desktop · DOI 10.2139/ssrn.1027844 | A |
| 29 | *Sovereign Borrowing by Developing Countries: What Determines Market Access?* Gelos et al. 2011, JIE | https://consensus.app/papers/details/150a306d2dd1580eb2aeeae7b6314ad3/?utm_source=claude_desktop · DOI 10.1016/j.jinteco.2010.11.007 | A |
| 30 | *On the measurement of political instability…*. Jong-A-Pin 2009, EJPE | https://consensus.app/papers/details/2042c92aaec354468bd61998fc4610f6/?utm_source=claude_desktop · DOI 10.1016/j.ejpoleco.2008.09.010 | A |
| 31 | *How Does Political Instability Affect Economic Growth?* Aisen, Veiga 2010/2013 | https://consensus.app/papers/details/7ced5aa201e056e8b58b1ea3cdc7b294/?utm_source=claude_desktop · DOI 10.1016/j.ejpoleco.2012.11.001 | A |
| 32 | *Are regime changes always bad economics?* Incerti, Lupu 2024, Business and Politics | https://consensus.app/papers/details/1a8803457ab8533d9a65ae50d671d259/?utm_source=claude_desktop · DOI 10.1017/bap.2024.7 | A |
| 33 | *Recovery from economic disasters*. Ćorić et al. 2023, Macroeconomic Dynamics | https://consensus.app/papers/details/c22b6e3ad73f567a8fe88beb91e0bad5/?utm_source=claude_desktop · DOI 10.1017/s1365100523000366 | A |
| 34 | *The Price of War: Macroeconomic and Cross-sectional Effects of Sanctions on Russia*. Mamonov et al. 2022 | https://consensus.app/papers/details/436daf90a15f5c79a97ef58aa8b4f98c/?utm_source=claude_desktop · DOI 10.2139/ssrn.4190655 | A |
| 35 | *The Russian war economy: macroeconomic performance*. Bruegel, 20.7.2023 | https://www.bruegel.org/analysis/russian-war-economy-macroeconomic-performance | A |
| 36 | *Russian GDP grows 4.1% in 2024, as in 2023 — Rosstat*. Interfax | https://interfax.com/newsroom/top-stories/109666/ | A |
| 37 | *Russia raises 2024 GDP growth figure to 4.3 %* (Rosstat-Revision 11.4.2025) | https://uk.finance.yahoo.com/news/russia-raises-2024-gdp-growth-170404836.html | A |
| 38 | *Russian economy lost steam in 2025* — BIP 2025 +1 % (Rosstat vorläufig). BOFIT Weekly 2026/07 | https://www.bofit.fi/en/monitoring/weekly/2026/vw202607_1/ | A |
| 39 | *In and out of the penalty box: U.S. sanctions and their effects on international trade*. Kohl 2021 | https://consensus.app/papers/details/8863fff6d4745b13bfa1510ffa803318/?utm_source=claude_desktop · DOI 10.4337/9781839102721.00030 | A |
| 40 | *Playing with Blocs: Quantifying Decoupling*. Bonadio et al. 2025, NBER w34302 | https://consensus.app/papers/details/c2b601f526315f0697cadc2878912e1b/?utm_source=claude_desktop · DOI 10.3386/w34302 | A |
| 41 | *Sovereign Defaults: The Price of Haircuts*. Cruces, Trebesch 2011/2013 | https://consensus.app/papers/details/a581f57ece9a5ce0bbd8a22a45106d93/?utm_source=claude_desktop · DOI 10.1257/mac.5.3.85 | A |
| 42 | *Are We Fragmented Yet?* Fernández-Villaverde et al. 2024, NBER w32638 | https://consensus.app/papers/details/a0b6ca34b9ed5296b86dc0f50de48ac8/?utm_source=claude_desktop · DOI 10.3386/w32638 | A |
| 43 | *Demographic and Economic Consequences of Conflict*. Kugler et al. 2013, ISQ (Phönix-Faktor, Organski/Kugler-Tradition) | https://consensus.app/papers/details/9b00a91b9d7d5edbb5b85b1dc7207310/?utm_source=claude_desktop · DOI 10.1111/isqu.12002 | A |
| 44 | *World War II and Convergence*. Cook 2002, REStat | https://consensus.app/papers/details/f232f026a8a65de69b9dd6ae4e5d346e/?utm_source=claude_desktop · DOI 10.1162/003465302317331964 | A |
| 45 | *Post-War Growth, Productivity Convergence and Reconstruction*. Smolny 2000, OBES | https://consensus.app/papers/details/7d410e86e176551c959f99b00526ff8d/?utm_source=claude_desktop · DOI 10.1111/1468-0084.00191 | A |
| 46 | *Post-war reconstruction and the Golden Age of economic growth*. Vonyó 2008, EREH | https://consensus.app/papers/details/d0d5be9c47ff5ed0b4425a2c3117e0db/?utm_source=claude_desktop · DOI 10.1017/s1361491608002244 | A |
| 47 | *The Aftermath of Civil War*. Chen, Loayza, Reynal-Querol 2007, World Bank Economic Review | https://consensus.app/papers/details/9f45c75380315b878b03bd65a4b3a349/?utm_source=claude_desktop · DOI 10.1093/wber/lhn001 | A |
| 48 | *Economic sanctions and output growth: Empirical evidence*. Petrevski 2026, Int. Econ. and Econ. Policy | https://consensus.app/papers/details/48a56b16b4ed54bd8883bfdb70dbdb9a/?utm_source=claude_desktop · DOI 10.1007/s10368-026-00782-z | A |
| 49 | *Is Economic Recovery a Myth?* Teulings, Zubanov 2014 | https://consensus.app/papers/details/d8df1fc832df53a59e631838e6204985/?utm_source=claude_desktop · DOI 10.1002/jae.2333 | A |
| 50 | *Growth Dynamics: The Myth of Economic Recovery*. Cerra, Saxena 2008, AER | https://consensus.app/papers/details/a7ce8ba5dc095853b3c7a8466eafe43d/?utm_source=claude_desktop · DOI 10.2139/ssrn.1013572 | A |
| 51 | *Collateral Damage: Trade Disruption and the Economic Impact of War*. Glick, Taylor 2010, REStat | https://consensus.app/papers/details/c4b6f5383b1f5ef4ab00c3281ebbb3a9/?utm_source=claude_desktop · DOI 10.1162/rest.2009.12023 | A |
| 52 | *Tariff Pass-Through at the Border and at the Store*. Cavallo, Gopinath, Neiman, Tang 2019/2021, AER: Insights | https://consensus.app/papers/details/ebca7069ac0559e687d5e6bf9a7e28ad/?utm_source=claude_desktop · DOI 10.3386/w26396 | A |
| 53 | *World Economic Outlook, October 2025*, Kap. 1, IMF | https://www.imf.org/-/media/files/publications/weo/2025/october/english/ch1.pdf | A |
| 54 | *Accounting for the business cycle reduces the estimated losses from systemic banking crises*. Luginbuhl, Koopman 2019, Empirical Economics | https://consensus.app/papers/details/d5f762bd84dc550f959ff47b493a74dd/?utm_source=claude_desktop · DOI 10.1007/s10181-018-1424-9 | A |

**Nicht belegt:** ifo-Wert „Taiwan-Krieg −1,4 %" (im ifo-Schnelldienst 9/2022 nicht quantifiziert); Cerra/Saxena „−7,5 %" für Finanzkrisen (Originalabstract nennt keine Punktzahl; abweichende Rekonstruktionen: 6 % bzw. 4 % konjunkturbereinigt [54], ~10 % [49]); Laeven/Valencia „23 % kumuliert"; Sanktions-Erfolgswahrscheinlichkeit p = 0,26; Penn-Wharton-Zollschätzung 2025; russisches BIP 2022 = −1,2 % (dokumentiert ist die Rosstat-Erstschätzung −2,1 % vom Februar 2023 sowie spätere Aufwärtsrevisionen für 2023/24 — die konkrete Revision auf −1,2 % konnte ich nicht primärbelegen).

---

## 5. Consensus-Hinweis

Die Consensus-Ergebnisse enthielten **keine** Sign-up-, Upgrade- oder Nutzungsmeldung. Jedes Suchergebnis endete ausschließlich mit dem folgenden, wörtlich wiedergegebenen Zitierhinweis:

> „IMPORTANT INSTRUCTIONS: When discussing these findings, you MUST cite papers inline using their numbered references, e.g. [1], [2]. Example: 'Caffeine improves endurance performance [1] and reduces perceived exertion [3].' Hyperlink paper titles directly: [Paper Title](url). Use the exact URLs above — do not modify or shorten them. If a paper line includes `DOI: ...`, treat it as a citation-formal identifier and preserve it when the user asks for citations."

*(16 Consensus-Suchen, 12 WebSearch/WebFetch-Abrufe; keine Rate-Limit-Fehler.)*
