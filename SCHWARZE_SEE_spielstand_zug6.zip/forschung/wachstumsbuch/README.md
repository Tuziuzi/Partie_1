# forschung/wachstumsbuch — Inhalt

| Datei | Was |
|---|---|
| `KB-02_WACHSTUMSBUCH.md` | Hauptbericht: Befund, Regelvorschläge W-1/W-2/W-3/E-1/E-2, Anwendung auf SCHWARZE SEE (§7), Nahtstelle zur Singularität S-01 (§8), Offenes |
| `anhang/A_wachstumspfade_je_block.md` | Agent A — Langfristprojektionen je Block, Demografie, Widersprüche (39 Quellen) |
| `anhang/B_konvergenzformel_hysterese.md` | Agent B — Formelparameter, Hysterese, Phönix, Klima-Niveauentscheid (32) |
| `anhang/C_kopplungen_energie_ki_ruestung.md` | Agent C — Deckungslücke, KI-Diffusion, SAEED-Prüfung, Kriegswirtschaft (50) |
| `anhang/D_energieausbau_hoechstraten.md` | Agent D — Ist-Zubau 2019–25, Höchstraten, Block-Deckel, EH-01-Urteile (42) |
| `anhang/E_beschleunigung_politik.md` | Agent E — Fallstudien, Engpässe, Beschleunigungsleiter (47) |
| `anhang/F_schocks_erholung.md` | Agent F — Schocktafel, Urteile zu C-4/C-7, Erholungsregel (54) |
| `pruefung_w1.py` | Gegenrechnung: Konvergenzformel (W-1b) gegen Tafelpfad (W-1a), 2026–2060 |

Stand 02.09.2026. Nichts davon ist gebucht — Entscheidungsvorlage, siehe Hauptbericht §7.
