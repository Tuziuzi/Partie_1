# BEFUNDLISTE — Skillpflege
## Kampagne SCHWARZE SEE, Aufbau bis Ende Zug 1 (2026)
Stand 16.08.2026 · Belege im Kampagnenjournal `journal.jsonl` und in `work/delta_*.json`

**Achtzehn Befunde.** B-1…B-12 aus dem Aufbau, B-13…B-18 aus Zug 2.
Sieben repariert, fünf umgangen und dokumentiert, sechs offen oder Hinweis.

> **Ein Muster über alle Befunde hinweg:** B-12 und B-18 haben dieselbe Bauform —
> eine Pflichtregel, die nur als Prosa in einem Worksheet steht und die danach kein
> Validator prüft. Beide wurden erst sichtbar, als eine Zahl anderswo komisch aussah.
> Wo eine Regel »muss« sagt, gehört eine Prüfung dazu, sonst ist sie eine Bitte.

---

## Repariert — Code geändert und getestet

### B-1 · `deltav-gm-controller` · Setup bricht hart ab
`gm_core.py:parse_bodenlage` entpackt zwei Rückgabewerte, `bodenlage.kompiliere()`
liefert seit Rev. C aber drei (`aus, unbekannt, herkunft`).
→ `ValueError: too many values to unpack`, **kein Kampagnenaufbau möglich.**
**Fix:** Einzeiler `_erg = mod.kompiliere(bekannt); aus = _erg[0]`.
*Noch nicht als Skillpaket geliefert — der Controller läuft als lokal gepatchte Kopie.*

### B-2 · `deltav-gm-controller` · Kriegswirtschaft-Startlage fehlt
Setup setzt nur `dependsOn`; `economy.kriegswirtschaft` blieb bei allen sechs Fraktionen
auf `rolle: ungebunden / steps_bound: 0`, obwohl `kriegswirtschaft.md` §2.2 Patrone und
Vasallen mit je einem gebundenen Schritt führt.
**Fix:** über das kanonische Werkzeug des deltav-Skills nachgezogen —
`kriegswirtschaft.py startlage --schreiben`. Der Kompilierer kennt die Tafel selbst.

### B-4 · `deltav-game-master` · §9-Startpools nicht gebucht
`industrial.capacity_t_year`, `stockpile_t`, Treibstoff und Verbrauchsgüter standen bei
allen sechs Fraktionen auf **0** — obwohl `economics.md` §9.5 das ausdrücklich als
GM-Prüfpunkt führt: *»Kein Startpool ohne Eintrag in launch_c2.md Tabelle 1.«*
Ohne Fix hätte niemand irgendetwas bauen können.
**Fix:** Tabelle §9.2 wörtlich nachgebucht (USA 200 t/a, CHN 40, RUS 10, EU 5, IND 4).

### B-5 · `werkbuch-bauzeiten` ↔ `deltav-game-master` · Resolver-Hook nicht implementiert
`regeln.md` §10 beschreibt einen Hook (»resolve_round.py … bucht Fertigstellungen im
Phase-7-Jahresabschluss, erhöht Serienzähler«), den es in `resolve_round.py` nicht gab.
Suche nach `bz01`, `bauplan`, `serienzaehler`: kein Treffer.
**Fix:** implementiert — Bauphase rechnet je strukturiertem Auftrag genau einen
`bz01_calc.py`-Aufruf, neue Phase `bz01_abschluss`, `finalize` bucht Statusflip,
Serienzähler und Ramp; `set_path` kann jetzt an Listen anhängen. Selftest um neun
BZ-01-Prüfungen erweitert. **Als Skillpaket geliefert.**

### B-12 · `erde01-gm` · Postfach-Lücke — Vergessen war unsichtbar
`resolve()` liefert nur den **Ablaufplan** und erzwingt nichts. In Zug 1 blieben fünf von
sieben Domänen unaufgelöst im Postfach liegen; der Validator meldete trotzdem BESTANDEN.
**Fix:** neue Validatorprüfung **V12 »Postfach-Vollständigkeit«** (Zug fällt durch,
solange eine Order weder aufgelöst noch mit Befund zurückgewiesen ist), `resolve` druckt
die Checkliste vorab, `blattlesen.py` setzt die Marke `"aufgeloest": false`,
Betriebsregel 5 verlangt die Domänen-Checkliste in jedem SITREP.
**Als Skillpaket geliefert.**

---

## Umgangen und dokumentiert — Skript unverändert

### B-6 · `erde01-gm` · `eh01.py` bricht mit `KeyError: 'zeit'`
Der Fallback für die Ära-Zugdauer greift auf `REGELN["zeit"]["aeren"][0]["zugdauer_a"]`
zu. Den Key `zeit` gibt es in `erde01_regeln.json` nicht (Top-Keys: modul, version, norm,
namensraum, hinweis, kampagne, anker, alternativregeln_aktiv, wirtschaft, innenpolitik,
intel, militaer, forschung, klima, endzustaende, oekosystem).
**Umgehung:** `--jahre=1` mitgeben und `daten.zugdauer_a = 1` setzen (Ära I, kanonisch).
**Fixvorschlag:** Fallback auf `assets/eh01_energiehunger.json` oder die Uhr im State.

### B-7 · `deltav-gm-controller` · `p_pl_W` wird beim Setup nicht angelegt
Setup bucht unter `truth.ressourcen` nur `q_raum` (C-9). `eh01.py spiel zug` erwartet
zusätzlich das Konto `p_pl_W` und bricht sonst ab.
**Umgehung:** Konto aus `staaten_2026.json` nachgebucht (`anteil_p_pl × _p_welt_W`).
**Fixvorschlag:** in den Setup-Schritt aufnehmen — die Quelle liegt ohnehin schon vor.

### B-10 · `implosion-wirtschaftswaffe` · `c7.py ip` addiert Fire-Sale unbedingt
Es gibt keinen Schalter, um eine reine I1-Zündung zu rechnen. Rohausgabe für Chinas
Exportverbot: `I1=1.42 I2=1.0 (… FireSale 1.0) … IP=2.42`. Nach `implosion_regeln.md` §2
gilt aber *»Nur gezündete Stufen zählen«* → **IP = 1,42**.
Der Unterschied ist nicht kosmetisch: bei 2,42 wird ein globaler Kaskadenwurf fällig
(p ≈ 3 %), bei 1,42 greift §3 *»Bei IP < 2 findet kein Wurf statt«*.
**Fixvorschlag:** Flags `--i1/--i2/--i3` oder `--stufen I1`.

### B-11 · `erde01-gm` · `sanktion` kennt die Einzelsanktion nicht
Die CLI kennt nur `un_allgemein`, `un_umfassend`, `us_unilateral`. Die Konstante
`wirtschaft.sanktionen.einzelsanktion_niveau_pct = -0.39` steht im Asset, ist aber nicht
abrufbar. Für Romans Huawei-Ausschluss direkt aus dem Asset angewandt.
**Fixvorschlag:** vierten Typ in `sanktion()` ergänzen.

---

## Offen — inhaltliche Lücken, kein Code-Fix möglich

### B-9 · `erde01-gm` · Die Ereignistafel hat keine Tafel
`ereignisse.md` §Ereignistafel enthält nur: *»2W10, Ökosystem-Konvention. Klimaereignisse
aus G-1/G-2, Konflikt aus E-2, Technologie aus dem APOTHEOSE-Filter.«* — und **keine
einzige Ergebniszeile**. Der Zug-1-Wurf fiel auf 2 (1+1) und hatte keine Auflösung.
Solange die Tafel fehlt, ist jede Runde ereignislos.
Im selben Abschnitt steht offen: *»Pandemie-Basisraten fehlen — offener Punkt O-14.«*

### B-3 · `deltav-gm-controller` · IND-Vasallenstatus nicht verdrahtet
`kriegswirtschaft.md` §2.2 und `kriegswirtschaft.py:PATRON_VON` führen `IND: CHN`;
das Setup-Skript verdrahtet nur EU→USA und RUS→CHN. Als REGELLÜCKE gemeldet und per
Spielerentscheid kanontreu aufgelöst (Hausentscheidung 1).
**Fixvorschlag:** `PATRON_VON` aus dem deltav-Skript importieren statt zwei Fälle fest zu
verdrahten.

### B-8 · `deltav-game-master` · REST scheitert am Validator
`wn02_validator.py` verlangt für **jede** Fraktion `omega.p_raum_watt > 0`. Für einen
Sammelblock wie REST führt `leistungsbuch.md` §6.1 keine Zeile — das Setup buchte
korrekt 0, und `finalize` lehnte die ganze Runde ab (»muss Zahl > 0 sein, ist 0«).
Aufgelöst durch Aggregation der übrigen §6.1-Zeilen (2,8261·10⁶ W).
**Fixvorschlag:** entweder Sammelblöcke im Validator zulassen, oder eine REST-Zeile in
§6.1 aufnehmen. Dasselbe Muster trifft `launch_c2.md` Tab. 1/2 und die BL-01-Tafel —
REST fällt dort überall durchs Raster (dokumentiert im Setup-Delta).

---

## Nicht Befund, sondern Konvention

Im Setup-Delta stehen vier weitere Notizen, die **so gewollt** sind und hier nur der
Vollständigkeit halber auftauchen: IND und REST haben kein Kanon-Template in
`diplomacy.md` und behalten die Vorlage `euLike`; REST hat keine Zeile in
`launch_c2.md` Tab. 1, in `leistungsbuch.md` §6.1 und in der BL-01-Tafel und startet dort
dokumentiert bei 0 beziehungsweise mit dem Template-Rückfall.

---

## Übersicht

| Nr. | Skill | Befund | Status |
|---|---|---|---|
| B-1 | deltav-gm-controller | BL-01-Entpackfehler, Setup bricht ab | repariert (lokal) |
| B-2 | deltav-gm-controller | Kriegswirtschaft-Startlage fehlt | repariert |
| B-3 | deltav-gm-controller | IND-Vasallenstatus nicht verdrahtet | offen |
| B-4 | deltav-game-master | §9-Startpools nicht gebucht | repariert |
| B-5 | werkbuch ↔ deltav | BZ-01-Resolver-Hook fehlt | **repariert, Paket geliefert** |
| B-6 | erde01-gm | `eh01.py` KeyError `REGELN["zeit"]` | umgangen |
| B-7 | deltav-gm-controller | `p_pl_W` beim Setup nicht angelegt | umgangen |
| B-8 | deltav-game-master | REST scheitert am ω-Validator | offen |
| B-9 | erde01-gm | Ereignistafel ohne Ergebniszeilen | **offen, inhaltlich** |
| B-10 | implosion-wirtschaftswaffe | `c7.py ip` erzwingt Fire-Sale | umgangen |
| B-11 | erde01-gm | `sanktion` kennt Einzelsanktion nicht | umgangen |
| B-12 | erde01-gm | Postfach-Lücke, Vergessen unsichtbar | **repariert, Paket geliefert** |
| B-13 | zeughaus-gm | `zh01_patch.py` scheitert lautlos (Vorgabe `--basis`) | offen, Fixvorschlag |
| B-14 | denkwerk + forschungswerk | Pflichtentscheidung ohne Blattfeld | umgangen (Blatt 4) |
| B-15 | forschungswerk-fue | Zug 1 ohne Spionagetafel aufgelöst | dokumentiert |
| B-16 | deltav (BZ-01 × launch_c2) | Startkapazität für einen Start in drei Jahren gebunden | **offen, Entscheidung** |
| B-17 | deltav (BZ-01) | Werftdurchsatz ist fast nie der Engpass — Stückzeit bindet | Hinweis |
| B-18 | deltav-game-master | Jahresend-Abrechnung ohne Prüfung in der Werkzeugkette | **repariert, Paket geliefert** |

**Ein Muster fällt auf:** sieben der zwölf Befunde hängen am Setup und an Sammelblöcken —
REST allein taucht in vier davon auf. Wer die Kampagne mit den vier »typ: spieler«-Staaten
aufsetzt, trifft die meisten davon nie.
