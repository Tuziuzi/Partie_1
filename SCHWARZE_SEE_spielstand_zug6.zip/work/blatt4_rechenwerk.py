#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HAUSFORMULAR — BEFEHLSBLATT · BLATT 4 »RECHENWERK & FORSCHUNG«

KEIN KANONBLATT. Behelf zu Befund B-14: DW-01 verlangt die Zuteilung
T/F/O/Z/D »vor der Handlungsphase, verbindlich fuer die ganze Runde«
(SKILL.md Rundenablauf Schritt 3), und FO-01 verlangt, dass der Einsatz
VOR dem Wurf feststeht (Regeltreue Ziffer 3) — fuer beides gibt es auf
keinem der drei Kanonblaetter ein Feld. Diese Seite sammelt genau diese
Entscheidungen ein, mehr nicht.

Stil, Rahmen, Regler, Combos und Schriftfeld kommen per Import aus
erde01-gm:scripts/befehlsblatt.py — Einzelquelle statt Kopie, wie es
zh01_blatt.py fuer Blatt 3 auch haelt.

Feldnamen: <praefix>_d_*  (Denkwerk / DW-01)
           <praefix>_f_*  (Forschungswerk / FO-01)
"""
import argparse
import importlib.util
import json
import os
import sys

ERDE01 = "/root/.claude/skills/synced/erde01-gm"


def lade_befehlsblatt(pfad=None):
    p = os.path.join(pfad or ERDE01, "scripts", "befehlsblatt.py")
    if not os.path.exists(p):
        sys.exit(f"ABBRUCH: {p} fehlt. Ohne ERDE-01 kein Blatt — "
                 "eine abweichende Kopie waere schlimmer als kein Blatt.")
    spec = importlib.util.spec_from_file_location("erde01_befehlsblatt", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    from reportlab.lib.colors import white as _w
    m.white = _w
    m._pfad = p
    return m


# Rueckfall, wenn KEIN Spielstand uebergeben wird: die DW-01-Startlage 2026.
# BEFUND B-23: bis 01.09.2026 war das die EINZIGE Quelle. Das Blatt druckte
# Chinas Bestand in jedem Zug als 20 RP und die Prueferstufe immer als P0 —
# egal was im Spielstand stand (China war seit Zug 3 auf P3). Seitdem liest
# stand_aus_spielstand() den Kopf aus gamestate.json; die Tafel hier greift
# nur noch fuer das Blankoblatt.
BESTAND_2026 = {"USA": 55, "CHN": 20, "REST": 13, "EU": 8, "IND": 3, "RUS": 1}


def stand_aus_spielstand(pfad, fraktion):
    """Rechenbestand, Prueferstufe und Weltbestand aus dem Spielstand.

    Rueckgabe (bestand, pruefer, welt); jedes Feld None, wenn der Spielstand
    es nicht hergibt — VORGABE ist Befund, nie Schaetzung (Z-8.3)."""
    if not pfad or not fraktion:
        return None, None, None
    try:
        with open(pfad, encoding="utf-8") as fh:
            gs = json.load(fh)
    except (OSError, ValueError):
        return None, None, None
    fak = gs.get("factions") or {}
    cc = (fak.get(fraktion) or {}).get("computeConfig") or {}
    welt = sum((f.get("computeConfig") or {}).get("stock_rp") or 0
               for f in fak.values()) or None
    return cc.get("stock_rp"), (cc.get("daten") or {}).get("pruefer"), welt


def rechenblatt(c, B, fraktion=None, zug=None, pre="bf",
                bestand=None, pruefer=None, welt=None):
    mm = B.mm
    W, H = B.W, B.H
    B.doppelrahmen(c)
    B.kopfzeile(c, "BEFEHLSBLATT · BLATT 4",
                "RECHENWERK & FORSCHUNG · DW-01 / FO-01 · HAUSFORMULAR (kein Kanonblatt)")

    y = H - 40*mm
    B.hinweis(c, 16*mm, y+3.0*mm,
              "Zwei Entscheidungen, die die Regeln JEDE Runde verlangen und fuer die es bisher kein Feld gab (Befund B-14).",
              B.BLUE, 6.6)
    B.hinweis(c, 16*mm, y-0.4*mm,
              "Beide gelten fuer die ganze Runde und stehen VOR der Handlungsphase fest. Nachtraegliches Aufstocken ist ausgeschlossen (FO-01 Ziffer 3).",
              B.FAINT, 6.2)

    # ---------------- 19 KOPF ----------------
    y = B.abschnitt(c, y - 8*mm, "19", "KOPF")
    bez = ["Fraktion", "Zug", "Rechenbestand RP (laut SITREP)"]
    xs = [18*mm, 78*mm, 108*mm]
    brs = [56*mm, 26*mm, 70*mm]
    for x, br, t in zip(xs, brs, bez):
        c.setFont("DJ", 5.6); c.setFillColor(B.FAINT)
        c.drawString(x, y + 6.2*mm, t)
    B.feld(c, f"{pre}_d_fraktion", xs[0], y, brs[0],
           wert=(fraktion or ""), tip="Fraktion")
    B.feld(c, f"{pre}_d_zug", xs[1], y, brs[1],
           wert=(str(zug) if zug else ""), tip="Zug")
    if bestand is None and fraktion:
        bestand = BESTAND_2026.get(fraktion)
    b_txt = ("" if bestand is None
             else (f"{bestand:g}" if isinstance(bestand, (int, float)) else str(bestand)))
    B.feld(c, f"{pre}_d_bestand", xs[2], y, brs[2], wert=b_txt,
           tip="Rechenbestand in RP — VORGABE aus dem Spielstand, nicht abschreiben")
    w_txt = (f"Weltbestand {welt:g} RP (Spielstand)" if welt else "Weltbestand 2026: 100 RP")
    B.hinweis(c, 18*mm, y - 4.2*mm,
              w_txt + ". Nicht zugeteilte RP verfallen nicht, wirken aber auch nicht — "
              "Rechenzeit ist nicht lagerfaehig (DW-01 §2).",
              B.FAINT, 5.8)

    # ---------------- 20 ZUTEILUNG ----------------
    y = B.abschnitt(c, y - 16*mm, "20", "ZUTEILUNG DER RECHENLEISTUNG — fuenf Konten, Summe <= Bestand", B.BLUE)
    konten = [
        ("T", "Training (Grundlagen)", "S-01-Gate, Compute-Wand, X-Risk. Ohne T kein Jahreswurf."),
        ("F", "Forschung und Anwendung", ">=1 % Weltanteil: -10 % Zeit  ·  >=3 %: -20 %  ·  >=8 %: -30 % (Deckel)"),
        ("O", "Operation", "0,02 RP je gebundenem C2-Slot. d>=2,0: Slotkosten -1 Stufe. d<1: -1 Initiative je 2 Slots."),
        ("Z", "Zivil / Durchdringung", "BIP-Wachstum, Diffusionsast; erntet +0,2 QP/a Betriebsdaten je Stufe."),
        ("D", "Daten (Synthetik + Pruefung)", "Datenfaktor g_D des Trainingslaufs; wirkt NUR ueber einen Pruefer (§9.1)."),
    ]
    for k, name, note in konten:
        c.setFont("DJB", 7.4); c.setFillColor(B.INK)
        c.drawString(18*mm, y + 1.4*mm, k)
        c.setFont("DJ", 7.0); c.setFillColor(B.INK)
        c.drawString(23*mm, y + 1.4*mm, name)
        B.feld(c, f"{pre}_d_konto_{k}", 78*mm, y, 18*mm, ho=4.6*mm, tip=f"Konto {k} in RP")
        B.hinweis(c, 99*mm, y + 1.2*mm, note, B.FAINT, 5.6)
        y -= 7.0*mm
    c.setStrokeColor(B.FAINT); c.setLineWidth(0.4)
    c.line(18*mm, y + 4.4*mm, W - 16*mm, y + 4.4*mm)
    c.setFont("DJB", 7.0); c.setFillColor(B.INK)
    c.drawString(18*mm, y + 0.6*mm, "SUMME")
    B.feld(c, f"{pre}_d_summe", 78*mm, y - 1.0*mm, 18*mm, ho=4.6*mm,
           tip="Summe T+F+O+Z+D, darf den Bestand nicht uebersteigen")
    B.hinweis(c, 99*mm, y + 0.4*mm,
              "Uebersteigt die Summe den Bestand, kommt das Blatt gekuerzt mit Befund zurueck.", B.FAINT, 5.6)

    # ---------------- 21 PRUEFER ----------------
    y = B.abschnitt(c, y - 10*mm, "21", "PRUEFERSTUFE — ohne Pruefer wirkt das D-Konto nicht")
    c.setFont("DJ", 5.6); c.setFillColor(B.FAINT)
    c.drawString(18*mm, y + 6.2*mm, "Pruefer P0-P3 (Unterhalt 0 / 1 / 5 / 20 Mrd USD je Jahr)")
    c.drawString(96*mm, y + 6.2*mm, "Lizenzkauf Datenpunkte (1 Mrd USD je QP)")
    stufen = ["P0", "P1", "P2", "P3"]
    vorwahl = stufen.index(pruefer) if pruefer in stufen else 0
    B.menue(c, f"{pre}_d_pruefer", 18*mm, y, 40*mm, stufen,
            tip="Prueferstufe — VORGABE aus dem Spielstand" if pruefer else
                "Pruefstufe fuer synthetische Daten", vorwahl=vorwahl)
    if pruefer:
        B.hinweis(c, 60*mm, y + 6.2*mm, f"Stand laut Spielstand: {pruefer}", B.OCKER, 5.6)
    B.feld(c, f"{pre}_d_lizenz", 96*mm, y, 40*mm, tip="Lizenzkauf in QP")
    B.hinweis(c, 18*mm, y - 4.2*mm,
              "Ungepruefte Synthetik ist die Versuchung, der Wissenskollaps der Preis (DW-01 §9). P0 heisst: Sie pruefen nicht.",
              B.FAINT, 5.8)

    # ---------------- 22 FORSCHUNG ----------------
    y = B.abschnitt(c, y - 13*mm, "22", "FORSCHUNGSEINSATZ — FO-01, Rate statt Muenzwurf", B.GRUEN)
    B.hinweis(c, 18*mm, y + 6.6*mm,
              "p = 1 - exp(-ln2 x (E/E0)^0,5 x m).  Normeinsatz E = E0 gibt p = 0,500 — genau den alten 1W6>=4. Wer nichts aendert, spielt wie bisher.",
              B.BLUE, 6.0)
    kopf = ["Projekt / Tech", "Stufe", "Einsatz E (x JB)", "Absicht"]
    xs2 = [18*mm, 74*mm, 96*mm, 130*mm]
    brs2 = [54*mm, 20*mm, 32*mm, 48*mm]
    for x, t in zip(xs2, kopf):
        c.setFont("DJ", 5.6); c.setFillColor(B.FAINT)
        c.drawString(x, y + 1.4*mm, t)
    y -= 4.0*mm
    for i in (1, 2, 3):
        B.feld(c, f"{pre}_f_projekt{i}", xs2[0], y, brs2[0], ho=4.6*mm, tip=f"Projekt {i}")
        B.menue(c, f"{pre}_f_stufe{i}", xs2[1], y, brs2[1], ho=4.6*mm,
                optionen=["L1", "L2", "L3", "AG"], tip=f"Techstufe Projekt {i}", vorwahl=0)
        B.feld(c, f"{pre}_f_einsatz{i}", xs2[2], y, brs2[2], ho=4.6*mm,
               tip="Einsatz als Vielfaches des Jahresbudgets, z. B. 0.25")
        B.feld(c, f"{pre}_f_absicht{i}", xs2[3], y, brs2[3], ho=4.6*mm, tip="kurz")
        y -= 6.2*mm
    B.hinweis(c, 18*mm, y + 1.0*mm,
              "E0: L1 0,25 · L2 0,50 · L3 1,00 · AG 2,00 x Jahresbudget. Untereinsatz ist erlaubt: 0,25 E0 gibt p = 0,293 zum Viertelpreis.",
              B.FAINT, 5.8)
    B.hinweis(c, 18*mm, y - 3.0*mm,
              "ZEITFENSTER UNBERUEHRT: L1 ab 2035/2036, L2 ab 2046, L3 ueber S-01 Stufe C oder Jahr >= 2058. Was nicht frei ist, hat keine Rate — auch nicht mit zehnfachem Einsatz.",
              B.FAINT, 5.8)

    # ---------------- 23 OPERATIONEN ----------------
    y = B.abschnitt(c, y - 11*mm, "23", "TECHNOLOGIEBESCHAFFUNG — vier Vektoren, Ertrag ist schwerrandig")
    kopf3 = ["Vektor", "gegen", "Ziel-Tech", "Bemerkung"]
    xs3 = [18*mm, 62*mm, 92*mm, 130*mm]
    brs3 = [42*mm, 28*mm, 36*mm, 48*mm]
    for x, t in zip(xs3, kopf3):
        c.setFont("DJ", 5.6); c.setFillColor(B.FAINT)
        c.drawString(x, y + 1.4*mm, t)
    y -= 4.0*mm
    for i in (1, 2):
        B.menue(c, f"{pre}_f_vektor{i}", xs3[0], y, brs3[0], ho=4.6*mm,
                optionen=["-", "BESCHAFFUNG (HUMINT/Cyber)", "ABWERBUNG (Kopf)",
                          "NACHBAU (Artefakt/Wrack)", "HANDEL (Lizenz)"],
                tip=f"Vektor {i}", vorwahl=0)
        B.menue(c, f"{pre}_f_gegen{i}", xs3[1], y, brs3[1], ho=4.6*mm,
                optionen=["-", "USA", "CHN", "EU", "IND", "RUS", "REST"],
                tip="Zielfraktion", vorwahl=0, frei=True)
        B.feld(c, f"{pre}_f_ziel{i}", xs3[2], y, brs3[2], ho=4.6*mm, tip="Ziel-Technologie")
        B.feld(c, f"{pre}_f_bem{i}", xs3[3], y, brs3[3], ho=4.6*mm, tip="kurz")
        y -= 6.2*mm
    B.hinweis(c, 18*mm, y + 1.0*mm,
              "BESCHAFFUNG/ABWERBUNG: Erfolg 0,39 · Entdeckung 0,60. NACHBAU und HANDEL ohne Wurf, dafuer gedeckelt (Frontier-1 bzw. 0,70 E0).",
              B.FAINT, 5.8)
    B.hinweis(c, 18*mm, y - 3.0*mm,
              "PAPIER IST NICHT KOENNEN: ohne ABWERBUNG bleibt Beute an tacit-lastigen Techs (Kernwaffen, Triebwerke, Fertigung) bei 0,50 E0 stehen.",
              B.GRUEN, 5.8)
    B.hinweis(c, 18*mm, y - 6.6*mm,
              "5 % der erfolgreichen Operationen tragen 50 % des Ertrags — Spionage als Ersatz eigener Forschung ist eine Lotterie.",
              B.FAINT, 5.8)

    # ---------------- 24 HAERTUNG ----------------
    y = B.abschnitt(c, y - 12*mm, "24", "EIGENE ABWEHR — Haertung kostet eigenes Tempo")
    _x0, _x1 = 62*mm, W - 24*mm
    B.W = 128*mm + 24*mm          # Regler endet vor dem Schriftfeld
    B.regler(c, f"{pre}_f_haertung", y, "Haertungsstufe",
             ["H0", "H1", "H2", "H3"], vorwahl=-1, farbe=B.GRUEN,
             fussnote="Fremder Erfolg 0,39 / 0,34 / 0,26 / 0,14 — eigene Rate x 1,00 / 0,97 / 0,92 / 0,82. Wer sich zumauert, forscht langsamer.")
    B.W = W

    B.schriftfeld(c, pre, fraktion, zug, 4, 4)


def mach(pfad, B, fraktion=None, zug=None, pre="bf", bestand=None, pruefer=None, welt=None):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(pfad, pagesize=A4)
    c.setTitle("Befehlsblatt Blatt 4 RECHENWERK & FORSCHUNG"
               + (f" {fraktion} Zug {zug}" if fraktion else " (blanko)"))
    c.setAuthor("DR. J., THYRNAU")
    c.setSubject("DW-01 / FO-01 Hausformular")
    rechenblatt(c, B, fraktion, zug, pre, bestand, pruefer, welt)
    B._need_appearances(c)
    c.save()
    return os.path.getsize(pfad)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--aus", default=".")
    ap.add_argument("--praefix", default="bf")
    ap.add_argument("--fraktion", default=None)
    ap.add_argument("--zug", type=int, default=None)
    ap.add_argument("--erde01", default=None)
    ap.add_argument("--gamestate", default=None,
                    help="Spielstand fuer Rechenbestand und Prueferstufe (B-23)")
    a = ap.parse_args(argv)
    B = lade_befehlsblatt(a.erde01)
    os.makedirs(a.aus, exist_ok=True)
    name = (f"Befehlsblatt4_RECHENWERK_{a.fraktion}_Zug{a.zug or 1}.pdf"
            if a.fraktion else "Befehlsblatt4_RECHENWERK_blanko.pdf")
    pfad = os.path.join(a.aus, name)
    bestand, pruefer, welt = stand_aus_spielstand(a.gamestate, a.fraktion)
    n = mach(pfad, B, a.fraktion, a.zug, a.praefix, bestand, pruefer, welt)
    if a.gamestate:
        print(f"  VORGABE aus dem Spielstand: Bestand {bestand} RP · Pruefer {pruefer} · Welt {welt} RP")
    print(f"  {os.path.basename(pfad):46s} {n/1024:5.1f} KiB   (Vorlage: {B._pfad})")
    return pfad


if __name__ == "__main__":
    main()
