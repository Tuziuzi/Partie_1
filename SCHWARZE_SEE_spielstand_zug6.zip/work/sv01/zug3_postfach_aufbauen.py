#!/usr/bin/env python3
"""ERDE-01-Posteingang fuer Zug 3 (2028). Gegenmittel gegen B-20 wie in Zug 2:
aufgeloeste Vorzuege wandern nach `archiv`, `orders` fuehrt nur den laufenden Zug."""
import json, subprocess, pathlib, sys

WS = pathlib.Path("/root/kampagne")
ST = WS / "erde01_state_schwarzesee.json"
cfg = json.loads((WS / "config.json").read_text(encoding="utf-8"))
S = pathlib.Path(cfg["skill_verzeichnisse"]["erde01"])
UP = pathlib.Path("/root/.claude/uploads/e98b1bb9-d2fd-56e0-aa86-896c0cde3298")

e = json.loads(ST.read_text(encoding="utf-8"))
for st, d in e["postfach"].items():
    arch = d.setdefault("archiv", [])
    for o in d.get("orders", []):
        o["zug"] = 2; o["aufgeloest"] = True; arch.append(o)
    d["orders"] = []
ST.write_text(json.dumps(e, ensure_ascii=False, indent=2), encoding="utf-8")

subprocess.run([sys.executable, str(S / "scripts/blattlesen.py"),
                str(UP / "0839d974-Befehlsblatt_Jakob_INDIEN_Zug3.pdf"),
                str(UP / "951ea35f-Befehlsblatt_Andi_CHINA_Zug3_1.pdf"),
                "--zug=3", f"--in={ST}"], check=True, capture_output=True)

e = json.loads(ST.read_text(encoding="utf-8"))
for st, d in e["postfach"].items():
    for o in d.get("orders", []):
        o["zug"] = 3; o.setdefault("aufgeloest", False)
        if not o["id"].startswith(f"O-{st}-Z3"):
            o["id"] = o["id"].replace(f"O-{st}-", f"O-{st}-Z3-")

DOM = {"intel": "intel", "wirtschaft": "wirtschaft", "diplomatie": "aussenpolitik",
       "militaer": "militaer", "innen": "innenpolitik", "forschung": "forschung",
       "eskalation": "aussenpolitik", "haltung": "aussenpolitik", "reaktion": "militaer"}

def lege(st, quelle, zeilen, energie):
    pf = e["postfach"].setdefault(st, {"orders": [], "archiv": []})
    pf.setdefault("orders", [])
    i = 0
    for z in zeilen:
        t = z.get("typ")
        if t == "budget":
            i += 1
            pf["orders"].append({"id": f"O-{st}-Z3-{i:02d}", "fraktion": st, "domaene": "wirtschaft",
                                 "ziel": st, "zug": 3, "aufgeloest": False, "herkunft": quelle,
                                 "text": "Budgetverteilung " + ", ".join(
                                     f"{k} {v:.0%}" for k, v in z["konten"].items())})
            continue
        i += 1
        pf["orders"].append({"id": f"O-{st}-Z3-{i:02d}", "fraktion": st,
                             "domaene": DOM.get(t, "aussenpolitik"), "ziel": z.get("ziel") or "-",
                             "text": z.get("text") or f"{t}: {z.get('wert') or z.get('antwort')}",
                             "zug": 3, "aufgeloest": False, "herkunft": quelle})
    if energie:
        pf["orders"].append({"id": f"O-{st}-Z3-E1", "fraktion": st, "domaene": "energie", "ziel": "-",
                             "zug": 3, "aufgeloest": False, "herkunft": quelle,
                             "text": f"Energiepolitik: Vorwahl {energie['mischung']}, "
                                     f"Budget {int(energie['budgetanteil']*100)}%",
                             "parameter": {"budgetanteil": energie["budgetanteil"],
                                           "mischung": energie["mischung"]}})

for fid, st, datei in (("USA", "usa", "blatt_USA_z3.json"), ("RUS", "russland", "blatt_RUS_z3.json")):
    b = json.loads((WS / "work/sv01" / datei).read_text(encoding="utf-8"))
    lege(st, f"STELLWERK A2 — {fid}", b["zeilen"], b.get("energie"))

eu = json.loads((WS / "work/sv01/a1_zug3.json/order_EU.json").read_text(encoding="utf-8"))
lege("eu", "STELLWERK A1 — defensiv-oekonomisch", eu["zeilen"],
     {"mischung": "erneuerbar", "budgetanteil": 1.0})
rest = json.loads((WS / "work/sv01/a1_zug3.json/order_REST.json").read_text(encoding="utf-8"))
lege("rest", "STELLWERK A1 — status-quo", rest["zeilen"],
     {"mischung": "ausgewogen", "budgetanteil": 1.0})

k = e["kopf"]; k["zug"] = 3; k["uhr"]["datum_ingame"] = "2028-12-31"
sr = k["seed_registry"]; sr["zug_seed"] = 20280101
sr["stufen_seeds"] = {nm: 20280100 + i + 2 for i, nm in enumerate(
    ["validierung", "aufloesung", "sensorfilter", "regime_bias", "rendering",
     "kipppunkte", "coup", "attribution", "schicksal"])}
for i, s in enumerate(["usa", "china", "eu", "indien", "russland", "rest"]):
    sr["stufen_seeds"][f"regime_bias_{s}"] = 20280200 + i
e["module"]["erde01"]["daten"]["domaenen_zug3"] = {
    d: {"status": "offen"} for d in ["energie", "wirtschaft", "innenpolitik",
                                     "aussenpolitik", "intel", "militaer", "forschung"]}
ST.write_text(json.dumps(e, ensure_ascii=False, indent=2), encoding="utf-8")
for st, d in e["postfach"].items():
    en = [o for o in d["orders"] if o["domaene"] == "energie"]
    print(f"{st:9s} {len(d['orders']):2d} Zug-3-Orders · Archiv {len(d.get('archiv', [])):2d}"
          f" · Energie: {en[0]['parameter']['mischung'] if en else '—'}")
