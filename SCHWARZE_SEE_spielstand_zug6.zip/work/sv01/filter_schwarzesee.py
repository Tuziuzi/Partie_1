#!/usr/bin/env python3
"""SV-01 FILTER — Hausfassung fuer die Kampagne SCHWARZE SEE.

BEFUND B-19: sv01_pipeline.py filter liest state["fraktionen"] und state["welt"].
Der Delta-V-Spielstand schreibt aber state["factions"] und state["state"]; ausserdem
kennt er keine Felder "public" / "sichtbar_fuer". Der Kanonfilter liefert deshalb
sechs leere SITREPs — formal korrekt (SV-01 §9.3: im Zweifel UNSICHTBAR), praktisch
unbrauchbar, weil die A2/A3-Agenten dann ueber nichts entscheiden.

Diese Hausfassung bildet dieselbe Regel auf das tatsaechliche Schema ab:
  eigene Daten voll  ·  fremde Daten nur aus der WEISSEN LISTE unten.
Die weisse Liste ist die Menge dessen, was in dieser Partie nachweislich
oeffentlich ist: veroeffentlichte Handelslage, SIPRI/FAS-Groessen, beobachtbare
Bahnobjekte und Startkapazitaet, Vertraege, Weltklima. Alles andere bleibt drin.
"""
import json, hashlib, pathlib, sys

WS = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".")
OUT = WS / "work/sv01/sitreps"
OUT.mkdir(parents=True, exist_ok=True)

gs = json.loads((WS / "gamestate.json").read_text(encoding="utf-8"))
e01 = json.loads((WS / "erde01_state_schwarzesee.json").read_text(encoding="utf-8"))
d01 = e01["module"]["erde01"]["daten"]
DV2E = {"USA": "usa", "CHN": "china", "EU": "eu", "IND": "indien",
        "RUS": "russland", "REST": "rest"}

# ---------------------------------------------------------------- WELT (allen bekannt)
WELT = {
    "jahr": gs["state"]["currentYear"], "zug": 2,
    "klima": {"co2_ppm": d01["co2_ppm"], "delta_T_C": d01["T_ist_C"],
              "biosphaere": d01["biosphaere"], "K": d01["K_welt"]},
    "energie_scores_2026": {"EU": 67.6, "USA": 54.8, "REST": 52.2, "CHN": 46.0, "IND": 44.6},
    "rezessionsflag_2026": {"EU": -0.1123, "IND": -0.0518},
    "vertraege": ["EU <-> IND Freihandel (Zug 1)",
                  "CHN <-> IND Wirtschaft ohne Technologietransfer (Zug 1)",
                  "CHN Exportverbot gegen die EU in Kraft",
                  "EU-Strafzoelle gegen CHN, 7 Jahre Laufzeit (-0,7 Pp/a)"],
    "compute_weltbestand_rp": 100,
    "techstufen": "keine offen — L1 oeffnet erst 2035/2036",
    "hinweis_zug1": ("Chinas Wirtschaftsangriff auf die EU (C-7) hat China selbst -9,0 % BIP "
                     "gekostet und der EU -1,45 %. Zwei Attributionen liegen oeffentlich "
                     "benennbar bei der EU: China A1, Indien B2 (falsche Flagge durchschaut).")}

# ---------------------------------------------------------- WEISSE LISTE (fremde Sicht)
def oeffentlich(fid):
    f = gs["factions"][fid]
    r = f["economy"]["resources"]
    sw = f.get("swarms") or {}
    zeug = gs["zeughaus"]["fraktionen"].get(fid, {})
    e = DV2E[fid]
    return {
        "regime": f.get("regime"),
        "bip_bio_usd": (e01["truth"]["ressourcen"].get(e) or {}).get("bip_bio_usd"),
        "startkapazitaet_t_a": r["launch"]["capacity_t_year"],
        "bahnobjekte": {k: {"count": v.get("count"), "zone": v.get("zone")} for k, v in sw.items()},
        "sprengkoepfe_geschaetzt": (zeug.get("sprengkoepfe") or {}).get("lager"),
        "bodentruppen_bl01": f.get("groundForces"),
        "compute_rp_geschaetzt": (f.get("computeConfig") or {}).get("stock_rp"),
        "quelle": "SIPRI/FAS/BL-01, beobachtbare Bahnobjekte, veroeffentlichte Handelslage",
    }

VERDECKT = ("Zuteilung der Rechenpunkte, verdeckte Operationen, Doktrin-Deklarationen ohne "
            "oeffentliche Ansage, Bodenkonto-Innenleben, fremde Attributionsergebnisse, "
            "Bauplaene vor dem Start")

pfade, hashes = {}, {}
for fid in gs["stellwerkConfig"]["fraktionen"]:
    e = DV2E[fid]
    sit = {"fraktion": fid, "zug": 2, "jahr": 2027, "welt": WELT,
           "eigene": {
               "spielstand": gs["factions"][fid],
               "zeughaus": gs["zeughaus"]["fraktionen"].get(fid),
               "forschung": gs["forschung"]["fraktionen"].get(fid),
               "eigene_orders_historie": (e01["postfach"].get(e) or {}).get("orders", []),
               "regler_2026": d01.get("regler_2026", {}).get(e)},
           "fremde": {o: oeffentlich(o) for o in gs["factions"] if o != fid},
           "unsichtbar": VERDECKT}
    p = OUT / f"sitrep_{fid}.json"
    p.write_text(json.dumps(sit, ensure_ascii=False, indent=1), encoding="utf-8")
    pfade[fid] = str(p)
    hashes[fid] = hashlib.sha256(p.read_bytes()).hexdigest()

print(json.dumps({"pfade": pfade, "sha256": hashes}, ensure_ascii=False, indent=1))
