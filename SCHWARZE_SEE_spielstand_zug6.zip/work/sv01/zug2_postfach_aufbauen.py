#!/usr/bin/env python3
"""Baut den ERDE-01-Zug-2-Posteingang deterministisch aus dem Snapshot auf.

BEFUND B-20: eh01.py _befehle_lesen() durchsucht das ganze Postfach nach
domaene == "energie" und filtert NICHT nach Zug. Bleiben die aufgeloesten
Zug-1-Energiebefehle in `orders` liegen, gewinnt der alte Befehl und der neue
wird still ignoriert — China haette 2027 weiter "erneuerbar" gefahren statt
"nuklear". Kein Befund, keine Warnung.

Gegenmittel ohne Skilleingriff: aufgeloeste Vorzuege nach `archiv` verschieben.
`orders` fuehrt damit nur den laufenden Zug — was der Bedeutung des Feldes
ohnehin entspricht.
"""
import json, subprocess, pathlib, sys

WS = pathlib.Path("/root/kampagne")
S = pathlib.Path("/root/.claude/skills/synced")
ST = WS / "erde01_state_schwarzesee.json"

# 1) Snapshot zurueckspielen
ST.write_bytes((WS / "snapshots/erde01_vor_zug2.json").read_bytes())
e = json.loads(ST.read_text(encoding="utf-8"))

# 2) Alle Vorzug-Orders ins Archiv
for st, d in e["postfach"].items():
    arch = d.setdefault("archiv", [])
    for o in d.get("orders", []):
        o["zug"] = 1
        o["aufgeloest"] = True
        arch.append(o)
    d["orders"] = []
ST.write_text(json.dumps(e, ensure_ascii=False, indent=2), encoding="utf-8")

# 3) Blatt 1/2 der beiden menschlichen Spieler einlesen
subprocess.run([sys.executable, str(S / "erde01-gm/scripts/blattlesen.py"),
                str(WS / "blaetter/zug2/eingereicht/Befehlsblatt_Jakob_INDIEN_Zug2.pdf"),
                str(WS / "blaetter/zug2/eingereicht/Befehlsblatt_Andi_CHINA_Zug2.pdf"),
                "--zug=2", f"--in={ST}"], check=True, capture_output=True)

e = json.loads(ST.read_text(encoding="utf-8"))
for st, d in e["postfach"].items():
    for o in d.get("orders", []):
        o["zug"] = 2
        o.setdefault("aufgeloest", False)
        if not o["id"].startswith(f"O-{st}-Z2"):
            o["id"] = o["id"].replace(f"O-{st}-", f"O-{st}-Z2-")

# 4) STELLWERK-Blaetter (EU A3/V2, USA A2, RUS A2) und REST (A1)
al = json.loads((WS / "work/sv01/orders_all.json").read_text(encoding="utf-8"))
MAP = {"EU": "eu", "USA": "usa", "RUS": "russland"}
DOM = {"intel": "intel", "wirtschaft": "wirtschaft", "diplomatie": "aussenpolitik",
       "militaer": "militaer", "innen": "innenpolitik", "forschung": "forschung",
       "eskalation": "aussenpolitik"}
for fid, blatt in al["orders"].items():
    st = MAP[fid]
    pf = e["postfach"].setdefault(st, {"orders": [], "archiv": []})
    pf.setdefault("orders", [])
    i = 0
    for z in blatt.get("zeilen", []):
        if z.get("typ") in ("budget", "haltung"):
            continue
        i += 1
        pf["orders"].append({"id": f"O-{st}-Z2-{i:02d}", "fraktion": st,
                             "domaene": DOM.get(z["typ"], "aussenpolitik"),
                             "ziel": z.get("ziel") or "-", "text": z.get("text"),
                             "zug": 2, "aufgeloest": False,
                             "herkunft": f"STELLWERK — {fid}"})
    en = blatt.get("energie") or {}
    pf["orders"].append({"id": f"O-{st}-Z2-E1", "fraktion": st, "domaene": "energie",
                         "ziel": "-", "zug": 2, "aufgeloest": False, "herkunft": "STELLWERK",
                         "text": f"Energiepolitik: Vorwahl {en.get('mischung')}, "
                                 f"Budget {int(en.get('budgetanteil', 1) * 100)}%",
                         "parameter": {"budgetanteil": en.get("budgetanteil"),
                                       "mischung": en.get("mischung")}})
pf = e["postfach"].setdefault("rest", {"orders": [], "archiv": []})
pf.setdefault("orders", []).append(
    {"id": "O-rest-Z2-00", "fraktion": "rest", "domaene": "aussenpolitik", "ziel": "-",
     "text": "A1-Doktrinbaum status-quo: Budget fortschreiben, Haltung halten, rein reaktiv.",
     "zug": 2, "aufgeloest": False, "herkunft": "STELLWERK A1 (SB-1 Sammelblock)"})

# 5) Kopf auf Zug 2
k = e["kopf"]; k["zug"] = 2; k["uhr"]["datum_ingame"] = "2027-12-31"
sr = k["seed_registry"]; sr["zug_seed"] = 20270101
sr["stufen_seeds"] = {nm: 20270100 + i + 2 for i, nm in enumerate(
    ["validierung", "aufloesung", "sensorfilter", "regime_bias", "rendering",
     "kipppunkte", "coup", "attribution", "schicksal"])}
for i, s in enumerate(["usa", "china", "eu", "indien", "russland", "rest"]):
    sr["stufen_seeds"][f"regime_bias_{s}"] = 20270200 + i
e["module"]["erde01"]["daten"]["domaenen_zug2"] = {
    d: {"status": "offen"} for d in ["energie", "wirtschaft", "innenpolitik",
                                     "aussenpolitik", "intel", "militaer", "forschung"]}
ST.write_text(json.dumps(e, ensure_ascii=False, indent=2), encoding="utf-8")

for st, d in e["postfach"].items():
    en = [o for o in d["orders"] if o["domaene"] == "energie"]
    print(f"{st:9s} {len(d['orders']):2d} Zug-2-Orders · Archiv {len(d.get('archiv', [])):2d}"
          f" · Energie: {en[0]['parameter']['mischung'] if en else '—'}")
